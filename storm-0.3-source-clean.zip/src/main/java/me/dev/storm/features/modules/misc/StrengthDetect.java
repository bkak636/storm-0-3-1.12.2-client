/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.MobEffects
 */
package me.dev.storm.features.modules.misc;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import me.dev.storm.features.command.Command;
import me.dev.storm.features.modules.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;

public class StrengthDetect
extends Module {
    public static final Minecraft mc = Minecraft.func_71410_x();
    private final Set<EntityPlayer> str = Collections.newSetFromMap(new WeakHashMap());

    public StrengthDetect() {
        super("StrengthNotify", "Notifies who has the strength potion effect.", Module.Category.MISC, true, false, false);
    }

    @Override
    public String onUpdate() {
        for (EntityPlayer player : StrengthDetect.mc.field_71441_e.field_73010_i) {
            if (player.equals((Object)StrengthDetect.mc.field_71439_g)) continue;
            if (player.func_70644_a(MobEffects.field_76420_g) && !this.str.contains(player)) {
                Command.sendMessage(player.getDisplayNameString() + " has strength");
                this.str.add(player);
            }
            if (!this.str.contains(player) || player.func_70644_a(MobEffects.field_76420_g)) continue;
            Command.sendMessage(player.getDisplayNameString() + " doesnt have strength anymore");
            this.str.remove(player);
        }
        return null;
    }
}

