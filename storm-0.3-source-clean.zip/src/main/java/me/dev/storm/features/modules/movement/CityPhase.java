/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;

public class CityPhase
extends Module {
    public Setting<Float> timeout = this.register(new Setting<Integer>("timeout", 5, 1, 10));

    public CityPhase() {
        super("CityPhase", "CityPhase", Module.Category.MOVEMENT, true, false, false);
    }

    public CityPhase(String name, String description, Module.Category category, boolean hasListener, boolean hidden, boolean alwaysListening) {
        super(name, description, category, hasListener, hidden, alwaysListening);
    }

    public boolean movingByKeys() {
        return CityPhase.mc.field_71474_y.field_74351_w.func_151470_d() || CityPhase.mc.field_71474_y.field_74368_y.func_151470_d() || CityPhase.mc.field_71474_y.field_74370_x.func_151470_d() || CityPhase.mc.field_71474_y.field_74366_z.func_151470_d();
    }

    public double roundToClosest(double num, double low, double high) {
        double d2 = high - num;
        double d1 = num - low;
        if (d2 > d1) {
            return low;
        }
        return high;
    }
}

