/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package me.dev.storm.features.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.storm.features.command.Command;

public class CoordCommand
extends Command {
    public CoordCommand() {
        super("coords", new String[0]);
    }

    @Override
    public void execute(String[] commands) {
        if (commands.length >= 3) {
            CoordCommand.sendMessage(ChatFormatting.GREEN + commands[0] + "'s coords are: " + commands[1] + ", " + commands[2] + ChatFormatting.GREEN + " [Overworld]");
        }
    }
}

