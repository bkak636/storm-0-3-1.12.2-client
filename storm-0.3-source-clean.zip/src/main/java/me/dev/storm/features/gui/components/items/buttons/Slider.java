/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  org.lwjgl.input.Mouse
 */
package me.dev.storm.features.gui.components.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import me.dev.storm.Storm;
import me.dev.storm.features.gui.StormGui;
import me.dev.storm.features.gui.components.Component;
import me.dev.storm.features.gui.components.items.buttons.Button;
import me.dev.storm.features.modules.client.ClickGui;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.manager.FpsManager;
import me.dev.storm.util.ColorUtil;
import me.dev.storm.util.RenderUtil;
import org.lwjgl.input.Mouse;

public class Slider
extends Button {
    private final Number min;
    private final Number max;
    private final int difference;
    public Setting setting;
    private float renderWidth;
    private float prevRenderWidth;

    public Slider(Setting setting) {
        super(setting.getName());
        this.setting = setting;
        this.min = (Number)setting.getMin();
        this.max = (Number)setting.getMax();
        this.difference = this.max.intValue() - this.min.intValue();
        this.width = 15;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        boolean newStyle = ClickGui.getInstance().style.getValue() == ClickGui.Style.NEW;
        boolean future = ClickGui.getInstance().style.getValue() == ClickGui.Style.FUTURE;
        boolean dotgod = ClickGui.getInstance().style.getValue() == ClickGui.Style.DOTGOD;
        this.dragSetting(mouseX, mouseY);
        this.setRenderWidth(this.x + ((float)this.width + 7.4f) * this.partialMultiplier());
        RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4f, this.y + (float)this.height - 0.5f, !this.isHovering(mouseX, mouseY) ? 0x11555555 : -2007673515);
        if (future) {
            RenderUtil.drawRect(this.x, this.y, ((Number)this.setting.getValue()).floatValue() <= this.min.floatValue() ? this.x : this.getRenderWidth(), this.y + (float)this.height - 0.5f, !this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(99) : Storm.colorManager.getCurrentWithAlpha(120));
        } else if (dotgod) {
            RenderUtil.drawRect(this.x, this.y, ((Number)this.setting.getValue()).floatValue() <= this.min.floatValue() ? this.x : this.getRenderWidth(), this.y + (float)this.height - 0.5f, !this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(65) : Storm.colorManager.getCurrentWithAlpha(90));
        } else {
            if (this.isHovering(mouseX, mouseY) && Mouse.isButtonDown((int)0)) {
                RenderUtil.drawHGradientRect(this.x, this.y, ((Number)this.setting.getValue()).floatValue() <= this.min.floatValue() ? this.x : this.getRenderWidth(), this.y + (float)this.height - 0.5f, ColorUtil.pulseColor(new Color(ClickGui.getInstance().color.getValue().getRed(), ClickGui.getInstance().color.getValue().getGreen(), ClickGui.getInstance().color.getValue().getBlue(), 200), 50, 1).getRGB(), ColorUtil.pulseColor(new Color(ClickGui.getInstance().color.getValue().getRed(), ClickGui.getInstance().color.getValue().getGreen(), ClickGui.getInstance().color.getValue().getBlue(), 200), 50, 1000).getRGB());
            } else {
                RenderUtil.drawRect(this.x, this.y, ((Number)this.setting.getValue()).floatValue() <= this.min.floatValue() ? this.x : this.getRenderWidth(), this.y + (float)this.height - 0.5f, !this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(120) : Storm.colorManager.getCurrentWithAlpha(200));
            }
            RenderUtil.drawLine(this.x + 1.0f, this.y, this.x + 1.0f, this.y + (float)this.height - 0.5f, 0.9f, Storm.colorManager.getCurrentWithAlpha(255));
        }
        if (dotgod) {
            Storm.textManager.drawStringWithShadow(this.getName().toLowerCase() + ":" + " " + ChatFormatting.GRAY + (this.setting.getValue() instanceof Float ? this.setting.getValue() : Double.valueOf(((Number)this.setting.getValue()).doubleValue())), this.x + 2.3f, this.y - 1.7f - (float)StormGui.getInstance().getTextOffset(), Storm.colorManager.getCurrentGui(240));
        } else {
            RenderUtil.drawRect(this.x, this.y, ((Number)this.setting.getValue()).floatValue() <= this.min.floatValue() ? this.x : this.x + ((float)this.width + 7.4f) * this.partialMultiplier(), this.y + (float)this.height - 0.5f, !this.isHovering(mouseX, mouseY) ? Storm.colorManager.getColorWithAlpha(Storm.moduleManager.getModuleByClass(ClickGui.class).hoverAlpha.getValue()) : Storm.colorManager.getColorWithAlpha(Storm.moduleManager.getModuleByClass(ClickGui.class).alpha.getValue()));
            Storm.textManager.drawStringWithShadow((newStyle ? this.getName().toLowerCase() + ":" : this.getName()) + " " + ChatFormatting.GRAY + (this.setting.getValue() instanceof Float ? this.setting.getValue() : Double.valueOf(((Number)this.setting.getValue()).doubleValue())), this.x + 2.3f, this.y - 1.7f - (float)StormGui.getInstance().getTextOffset(), -1);
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (this.isHovering(mouseX, mouseY)) {
            this.setSettingFromX(mouseX);
        }
    }

    public void setRenderWidth(float renderWidth) {
        if (this.renderWidth == renderWidth) {
            return;
        }
        this.prevRenderWidth = this.renderWidth;
        this.renderWidth = renderWidth;
    }

    public float getRenderWidth() {
        if (FpsManager.getFPS() < 20) {
            return this.renderWidth;
        }
        this.renderWidth = this.prevRenderWidth + (this.renderWidth - this.prevRenderWidth) * mc.func_184121_ak() / (8.0f * ((float)Math.min(240, FpsManager.getFPS()) / 240.0f));
        return this.renderWidth;
    }

    @Override
    public boolean isHovering(int mouseX, int mouseY) {
        for (Component component : StormGui.getClickGui().getComponents()) {
            if (!component.drag) continue;
            return false;
        }
        return (float)mouseX >= this.getX() && (float)mouseX <= this.getX() + (float)this.getWidth() + 8.0f && (float)mouseY >= this.getY() && (float)mouseY <= this.getY() + (float)this.height;
    }

    @Override
    public void update() {
        this.setHidden(!this.setting.isVisible());
    }

    private void dragSetting(int mouseX, int mouseY) {
        if (this.isHovering(mouseX, mouseY) && Mouse.isButtonDown((int)0)) {
            this.setSettingFromX(mouseX);
        }
    }

    @Override
    public int getHeight() {
        return 14;
    }

    private void setSettingFromX(int mouseX) {
        float percent = ((float)mouseX - this.x) / ((float)this.width + 7.4f);
        if (this.setting.getValue() instanceof Double) {
            double result = (Double)this.setting.getMin() + (double)((float)this.difference * percent);
            this.setting.setValue((double)Math.round(10.0 * result) / 10.0);
        } else if (this.setting.getValue() instanceof Float) {
            float result = ((Float)this.setting.getMin()).floatValue() + (float)this.difference * percent;
            this.setting.setValue(Float.valueOf((float)Math.round(10.0f * result) / 10.0f));
        } else if (this.setting.getValue() instanceof Integer) {
            this.setting.setValue((Integer)this.setting.getMin() + (int)((float)this.difference * percent));
        }
    }

    private float middle() {
        return this.max.floatValue() - this.min.floatValue();
    }

    private float part() {
        return ((Number)this.setting.getValue()).floatValue() - this.min.floatValue();
    }

    private float partialMultiplier() {
        return this.part() / this.middle();
    }
}

