/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.item.ItemStack
 */
package me.dev.storm.features.modules.misc;

import me.dev.storm.event.events.Render2DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;

public class DurabilityAlert
extends Module {
    private Setting<Integer> dura = this.register(new Setting<Integer>("Durability", 10, 1, 100));
    private Setting<Boolean> chad = this.register(new Setting<Boolean>("Australian Mode", true));
    private boolean lowDura = false;

    public DurabilityAlert() {
        super("DurabilityAlert", "Alerts you and your friends if you have low durability", Module.Category.MISC, true, false, false);
    }

    @Override
    public String onUpdate() {
        this.lowDura = false;
        try {
            for (ItemStack is : DurabilityAlert.mc.field_71439_g.func_184193_aE()) {
                float green = ((float)is.func_77958_k() - (float)is.func_77952_i()) / (float)is.func_77958_k();
                float red = 1.0f - green;
                int dmg = 100 - (int)(red * 100.0f);
                if ((float)dmg > (float)this.dura.getValue().intValue()) continue;
                this.lowDura = true;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        if (this.lowDura) {
            ScaledResolution sr = new ScaledResolution(mc);
            DurabilityAlert.mc.field_71466_p.func_175063_a("Warning: Your " + (this.chad.getValue() != false ? "armour" : "shits") + " is below " + this.dura.getValue() + "%", (float)(sr.func_78326_a() / 2 - DurabilityAlert.mc.field_71466_p.func_78256_a("Warning: Your armour is below " + this.dura.getValue() + "%") / 2), 15.0f, -65536);
        }
    }
}

