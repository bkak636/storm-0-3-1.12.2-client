/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraftforge.client.event.RenderGameOverlayEvent$ElementType
 *  net.minecraftforge.client.event.RenderGameOverlayEvent$Post
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.InputEvent$KeyInputEvent
 *  org.lwjgl.input.Keyboard
 */
package me.dev.storm.features.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import me.dev.storm.features.command.Command;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.client.Watermark;
import me.dev.storm.features.modules.misc.PopCounter;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

public class Notifications
extends Module {
    public static HashMap<String, Integer> TotemPopContainer = new HashMap();
    private static Notifications INSTANCE = new Notifications();
    public Setting<Integer> posY = this.register(new Setting<Integer>("PosY", 520, 0, 1000));
    public Setting<Double> barPosY = this.register(new Setting<Double>("BarPosY", 0.0, -2.0, 15.0));
    public Setting<Double> textPosY = this.register(new Setting<Double>("TextPosY", 3.0, -6.0, 3.0));
    public Setting<Color> bC = this.register(new Setting<Color>("BorderColor", new Color(0, 0, 0, 255)));
    public Setting<Color> sC = this.register(new Setting<Color>("Background 1", new Color(0, 0, 0, 128)));
    public Setting<Color> foC = this.register(new Setting<Color>("Background 2", new Color(0, 0, 0, 128)));
    public Setting<String> notificationText = this.register(new Setting<String>("NotificationText", "testmodule"));
    private List<String> notifications = new ArrayList<String>();
    private int currentNotificationIndex = -1;
    private boolean buttonPressed = false;
    private float animationTimer = 0.0f;
    private long startTime = 0L;
    private boolean isNotificationVisible = false;
    private boolean isReversingAnimation = false;

    public Notifications() {
        super("Notifications", "notifs", Module.Category.CLIENT, true, false, false);
        this.setInstance();
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post event) throws InterruptedException {
        if (Watermark.nullCheck() || !this.isNotificationVisible && !this.isReversingAnimation) {
            return;
        }
        if (event.getType() == RenderGameOverlayEvent.ElementType.HOTBAR) {
            String storm = ChatFormatting.WHITE + this.notifications.get(this.currentNotificationIndex);
            float width = Minecraft.func_71410_x().field_71466_p.func_78256_a(storm) + 6;
            float posX = (float)event.getResolution().func_78326_a() - width - 4.0f;
            float posY = this.posY.getValue().intValue();
            double barPosY = this.barPosY.getValue();
            double textPosY = this.textPosY.getValue();
            float animationProgress = 1.0f;
            if (this.buttonPressed || this.isReversingAnimation) {
                long elapsedTime = System.currentTimeMillis() - this.startTime;
                animationProgress = this.buttonPressed && elapsedTime < 1000L ? this.easeInOutQuad((float)elapsedTime / 1000.0f) : (this.isReversingAnimation && elapsedTime < 1000L ? 1.0f - this.easeInOutQuad((float)elapsedTime / 1000.0f) : (this.buttonPressed ? 1.0f : 0.0f));
            }
            float animatedWidth = width * animationProgress;
            float animatedPosX = posX + (width - animatedWidth);
            RenderUtil.drawGradientSideways(animatedPosX, (double)posY + barPosY, event.getResolution().func_78326_a(), (double)posY + barPosY + 17.0, new Color(this.sC.getValue().getRed(), this.sC.getValue().getGreen(), this.sC.getValue().getBlue(), this.sC.getValue().getAlpha()).getRGB(), new Color(this.foC.getValue().getRed(), this.foC.getValue().getGreen(), this.foC.getValue().getBlue(), this.foC.getValue().getAlpha()).getRGB());
            Minecraft.func_71410_x().field_71466_p.func_175063_a(storm, animatedPosX + 4.0f, (float)((double)posY + textPosY), -1);
            if (this.buttonPressed && animationProgress < 1.0f) {
                this.animationTimer += 1.0f;
            } else if (!this.buttonPressed && animationProgress > 0.0f) {
                this.animationTimer -= 1.0f;
            }
            if (this.buttonPressed && animationProgress >= 1.0f) {
                this.buttonPressed = false;
                this.startTime = System.currentTimeMillis();
                this.isReversingAnimation = true;
            }
            if (this.isReversingAnimation && animationProgress <= 0.0f) {
                this.isReversingAnimation = false;
                this.isNotificationVisible = false;
            }
        }
    }

    @SubscribeEvent
    public void onKeyRelease(InputEvent.KeyInputEvent event) {
        if (Keyboard.getEventKey() == 25 && !Keyboard.getEventKeyState()) {
            if (this.buttonPressed) {
                this.isReversingAnimation = true;
            } else if (!this.isNotificationVisible && !this.isReversingAnimation) {
                String newNotification = this.notificationText.getValue();
                this.notifications.add(newNotification);
                this.currentNotificationIndex = this.notifications.size() - 1;
                this.buttonPressed = true;
                this.startTime = System.currentTimeMillis();
                this.isNotificationVisible = true;
            }
        }
    }

    public void showNotificationAfterSomething() {
        if (this.buttonPressed) {
            this.isReversingAnimation = true;
        } else if (!this.isNotificationVisible && !this.isReversingAnimation) {
            String newNotification = this.notificationText.getValue();
            this.notifications.add(newNotification);
            this.currentNotificationIndex = this.notifications.size() - 1;
            this.buttonPressed = true;
            this.startTime = System.currentTimeMillis();
            this.isNotificationVisible = true;
        }
    }

    public void onTotemPop(EntityPlayer player) {
        if (Notifications.fullNullCheck()) {
            return;
        }
        if (PopCounter.mc.field_71439_g.equals((Object)player)) {
            return;
        }
        int l_Count = 1;
        if (PopCounter.TotemPopContainer.containsKey(player.func_70005_c_())) {
            l_Count = PopCounter.TotemPopContainer.get(player.func_70005_c_());
            PopCounter.TotemPopContainer.put(player.func_70005_c_(), ++l_Count);
        } else {
            PopCounter.TotemPopContainer.put(player.func_70005_c_(), l_Count);
        }
        if (l_Count == 1) {
            Command.sendSilentMessage("" + ChatFormatting.BLUE + player.func_70005_c_() + ChatFormatting.BLUE + " popped " + ChatFormatting.WHITE + "one" + ChatFormatting.BLUE + " totem");
            this.notificationText.setValue("" + ChatFormatting.BLUE + player.func_70005_c_() + ChatFormatting.BLUE + " popped " + ChatFormatting.WHITE + "one" + ChatFormatting.BLUE + " totem");
            this.showNotificationAfterSomething();
        } else {
            this.notificationText.setValue("" + ChatFormatting.BLUE + player.func_70005_c_() + " popped " + ChatFormatting.WHITE + l_Count + ChatFormatting.BLUE + " totems");
            Command.sendSilentMessage("" + ChatFormatting.BLUE + player.func_70005_c_() + " popped " + ChatFormatting.WHITE + l_Count + ChatFormatting.BLUE + " totems");
            this.showNotificationAfterSomething();
        }
    }

    @Override
    public String onUpdate() {
        if (this.isNotificationVisible && !this.buttonPressed && !this.isReversingAnimation && this.currentNotificationIndex < this.notifications.size() - 1) {
            this.isNotificationVisible = false;
        }
        return null;
    }

    public static Notifications getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Notifications();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    private float easeInOutQuad(float t) {
        return t < 0.5f ? 2.0f * t * t : -1.0f + (4.0f - 2.0f * t) * t;
    }
}

