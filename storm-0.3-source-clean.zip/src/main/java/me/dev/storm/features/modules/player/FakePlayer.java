/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.entity.Entity
 *  net.minecraft.world.World
 *  org.apache.commons.io.IOUtils
 */
package me.dev.storm.features.modules.player;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import me.dev.storm.features.command.Command;
import me.dev.storm.features.modules.Module;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import org.apache.commons.io.IOUtils;

public class FakePlayer
extends Module {
    private final String name = "nigga";
    private EntityOtherPlayerMP _fakePlayer;

    public FakePlayer() {
        super("FakePlayer", "Spawns a FakePlayer for testing", Module.Category.PLAYER, false, false, false);
    }

    public static String getUuid(String name) {
        JsonParser parser = new JsonParser();
        String url = "https://api.mojang.com/users/profiles/minecraft/" + name;
        try {
            String UUIDJson = IOUtils.toString((URL)new URL(url), (Charset)StandardCharsets.UTF_8);
            if (UUIDJson.isEmpty()) {
                return "invalid name";
            }
            JsonObject UUIDObject = (JsonObject)parser.parse(UUIDJson);
            return FakePlayer.reformatUuid(UUIDObject.get("id").toString());
        }
        catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    private static String reformatUuid(String uuid) {
        String longUuid = "";
        longUuid = longUuid + uuid.substring(1, 9) + "-";
        longUuid = longUuid + uuid.substring(9, 13) + "-";
        longUuid = longUuid + uuid.substring(13, 17) + "-";
        longUuid = longUuid + uuid.substring(17, 21) + "-";
        longUuid = longUuid + uuid.substring(21, 33);
        return longUuid;
    }

    @Override
    public void onEnable() {
        if (FakePlayer.fullNullCheck()) {
            this.disable();
            return;
        }
        this._fakePlayer = null;
        if (FakePlayer.mc.field_71439_g != null) {
            try {
                this._fakePlayer = new EntityOtherPlayerMP((World)FakePlayer.mc.field_71441_e, new GameProfile(UUID.fromString(FakePlayer.getUuid(this.name)), this.name));
            }
            catch (Exception e) {
                this._fakePlayer = new EntityOtherPlayerMP((World)FakePlayer.mc.field_71441_e, new GameProfile(UUID.fromString("70ee432d-0a96-4137-a2c0-37cc9df67f03"), this.name));
                Command.sendMessage("Failed to load uuid, setting another one.");
            }
            Command.sendMessage(String.format("%s has been spawned.", this.name));
            this._fakePlayer.func_82149_j((Entity)FakePlayer.mc.field_71439_g);
            this._fakePlayer.field_70759_as = FakePlayer.mc.field_71439_g.field_70759_as;
            FakePlayer.mc.field_71441_e.func_73027_a(-100, (Entity)this._fakePlayer);
        }
    }

    @Override
    public void onDisable() {
        if (FakePlayer.mc.field_71441_e != null && FakePlayer.mc.field_71439_g != null) {
            super.onDisable();
            FakePlayer.mc.field_71441_e.func_72900_e((Entity)this._fakePlayer);
        }
    }

    @Override
    public String getDisplayInfo() {
        return "nigga";
    }
}

