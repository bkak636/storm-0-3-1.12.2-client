/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.entity.AbstractClientPlayer
 *  net.minecraft.client.gui.Gui
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.client.event.RenderGameOverlayEvent$Text
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.features.modules.render;

import java.awt.Color;
import java.util.Comparator;
import me.dev.storm.Storm;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.misc.PopCounter;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.MathUtil;
import me.dev.storm.util.RenderUtil;
import me.dev.storm.util.trollhack.ColorUtil;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class PTargetHud
extends Module {
    public final Setting<Float> x = this.register(new Setting<Float>("X", Float.valueOf(300.0f), Float.valueOf(0.0f), Float.valueOf(700.0f)));
    public final Setting<Float> y = this.register(new Setting<Float>("Y", Float.valueOf(300.0f), Float.valueOf(0.0f), Float.valueOf(700.0f)));
    public final Setting<HealthColor> healthColor = this.register(new Setting<HealthColor>("Health Color", HealthColor.Rainbow));
    public final Setting<Float> range = this.register(new Setting<Float>("Range", Float.valueOf(400.0f), Float.valueOf(0.0f), Float.valueOf(600.0f)));
    public final Setting<Integer> red = this.register(new Setting<Integer>("Red", 30, 0, 255));
    public final Setting<Integer> green = this.register(new Setting<Integer>("Green", 167, 0, 255));
    public final Setting<Integer> blue = this.register(new Setting<Integer>("Blue", 255, 0, 255));
    public final Setting<Integer> alpha = this.register(new Setting<Integer>("Alpha", 60, 0, 255));
    public float health;

    public PTargetHud() {
        super("TargetHud", "Draws a rectangle on your screen with some useful information about the enemy", Module.Category.RENDER, true, false, false);
    }

    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Text event) {
        if (PTargetHud.mc.field_71439_g == null || PTargetHud.mc.field_71441_e == null) {
            return;
        }
        EntityPlayer target = PTargetHud.mc.field_71441_e.field_73010_i.stream().filter(entity -> !Storm.friendManager.isFriend((EntityPlayer)entity) && !entity.equals((Object)PTargetHud.mc.field_71439_g) && !entity.field_70128_L && entity.func_70032_d((Entity)PTargetHud.mc.field_71439_g) <= this.range.getValue().floatValue()).min(Comparator.comparingDouble(entity -> entity.func_70032_d((Entity)PTargetHud.mc.field_71439_g))).orElse(null);
        if (target == null) {
            return;
        }
        this.drawRoundedRect(this.x.getValue().floatValue(), this.y.getValue().floatValue(), this.x.getValue().floatValue() + 150.0f, this.y.getValue().floatValue() + 54.0f, 6.0, new Color(20, 20, 20, 65).hashCode());
        this.drawOutlinedRoundedRect(this.x.getValue().floatValue(), this.y.getValue().floatValue(), this.x.getValue().floatValue() + 150.0f, this.y.getValue().floatValue() + 54.0f, 6.0, 3.0f, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()).hashCode());
        this.drawPlayerHeadTexture(this.x.getValue().floatValue() + 5.0f, this.y.getValue().floatValue() + 5.0f, 8.0f, 8.0f, 8, 8, 32, 32, 64.0f, 64.0f, (AbstractClientPlayer)target);
        PTargetHud.mc.field_71466_p.func_175065_a("Name: " + target.func_70005_c_(), this.x.getValue().floatValue() + 40.0f, this.y.getValue().floatValue() + 5.5f, -1, true);
        PTargetHud.mc.field_71466_p.func_175065_a("Pops: " + PopCounter.TotemPopContainer.getOrDefault(target.func_70005_c_(), 0), this.x.getValue().floatValue() + 40.0f, this.y.getValue().floatValue() + 14.0f, -1, true);
        PTargetHud.mc.field_71466_p.func_175065_a("Distance: " + MathUtil.round(target.func_70032_d((Entity)PTargetHud.mc.field_71439_g), 1), this.x.getValue().floatValue() + 80.0f, this.y.getValue().floatValue() + 14.0f, -1, true);
        float health = target.func_110143_aJ() + target.func_110139_bj();
        this.health += (health * 3.5f - this.health) * 0.075f;
        if (this.healthColor.getValue() == HealthColor.Auto) {
            RenderUtil.drawRect(this.x.getValue().floatValue() + 5.0f, this.y.getValue().floatValue() + 43.0f, this.x.getValue().floatValue() + this.health, this.y.getValue().floatValue() + 48.0f, this.getColorByHealth(health).hashCode());
        } else if (this.healthColor.getValue() == HealthColor.Rainbow) {
            float off = 0.0f;
            int i = 0;
            while ((float)i < this.health) {
                RenderUtil.drawRect(this.x.getValue().floatValue() + 5.0f + off, this.y.getValue().floatValue() + 43.0f, this.x.getValue().floatValue() + 5.0f + off + 1.0f, this.y.getValue().floatValue() + 48.0f, ColorUtil.getRainbow(1.0f * (this.x.getValue().floatValue() + 5.0f) * 1.4f + (float)i / 6.0f, 0.5f, 1.0f, 4500.0f));
                off += 0.91f;
                ++i;
            }
        }
        PTargetHud.mc.field_71466_p.func_175065_a(MathUtil.round(health, 1) + "", this.x.getValue().floatValue() + (this.healthColor.getValue() == HealthColor.Rainbow ? this.health * 0.91f + 4.0f : this.health) + 3.0f, this.y.getValue().floatValue() + 42.0f, -1, true);
        GlStateManager.func_179094_E();
        float i = this.x.getValue().floatValue() + 85.0f;
        for (ItemStack armor : target.field_71071_by.field_70460_b) {
            GlStateManager.func_179126_j();
            PTargetHud.mc.func_175597_ag().field_178112_h.func_180450_b(armor, (int)i, (int)(this.y.getValue().floatValue() + 23.0f));
            PTargetHud.mc.func_175597_ag().field_178112_h.func_180453_a(PTargetHud.mc.field_71466_p, armor, (int)i, (int)(this.y.getValue().floatValue() + 23.0f), "");
            GlStateManager.func_179098_w();
            GlStateManager.func_179140_f();
            GlStateManager.func_179097_i();
            i -= 15.0f;
        }
        GlStateManager.func_179121_F();
    }

    public Color getColorByHealth(float health) {
        return health > 20.0f ? new Color(0, 255, 10, 115) : (health > 10.0f ? new Color(255, 255, 0, 115) : new Color(255, 0, 10, 115));
    }

    public void drawPlayerHeadTexture(float x, float y, float u, float v, int uWidth, int vHeight, int width, int height, float tileWidth, float tileHeight, AbstractClientPlayer target) {
        ResourceLocation skinLocation = target.func_110306_p();
        mc.func_110434_K().func_110577_a(skinLocation);
        GlStateManager.func_179094_E();
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.func_179147_l();
        Gui.func_152125_a((int)((int)x), (int)((int)y), (float)u, (float)v, (int)uWidth, (int)vHeight, (int)width, (int)height, (float)tileWidth, (float)tileHeight);
        GlStateManager.func_179121_F();
    }

    public void drawOutlinedRoundedRect(double x, double y, double width, double height, double radius, float lineWidth, int color) {
        int i;
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        GL11.glPushAttrib((int)0);
        GL11.glScaled((double)0.5, (double)0.5, (double)0.5);
        x *= 2.0;
        y *= 2.0;
        width *= 2.0;
        height *= 2.0;
        GL11.glLineWidth((float)lineWidth);
        GL11.glDisable((int)3553);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)2);
        for (i = 0; i <= 90; i += 3) {
            GL11.glVertex2d((double)(x + radius + Math.sin((double)i * Math.PI / 180.0) * (radius * -1.0)), (double)(y + radius + Math.cos((double)i * Math.PI / 180.0) * (radius * -1.0)));
        }
        for (i = 90; i <= 180; i += 3) {
            GL11.glVertex2d((double)(x + radius + Math.sin((double)i * Math.PI / 180.0) * (radius * -1.0)), (double)(height - radius + Math.cos((double)i * Math.PI / 180.0) * (radius * -1.0)));
        }
        for (i = 0; i <= 90; i += 3) {
            GL11.glVertex2d((double)(width - radius + Math.sin((double)i * Math.PI / 180.0) * radius), (double)(height - radius + Math.cos((double)i * Math.PI / 180.0) * radius));
        }
        for (i = 90; i <= 180; i += 3) {
            GL11.glVertex2d((double)(width - radius + Math.sin((double)i * Math.PI / 180.0) * radius), (double)(y + radius + Math.cos((double)i * Math.PI / 180.0) * radius));
        }
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glScaled((double)2.0, (double)2.0, (double)2.0);
        GL11.glPopAttrib();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
        GlStateManager.func_179117_G();
    }

    public void drawRoundedRect(double x, double y, double width, double height, double radius, int color) {
        int i;
        GlStateManager.func_179094_E();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        GL11.glPushAttrib((int)0);
        GL11.glScaled((double)0.5, (double)0.5, (double)0.5);
        x *= 2.0;
        y *= 2.0;
        width *= 2.0;
        height *= 2.0;
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)9);
        for (i = 0; i <= 90; i += 3) {
            GL11.glVertex2d((double)(x + radius + Math.sin((double)i * Math.PI / 180.0) * radius * -1.0), (double)(y + radius + Math.cos((double)i * Math.PI / 180.0) * radius * -1.0));
        }
        for (i = 90; i <= 180; i += 3) {
            GL11.glVertex2d((double)(x + radius + Math.sin((double)i * Math.PI / 180.0) * radius * -1.0), (double)(height - radius + Math.cos((double)i * Math.PI / 180.0) * radius * -1.0));
        }
        for (i = 0; i <= 90; i += 3) {
            GL11.glVertex2d((double)(width - radius + Math.sin((double)i * Math.PI / 180.0) * radius), (double)(height - radius + Math.cos((double)i * Math.PI / 180.0) * radius));
        }
        for (i = 90; i <= 180; i += 3) {
            GL11.glVertex2d((double)(width - radius + Math.sin((double)i * Math.PI / 180.0) * radius), (double)(y + radius + Math.cos((double)i * Math.PI / 180.0) * radius));
        }
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glScaled((double)2.0, (double)2.0, (double)2.0);
        GL11.glPopAttrib();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
        GlStateManager.func_179117_G();
    }

    public static enum HealthColor {
        Rainbow,
        Auto;

    }
}

