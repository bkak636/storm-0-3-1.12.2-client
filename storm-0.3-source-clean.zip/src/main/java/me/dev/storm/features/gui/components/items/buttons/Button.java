/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.audio.ISound
 *  net.minecraft.client.audio.PositionedSoundRecord
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.util.SoundEvent
 */
package me.dev.storm.features.gui.components.items.buttons;

import me.dev.storm.Storm;
import me.dev.storm.features.gui.StormGui;
import me.dev.storm.features.gui.components.Component;
import me.dev.storm.features.gui.components.items.Item;
import me.dev.storm.features.modules.client.ClickGui;
import me.dev.storm.util.RenderUtil;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundEvent;

public class Button
extends Item {
    private boolean state;

    public Button(String name) {
        super(name);
        this.height = 15;
    }

    @Override
    public void drawScreen(int n, int n2, float f) {
        boolean dotgod;
        boolean newStyle = ClickGui.getInstance().style.getValue() == ClickGui.Style.NEW;
        boolean future = ClickGui.getInstance().style.getValue() == ClickGui.Style.FUTURE;
        boolean bl = dotgod = ClickGui.getInstance().style.getValue() == ClickGui.Style.DOTGOD;
        if (newStyle) {
            RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width, this.y + (float)this.height - 0.5f, !this.isHovering(n, n2) ? 0x11555555 : -2007673515);
            Storm.textManager.drawStringWithShadow(this.getName(), this.x + 2.3f, this.y - 2.0f - (float)StormGui.getInstance().getTextOffset(), this.getState() ? Storm.colorManager.getCurrentGui(240) : -1);
            if (ClickGui.getInstance().box2.getValue().booleanValue()) {
                RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(n, n2) ? Storm.colorManager.getColorWithAlpha(Storm.moduleManager.getModuleByClass(ClickGui.class).hoverAlpha.getValue()) : Storm.colorManager.getColorWithAlpha(Storm.moduleManager.getModuleByClass(ClickGui.class).alpha.getValue())) : (!this.isHovering(n, n2) ? 0x35555555 : -2007673515));
            } else if (dotgod) {
                RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(n, n2) ? Storm.colorManager.getCurrentWithAlpha(65) : Storm.colorManager.getCurrentWithAlpha(90)) : (!this.isHovering(n, n2) ? Storm.colorManager.getCurrentWithAlpha(26) : Storm.colorManager.getCurrentWithAlpha(35)));
                Storm.textManager.drawStringWithShadow(this.getName(), this.x + 2.3f, this.y - 2.0f - (float)StormGui.getInstance().getTextOffset(), this.getState() ? Storm.colorManager.getCurrentGui(240) : 0xB0B0B0);
            } else if (future) {
                RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(n, n2) ? Storm.colorManager.getCurrentWithAlpha(99) : Storm.colorManager.getCurrentWithAlpha(120)) : (!this.isHovering(n, n2) ? Storm.colorManager.getCurrentWithAlpha(26) : Storm.colorManager.getCurrentWithAlpha(55)));
                Storm.textManager.drawStringWithShadow(this.getName(), this.x + 2.3f, this.y - 2.0f - (float)StormGui.getInstance().getTextOffset(), this.getState() ? -1 : -5592406);
                Storm.textManager.drawStringWithShadow(this.getName(), this.x + 1.3f, this.y - 1.0f - (float)StormGui.getClickGui().getTextOffset(), this.getState() ? -1 : -159240);
            }
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && this.isHovering(mouseX, mouseY)) {
            this.onMouseClick();
        }
    }

    public void onMouseClick() {
        this.state = !this.state;
        this.toggle();
        mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a((SoundEvent)SoundEvents.field_187909_gi, (float)1.0f));
    }

    public void toggle() {
    }

    public boolean getState() {
        return this.state;
    }

    @Override
    public int getHeight() {
        return 14;
    }

    public boolean isHovering(int mouseX, int mouseY) {
        for (Component component : StormGui.getClickGui().getComponents()) {
            if (!component.drag) continue;
            return false;
        }
        return (float)mouseX >= this.getX() && (float)mouseX <= this.getX() + (float)this.getWidth() && (float)mouseY >= this.getY() && (float)mouseY <= this.getY() + (float)this.height;
    }
}

