/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.GuiConfirmOpenLink
 *  net.minecraft.client.gui.GuiControls
 *  net.minecraft.client.gui.GuiCustomizeSkin
 *  net.minecraft.client.gui.GuiGameOver
 *  net.minecraft.client.gui.GuiIngameMenu
 *  net.minecraft.client.gui.GuiOptions
 *  net.minecraft.client.gui.GuiScreenOptionsSounds
 *  net.minecraft.client.gui.GuiVideoSettings
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.gui.inventory.GuiEditSign
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.client.GuiModList
 */
package me.dev.storm.features.modules.client;

import me.dev.storm.features.gui.StormGui;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.client.ClickGui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiConfirmOpenLink;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiCustomizeSkin;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.GuiModList;

public class GuiBlur
extends Module {
    public GuiBlur() {
        super("GuiBlur", "blur in gui", Module.Category.CLIENT, true, false, false);
    }

    @Override
    public String onUpdate() {
        if (GuiBlur.mc.field_71441_e != null) {
            if (!(ClickGui.getInstance().isEnabled() || GuiBlur.mc.field_71462_r instanceof GuiContainer || GuiBlur.mc.field_71462_r instanceof GuiChat || GuiBlur.mc.field_71462_r instanceof GuiConfirmOpenLink || GuiBlur.mc.field_71462_r instanceof GuiEditSign || GuiBlur.mc.field_71462_r instanceof GuiGameOver || GuiBlur.mc.field_71462_r instanceof GuiOptions || GuiBlur.mc.field_71462_r instanceof GuiIngameMenu || GuiBlur.mc.field_71462_r instanceof GuiVideoSettings || GuiBlur.mc.field_71462_r instanceof GuiScreenOptionsSounds || GuiBlur.mc.field_71462_r instanceof GuiControls || GuiBlur.mc.field_71462_r instanceof GuiCustomizeSkin || GuiBlur.mc.field_71462_r instanceof GuiModList || GuiBlur.mc.field_71462_r instanceof StormGui)) {
                if (GuiBlur.mc.field_71460_t.func_147706_e() != null) {
                    GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
                }
            } else if (OpenGlHelper.field_148824_g && mc.func_175606_aa() instanceof EntityPlayer) {
                if (GuiBlur.mc.field_71460_t.func_147706_e() != null) {
                    GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
                }
                try {
                    GuiBlur.mc.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            } else if (GuiBlur.mc.field_71460_t.func_147706_e() != null && GuiBlur.mc.field_71462_r == null) {
                GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
            }
        }
        return null;
    }
}

