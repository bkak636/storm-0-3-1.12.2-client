/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.util.EnumHand
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.misc;

import me.dev.storm.event.events.Packet;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class SwingHand
extends Module {
    private Setting<Hand> hand = this.register(new Setting<Hand>("Hand", Hand.OFFHAND));

    public SwingHand() {
        super("SwingHand", "Changes the hand you swing with", Module.Category.MISC, false, false, false);
    }

    @Override
    public String onUpdate() {
        if (SwingHand.mc.field_71441_e == null) {
            return null;
        }
        if (this.hand.getValue().equals((Object)Hand.OFFHAND)) {
            SwingHand.mc.field_71439_g.field_184622_au = EnumHand.OFF_HAND;
        }
        if (this.hand.getValue().equals((Object)Hand.MAINHAND)) {
            SwingHand.mc.field_71439_g.field_184622_au = EnumHand.MAIN_HAND;
        }
        return null;
    }

    @SubscribeEvent
    public void onPacket(Packet event) {
        if (SwingHand.nullCheck() || event.getType() == Packet.Type.INCOMING) {
            return;
        }
        if (event.getPacket() instanceof CPacketAnimation) {
            event.setCanceled(true);
        }
    }

    public static enum Hand {
        OFFHAND,
        MAINHAND,
        PACKETSWING;

    }
}

