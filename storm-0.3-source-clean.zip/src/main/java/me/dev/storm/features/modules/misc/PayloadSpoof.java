/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.server.SPacketChat
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.misc;

import me.dev.storm.event.events.PacketEvent;
import me.dev.storm.features.command.Command;
import me.dev.storm.features.modules.Module;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PayloadSpoof
extends Module {
    public PayloadSpoof() {
        super("PayloadSpoof", "blocks payloads and exploits", Module.Category.MISC, true, false, false);
    }

    @SubscribeEvent(priority=EventPriority.HIGHEST)
    public void onPacketRecieve(PacketEvent.Receive event) {
        String text;
        if (event.getPacket() instanceof SPacketChat && ((text = ((SPacketChat)event.getPacket()).func_148915_c().func_150260_c()).contains("${") || text.contains("$<") || text.contains("$:-") || text.contains("jndi:ldap"))) {
            Command.sendMessage("[PayloadSpoof] Blocked message: " + text);
            event.setCanceled(true);
        }
    }
}

