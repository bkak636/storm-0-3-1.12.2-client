/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketPlayerDigging$Action
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3i
 */
package me.dev.storm.features.modules.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.BlockUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

public class CevBreaker
extends Module {
    private List<BlockPos> placeList = new ArrayList<BlockPos>();
    private boolean placing = false;
    private boolean placedCrystal = false;
    private boolean breaking = false;
    private boolean broke = false;
    private EntityPlayer _target = null;
    private BlockPos b_crystal = null;
    private BlockPos breakPos = null;
    private int attempts = 0;
    private Setting<type> targetType = this.register(new Setting<type>("Target", type.NEAREST));
    private Setting<mode> breakMode = this.register(new Setting<mode>("Break Mode", mode.Vanilla));
    private Setting<Boolean> rotate = this.register(new Setting<Boolean>("Rotate", true));
    private Setting<Integer> startDelay = this.register(new Setting<Integer>("Start Delay", 1, 0, 10));
    private Setting<Integer> breakDelay = this.register(new Setting<Integer>("Break Delay", 1, 0, 10));
    private Setting<Integer> crystalDelay = this.register(new Setting<Integer>("Crystal Delay", 1, 0, 10));
    private Setting<Integer> hitDelay = this.register(new Setting<Integer>("Hit Delay", 3, 0, 10));
    private Setting<Integer> tinpoDelay = this.register(new Setting<Integer>("Tinpo Delay", 3, 0, 10));
    private int timer = 0;

    public CevBreaker() {
        super("Cev", "Attack Ceil", Module.Category.COMBAT, true, false, false);
    }

    @Override
    public void onEnable() {
        this.init();
    }

    private void init() {
        this.placeList = new ArrayList<BlockPos>();
        this._target = null;
        this.b_crystal = null;
        this.placedCrystal = false;
        this.placing = false;
        this.breaking = false;
        this.broke = false;
        this.timer = 0;
        this.attempts = 0;
    }

    @Override
    public void onTick() {
        int pix = this.findItem(Items.field_151046_w);
        int crystal = this.findItem(Items.field_185158_cP);
        int obby = this.findMaterials(Blocks.field_150343_Z);
        if (pix == -1 || crystal == -1 || obby == -1) {
            this.disable();
            return;
        }
        if (this._target == null) {
            if (this.targetType.getValue() == type.NEAREST) {
                this._target = CevBreaker.mc.field_71441_e.field_73010_i.stream().filter(p -> p.func_145782_y() != CevBreaker.mc.field_71439_g.func_145782_y()).min(Comparator.comparing(p -> Float.valueOf(p.func_70032_d((Entity)CevBreaker.mc.field_71439_g)))).orElse(null);
            }
            if (this._target == null) {
                this.disable();
                return;
            }
        }
        if (this.placeList.size() == 0 && !this.placing) {
            this.searchSpace();
            if (this.placeList.size() == 0) {
                this.disable();
                return;
            }
        }
        if (!this.placedCrystal) {
            if (this.timer < this.startDelay.getValue()) {
                ++this.timer;
                return;
            }
            this.timer = 0;
            this.doPlace(obby, crystal);
        } else if (!this.breaking) {
            if (this.timer < this.breakDelay.getValue()) {
                ++this.timer;
                return;
            }
            this.timer = 0;
            if (this.breakMode.getValue() == mode.Vanilla) {
                CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = pix;
                CevBreaker.mc.field_71442_b.func_78765_e();
                CevBreaker.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                CevBreaker.mc.field_71442_b.func_180512_c(this.breakPos, EnumFacing.DOWN);
            } else {
                CevBreaker.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                CevBreaker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.breakPos, EnumFacing.DOWN));
                CevBreaker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.breakPos, EnumFacing.DOWN));
            }
            this.breaking = true;
        } else if (this.breaking && !this.broke) {
            if (this.getBlock(this.breakPos) == Blocks.field_150350_a) {
                this.broke = true;
            }
        } else if (this.broke) {
            if (this.timer < this.crystalDelay.getValue()) {
                ++this.timer;
                return;
            }
            this.timer = 0;
            Entity bcrystal = CevBreaker.mc.field_71441_e.field_72996_f.stream().filter(e -> e instanceof EntityEnderCrystal).min(Comparator.comparing(c -> Float.valueOf(c.func_70032_d((Entity)this._target)))).orElse(null);
            if (bcrystal == null) {
                if (this.attempts < this.hitDelay.getValue()) {
                    ++this.attempts;
                    return;
                }
                if (this.attempts < this.tinpoDelay.getValue()) {
                    ++this.attempts;
                    return;
                }
                this.placedCrystal = false;
                this.placeList.add(this.breakPos);
                this.breaking = false;
                this.broke = false;
                this.attempts = 0;
            } else {
                CevBreaker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(bcrystal));
                this.placedCrystal = false;
                this.placeList.add(this.breakPos);
                this.breaking = false;
                this.broke = false;
                this.attempts = 0;
            }
        }
    }

    private void doPlace(int obby, int crystal) {
        this.placing = true;
        if (this.placeList.size() != 0) {
            int oldslot = CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c;
            CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = obby;
            CevBreaker.mc.field_71442_b.func_78765_e();
            BlockUtil.placeBlock(this.placeList.get(0), EnumHand.MAIN_HAND, this.rotate.getValue(), false, false);
            this.placeList.remove(0);
            CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = oldslot;
        } else if (!this.placedCrystal) {
            int oldslot = CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c;
            if (crystal != 999) {
                CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = crystal;
            }
            CevBreaker.mc.field_71442_b.func_78765_e();
            CevBreaker.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(this.b_crystal, EnumFacing.UP, CevBreaker.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            CevBreaker.mc.field_71439_g.field_71071_by.field_70461_c = oldslot;
            this.placedCrystal = true;
        }
    }

    private void searchSpace() {
        BlockPos ppos = CevBreaker.mc.field_71439_g.func_180425_c();
        BlockPos tpos = new BlockPos(this._target.field_70165_t, this._target.field_70163_u, this._target.field_70161_v);
        this.placeList = new ArrayList<BlockPos>();
        BlockPos[] offset = new BlockPos[]{new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1)};
        if (this.getBlock(new BlockPos(tpos.func_177958_n(), tpos.func_177956_o() + 3, tpos.func_177952_p())) != Blocks.field_150350_a || this.getBlock(new BlockPos(tpos.func_177958_n(), tpos.func_177956_o() + 4, tpos.func_177952_p())) != Blocks.field_150350_a) {
            return;
        }
        ArrayList<BlockPos> posList = new ArrayList<BlockPos>();
        for (int i = 0; i < offset.length; ++i) {
            BlockPos offsetPos = tpos.func_177971_a((Vec3i)offset[i]);
            Block block = this.getBlock(offsetPos);
            if (block == Blocks.field_150350_a || block instanceof BlockLiquid) continue;
            posList.add(offsetPos);
        }
        BlockPos base = posList.stream().max(Comparator.comparing(b -> this._target.func_70011_f((double)b.func_177958_n(), (double)b.func_177956_o(), (double)b.func_177952_p()))).orElse(null);
        if (base == null) {
            return;
        }
        this.placeList.add(base);
        this.placeList.add(base.func_177982_a(0, 1, 0));
        this.placeList.add(base.func_177982_a(0, 2, 0));
        this.placeList.add(tpos.func_177982_a(0, 2, 0));
        this.breakPos = tpos.func_177982_a(0, 2, 0);
        this.b_crystal = tpos.func_177982_a(0, 2, 0);
    }

    private int findMaterials(Block b) {
        for (int i = 0; i < 9; ++i) {
            if (!(CevBreaker.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock) || ((ItemBlock)CevBreaker.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b()).func_179223_d() != b) continue;
            return i;
        }
        return -1;
    }

    private int findItem(Item item) {
        if (item == Items.field_185158_cP && CevBreaker.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
            return 999;
        }
        for (int i = 0; i < 9; ++i) {
            if (CevBreaker.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() != item) continue;
            return i;
        }
        return -1;
    }

    private Block getBlock(BlockPos b) {
        return CevBreaker.mc.field_71441_e.func_180495_p(b).func_177230_c();
    }

    @Override
    public String getDisplayInfo() {
        return "Active";
    }

    public static enum type {
        NEAREST,
        LOOKING;

    }

    public static enum mode {
        Vanilla,
        Packet;

    }
}

