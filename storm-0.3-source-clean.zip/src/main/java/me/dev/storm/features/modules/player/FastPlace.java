/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemExpBottle
 */
package me.dev.storm.features.modules.player;

import me.dev.storm.features.modules.Module;
import me.dev.storm.util.InventoryUtil;
import net.minecraft.item.ItemExpBottle;

public class FastPlace
extends Module {
    public FastPlace() {
        super("FastPlace", "Fast everything.", Module.Category.PLAYER, true, false, false);
    }

    @Override
    public String onUpdate() {
        if (FastPlace.fullNullCheck()) {
            return null;
        }
        if (InventoryUtil.holdingItem(ItemExpBottle.class)) {
            FastPlace.mc.field_71467_ac = 0;
        }
        return null;
    }
}

