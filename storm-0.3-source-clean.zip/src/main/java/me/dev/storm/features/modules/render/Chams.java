/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.client.event.RenderPlayerEvent$Pre
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.render;

import java.awt.Color;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Chams
extends Module {
    public static Chams INSTANCE;
    public final Setting<Boolean> fill = this.register(new Setting<Boolean>("Fill", true));
    public final Setting<Boolean> xqz = this.register(new Setting<Boolean>("XQZ", true));
    public final Setting<Boolean> wireframe = this.register(new Setting<Boolean>("Wireframe", true));
    public final Setting<Boolean> model = this.register(new Setting<Boolean>("Model", false));
    public final Setting<Boolean> self = this.register(new Setting<Boolean>("Self", true));
    public final Setting<Boolean> noInterp = this.register(new Setting<Boolean>("NoInterp", false));
    public final Setting<Boolean> sneak = this.register(new Setting<Boolean>("Sneak", false));
    public final Setting<Boolean> glint = this.register(new Setting<Boolean>("Glint", false));
    public final Setting<Float> lineWidth = this.register(new Setting<Float>("LineWidth", Float.valueOf(1.0f), Float.valueOf(0.1f), Float.valueOf(3.0f)));
    public final Setting<Boolean> rainbow = this.register(new Setting<Boolean>("Rainbow", false));
    public final Setting<Color> color = this.register(new Setting<Color>("Color", new Color(132, 132, 241, 150)));
    public final Setting<Color> lineColor = this.register(new Setting<Color>("LineColor", new Color(255, 255, 255)));
    public final Setting<Color> modelColor = this.register(new Setting<Color>("ModelColor", new Color(125, 125, 213, 150)));

    public Chams() {
        super("Chams", "Shows safe spots.", Module.Category.RENDER, false, false, false);
        INSTANCE = this;
    }

    @Override
    public String getInfo() {
        String info = null;
        if (this.fill.getValue().booleanValue()) {
            info = "Fill";
        } else if (this.wireframe.getValue().booleanValue()) {
            info = "Wireframe";
        }
        if (this.wireframe.getValue().booleanValue() && this.fill.getValue().booleanValue()) {
            info = "Both";
        }
        return info;
    }

    @SubscribeEvent
    public void onRenderPlayerEvent(RenderPlayerEvent.Pre event) {
        event.getEntityPlayer().field_70737_aN = 0;
    }
}

