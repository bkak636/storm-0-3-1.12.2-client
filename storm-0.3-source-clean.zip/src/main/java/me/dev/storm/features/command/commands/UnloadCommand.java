/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.command.commands;

import me.dev.storm.Storm;
import me.dev.storm.features.command.Command;

public class UnloadCommand
extends Command {
    public UnloadCommand() {
        super("unload", new String[0]);
    }

    @Override
    public void execute(String[] commands) {
        Storm.unload(true);
    }
}

