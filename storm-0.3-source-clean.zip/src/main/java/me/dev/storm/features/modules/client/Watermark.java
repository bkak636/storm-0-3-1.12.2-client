/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraftforge.client.event.RenderGameOverlayEvent$ElementType
 *  net.minecraftforge.client.event.RenderGameOverlayEvent$Post
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.features.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.Objects;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.ColorUtil;
import me.dev.storm.util.MathUtil;
import me.dev.storm.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class Watermark
extends Module {
    public Setting<Integer> posY = this.register(new Setting<Integer>("PosY", 2, 0, 512));
    public Setting<Double> barPosY = this.register(new Setting<Double>("BarPosY", 0.0, -2.0, 15.0));
    public Setting<Double> textPosY = this.register(new Setting<Double>("TextPosY", 0.0, -6.0, 3.0));
    public Setting<Color> bgC = this.register(new Setting<Color>("BackgroundColor", new Color(20, 20, 20, 255)));
    public Setting<Color> bC = this.register(new Setting<Color>("BorderColor", new Color(0, 0, 20, 255)));
    public Setting<Color> fC = this.register(new Setting<Color>("FirstLineColor", new Color(135, 135, 255, 255)));
    public Setting<Color> sC = this.register(new Setting<Color>("SecondLineColor", new Color(0, 255, 255, 255)));
    public Setting<Color> tC = this.register(new Setting<Color>("ThirdLineColor", new Color(135, 135, 255, 255)));
    public Setting<Color> foC = this.register(new Setting<Color>("FourthLineColor", new Color(0, 255, 255, 255)));

    public Watermark() {
        super("Watermark [CT]", "Hot csgo watermark", Module.Category.CLIENT, true, false, false);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post event) {
        if (Watermark.nullCheck()) {
            return;
        }
        if (event.getType() == RenderGameOverlayEvent.ElementType.HOTBAR) {
            String ping = this.getPing((EntityPlayer)Watermark.mc.field_71439_g) + "ms";
            String fpsText = Minecraft.field_71470_ab + "fps ";
            String name = Watermark.mc.field_71439_g.getDisplayNameString();
            String server = Minecraft.func_71410_x().func_71356_B() ? "singleplayer".toLowerCase() : Watermark.mc.func_147104_D().field_78845_b.toLowerCase();
            String Storm2 = ChatFormatting.DARK_BLUE + "storm" + ChatFormatting.WHITE + " v0.3";
            String text = Storm2 + " | " + server + " | " + ping + " | " + fpsText;
            float width = Minecraft.func_71410_x().field_71466_p.func_78256_a(text) + 6;
            int height = 20;
            int posX = 2;
            int posY = this.posY.getValue();
            double barPosY = this.barPosY.getValue();
            double textPosY = this.textPosY.getValue();
            RenderUtil.drawRectangleCorrectly(posX - 4, posY - 4, (int)(width + 10.0f), height + 5, ColorUtil.toRGBA(this.bC.getValue().getRed(), this.bC.getValue().getGreen(), this.bC.getValue().getBlue(), this.bC.getValue().getAlpha()));
            RenderUtil.drawRectangleCorrectly(posX - 4, posY - 4, (int)(width + 11.0f), height + 5, ColorUtil.toRGBA(this.bC.getValue().getRed(), this.bC.getValue().getGreen(), this.bC.getValue().getBlue(), this.bC.getValue().getAlpha()));
            Watermark.drawRect(posX, posY, (float)posX + width + 1.0f, posY + height, new Color(this.bgC.getValue().getRed(), this.bgC.getValue().getGreen(), this.bgC.getValue().getBlue(), this.bgC.getValue().getAlpha()).getRGB());
            Watermark.drawRect((double)posX + 2.5, (double)posY + 2.5, (double)((float)posX + width) - 0.5, (double)posY + 4.5, new Color(this.bgC.getValue().getRed(), this.bgC.getValue().getGreen(), this.bgC.getValue().getBlue(), this.bgC.getValue().getAlpha()).getRGB());
            Watermark.drawGradientSideways(3.0, (double)posY + barPosY + 3.0, 4.0f + width / 3.0f, (double)posY + barPosY + 4.0, new Color(this.fC.getValue().getRed(), this.fC.getValue().getGreen(), this.fC.getValue().getBlue(), this.fC.getValue().getAlpha()).getRGB(), new Color(this.sC.getValue().getRed(), this.sC.getValue().getGreen(), this.sC.getValue().getBlue(), this.sC.getValue().getAlpha()).getRGB());
            Watermark.drawGradientSideways(3.0f + width / 3.0f, (double)posY + barPosY + 3.0, 4.0f + width / 3.0f * 2.0f, (double)posY + barPosY + 4.0, new Color(this.sC.getValue().getRed(), this.sC.getValue().getGreen(), this.sC.getValue().getBlue(), this.sC.getValue().getAlpha()).getRGB(), new Color(this.tC.getValue().getRed(), this.tC.getValue().getGreen(), this.tC.getValue().getBlue(), this.tC.getValue().getAlpha()).getRGB());
            Watermark.drawGradientSideways(3.0f + width / 3.0f * 2.0f, (double)posY + barPosY + 3.0, width / 3.0f * 3.0f + 1.0f, (double)posY + barPosY + 4.0, new Color(this.tC.getValue().getRed(), this.tC.getValue().getGreen(), this.tC.getValue().getBlue(), this.tC.getValue().getAlpha()).getRGB(), new Color(this.foC.getValue().getRed(), this.foC.getValue().getGreen(), this.foC.getValue().getBlue(), this.foC.getValue().getAlpha()).getRGB());
            Minecraft.func_71410_x().field_71466_p.func_175063_a(text, (float)(4 + posX), (float)(8.0 + ((double)posY + textPosY)), -1);
        }
    }

    public static void drawRect(double left, double top, double right, double bottom, int color) {
        if (left < right) {
            double i = left;
            left = right;
            right = i;
        }
        if (top < bottom) {
            double j = top;
            top = bottom;
            bottom = j;
        }
        float f3 = (float)(color >> 24 & 0xFF) / 255.0f;
        float f = (float)(color >> 16 & 0xFF) / 255.0f;
        float f1 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f2 = (float)(color & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179131_c((float)f, (float)f1, (float)f2, (float)f3);
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(left, bottom, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(right, bottom, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(right, top, 0.0).func_181675_d();
        bufferBuilder.func_181662_b(left, top, 0.0).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void drawGradientSideways(double left, double top, double right, double bottom, int col1, int col2) {
        float f = (float)(col1 >> 24 & 0xFF) / 255.0f;
        float f1 = (float)(col1 >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(col1 >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(col1 & 0xFF) / 255.0f;
        float f4 = (float)(col2 >> 24 & 0xFF) / 255.0f;
        float f5 = (float)(col2 >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(col2 >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(col2 & 0xFF) / 255.0f;
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        GL11.glPushMatrix();
        GL11.glBegin((int)7);
        GL11.glColor4f((float)f1, (float)f2, (float)f3, (float)f);
        GL11.glVertex2d((double)left, (double)top);
        GL11.glVertex2d((double)left, (double)bottom);
        GL11.glColor4f((float)f5, (float)f6, (float)f7, (float)f4);
        GL11.glVertex2d((double)right, (double)bottom);
        GL11.glVertex2d((double)right, (double)top);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
    }

    private int getPing(EntityPlayer player) {
        int ping = 0;
        try {
            ping = (int)MathUtil.clamp((float)Objects.requireNonNull(mc.func_147114_u()).func_175102_a(player.func_110124_au()).func_178853_c(), 1.0f, 300.0f);
        }
        catch (NullPointerException nullPointerException) {
            // empty catch block
        }
        return ping;
    }
}

