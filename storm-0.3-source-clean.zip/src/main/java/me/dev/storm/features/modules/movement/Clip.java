/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.math.MathHelper
 */
package me.dev.storm.features.modules.movement;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;

public class Clip
extends Module {
    public static Clip INSTANCE;
    private final Setting<Integer> timeout = this.register(new Setting<Integer>("Timeout", 5, 1, 10));
    private int packets;

    public static boolean isMoving() {
        return Clip.mc.field_71474_y.field_74351_w.func_151470_d() || Clip.mc.field_71474_y.field_74368_y.func_151470_d() || Clip.mc.field_71474_y.field_74370_x.func_151470_d() || Clip.mc.field_71474_y.field_74366_z.func_151470_d();
    }

    public Clip() {
        super("Clip", "Clips into blocks nearby to prevent crystal damage.", Module.Category.MOVEMENT, true, false, false);
        INSTANCE = this;
    }

    @Override
    public void onDisable() {
        this.packets = 0;
    }

    @Override
    public String getDisplayInfo() {
        return ChatFormatting.GRAY + "[" + ChatFormatting.RESET + ChatFormatting.WHITE + String.valueOf(this.packets).toLowerCase() + ChatFormatting.RESET + ChatFormatting.GRAY + "]";
    }

    @Override
    public String onUpdate() {
        if (Clip.isMoving()) {
            this.toggle();
            return null;
        }
        if (Clip.mc.field_71441_e.func_184144_a((Entity)Clip.mc.field_71439_g, Clip.mc.field_71439_g.func_174813_aQ().func_72314_b(0.01, 0.0, 0.01)).size() < 2) {
            Clip.mc.field_71439_g.func_70107_b(this.roundToClosest(Clip.mc.field_71439_g.field_70165_t, Math.floor(Clip.mc.field_71439_g.field_70165_t) + 0.301, Math.floor(Clip.mc.field_71439_g.field_70165_t) + 0.699), Clip.mc.field_71439_g.field_70163_u, this.roundToClosest(Clip.mc.field_71439_g.field_70161_v, Math.floor(Clip.mc.field_71439_g.field_70161_v) + 0.301, Math.floor(Clip.mc.field_71439_g.field_70161_v) + 0.699));
            this.packets = 0;
        } else if (Clip.mc.field_71439_g.field_70173_aa % this.timeout.getValue() == 0) {
            Clip.mc.field_71439_g.func_70107_b(Clip.mc.field_71439_g.field_70165_t + MathHelper.func_151237_a((double)(this.roundToClosest(Clip.mc.field_71439_g.field_70165_t, Math.floor(Clip.mc.field_71439_g.field_70165_t) + 0.241, Math.floor(Clip.mc.field_71439_g.field_70165_t) + 0.759) - Clip.mc.field_71439_g.field_70165_t), (double)-0.03, (double)0.03), Clip.mc.field_71439_g.field_70163_u, Clip.mc.field_71439_g.field_70161_v + MathHelper.func_151237_a((double)(this.roundToClosest(Clip.mc.field_71439_g.field_70161_v, Math.floor(Clip.mc.field_71439_g.field_70161_v) + 0.241, Math.floor(Clip.mc.field_71439_g.field_70161_v) + 0.759) - Clip.mc.field_71439_g.field_70161_v), (double)-0.03, (double)0.03));
            Clip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Clip.mc.field_71439_g.field_70165_t, Clip.mc.field_71439_g.field_70163_u, Clip.mc.field_71439_g.field_70161_v, true));
            Clip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(this.roundToClosest(Clip.mc.field_71439_g.field_70165_t, Math.floor(Clip.mc.field_71439_g.field_70165_t) + 0.23, Math.floor(Clip.mc.field_71439_g.field_70165_t) + 0.77), Clip.mc.field_71439_g.field_70163_u, this.roundToClosest(Clip.mc.field_71439_g.field_70161_v, Math.floor(Clip.mc.field_71439_g.field_70161_v) + 0.23, Math.floor(Clip.mc.field_71439_g.field_70161_v) + 0.77), true));
            ++this.packets;
        }
        return null;
    }

    private double roundToClosest(double num, double low, double high) {
        double d2 = high - num;
        double d1 = num - low;
        if (d2 > d1) {
            return low;
        }
        return high;
    }
}

