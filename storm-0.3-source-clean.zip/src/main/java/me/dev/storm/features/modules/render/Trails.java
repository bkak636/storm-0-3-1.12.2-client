/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderPearl
 *  net.minecraft.entity.item.EntityExpBottle
 *  net.minecraft.entity.projectile.EntityArrow
 *  net.minecraft.entity.projectile.EntityPotion
 *  net.minecraft.util.math.Vec3d
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.features.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import me.dev.storm.event.events.Render3DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class Trails
extends Module {
    private final Setting<Float> thick = this.register(new Setting<Float>("LineWidth", Float.valueOf(1.5f), Float.valueOf(0.1f), Float.valueOf(5.0f)));
    private final Setting<Boolean> pearl = this.register(new Setting<Boolean>("Pearl", true));
    private final Setting<Boolean> arrows = this.register(new Setting<Boolean>("Arrows", true));
    private final Setting<Boolean> exp = this.register(new Setting<Boolean>("Experience Bottles", true));
    private final Setting<Boolean> potions = this.register(new Setting<Boolean>("Splash Potions", true));
    private final Setting<Boolean> render = this.register(new Setting<Boolean>("Render", true));
    private final Setting<Double> aliveTime = this.register(new Setting<Double>("Fade Time", 5.0, 0.0, 20.0));
    private final Setting<Integer> rDelay = this.register(new Setting<Integer>("Delay Before Render", 120, 0, 360));
    private final Setting<Color> colorC = this.register(new Setting<Color>("Color", new Color(40, 192, 255, 255)));
    private final HashMap<UUID, List<Vec3d>> poses = new HashMap();
    private final HashMap<UUID, Double> time = new HashMap();

    public Trails() {
        super("Trails", "Draws a line behind projectiles", Module.Category.RENDER, true, false, false);
    }

    @Override
    public String onUpdate() {
        List<Vec3d> v;
        UUID toRemove = null;
        for (UUID uuid : this.time.keySet()) {
            if (this.time.get(uuid) <= 0.0) {
                this.poses.remove(uuid);
                toRemove = uuid;
                continue;
            }
            this.time.replace(uuid, this.time.get(uuid) - 0.05);
        }
        if (toRemove != null) {
            this.time.remove(toRemove);
            toRemove = null;
        }
        if (this.arrows.getValue().booleanValue() || this.exp.getValue().booleanValue() || this.pearl.getValue().booleanValue() || this.potions.getValue().booleanValue()) {
            for (Entity e : Trails.mc.field_71441_e.func_72910_y()) {
                if (!(e instanceof EntityArrow) && !(e instanceof EntityExpBottle) && !(e instanceof EntityPotion)) continue;
                if (!this.poses.containsKey(e.func_110124_au())) {
                    this.poses.put(e.func_110124_au(), new ArrayList<Vec3d>(Collections.singletonList(e.func_174791_d())));
                    this.time.put(e.func_110124_au(), 0.05);
                    continue;
                }
                this.time.replace(e.func_110124_au(), 0.05);
                v = this.poses.get(e.func_110124_au());
                v.add(e.func_174791_d());
            }
        }
        for (Entity e : Trails.mc.field_71441_e.func_72910_y()) {
            if (!(e instanceof EntityEnderPearl)) continue;
            if (!this.poses.containsKey(e.func_110124_au())) {
                this.poses.put(e.func_110124_au(), new ArrayList<Vec3d>(Collections.singletonList(e.func_174791_d())));
                this.time.put(e.func_110124_au(), this.aliveTime.getValue());
                continue;
            }
            this.time.replace(e.func_110124_au(), this.aliveTime.getValue());
            v = this.poses.get(e.func_110124_au());
            v.add(e.func_174791_d());
        }
        return null;
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (!this.render.getValue().booleanValue() && !this.poses.isEmpty()) {
            return;
        }
        GL11.glPushMatrix();
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glLineWidth((float)this.thick.getValue().floatValue());
        for (UUID uuid : this.poses.keySet()) {
            if (this.poses.get(uuid).size() <= 2) continue;
            int delay = 0;
            GL11.glBegin((int)1);
            for (int i = 1; i < this.poses.get(uuid).size(); ++i) {
                delay += this.rDelay.getValue().intValue();
                GL11.glColor4d((double)((float)this.colorC.getValue().getRed() / 255.0f), (double)((float)this.colorC.getValue().getGreen() / 255.0f), (double)((float)this.colorC.getValue().getBlue() / 255.0f), (double)((float)this.colorC.getValue().getAlpha() / 255.0f));
                List<Vec3d> pos = this.poses.get(uuid);
                GL11.glVertex3d((double)(pos.get((int)i).field_72450_a - Trails.mc.func_175598_ae().field_78730_l), (double)(pos.get((int)i).field_72448_b - Trails.mc.func_175598_ae().field_78731_m), (double)(pos.get((int)i).field_72449_c - Trails.mc.func_175598_ae().field_78728_n));
                GL11.glVertex3d((double)(pos.get((int)(i - 1)).field_72450_a - Trails.mc.func_175598_ae().field_78730_l), (double)(pos.get((int)(i - 1)).field_72448_b - Trails.mc.func_175598_ae().field_78731_m), (double)(pos.get((int)(i - 1)).field_72449_c - Trails.mc.func_175598_ae().field_78728_n));
            }
            GL11.glEnd();
        }
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }
}

