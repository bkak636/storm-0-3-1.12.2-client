/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.math.Vec3d
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.features.modules.render;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import me.dev.storm.event.events.JumpEvent;
import me.dev.storm.event.events.Render3DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.render.jumpanim.aAnimation;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.Timer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class JumpCircle
extends Module {
    public static aAnimation jumpanim = new aAnimation();
    static List<Circle> circles = new ArrayList<Circle>();
    public Setting<Float> range2 = this.register(new Setting<Float>("Radius", Float.valueOf(1.0f), Float.valueOf(0.1f), Float.valueOf(3.0f)));
    public Setting<Float> range = this.register(new Setting<Float>("Radius2", Float.valueOf(3.0f), Float.valueOf(0.1f), Float.valueOf(3.0f)));
    public Setting<Integer> lifetime = this.register(new Setting<Integer>("Live", 1000, 1, 10000));
    public Setting<mode> Mode = this.register(new Setting<mode>("Mode", mode.Jump));
    public Timer timer = new Timer();
    boolean check = false;

    public JumpCircle() {
        super("JumpCircle", "jump circle render", Module.Category.RENDER, true, false, false);
    }

    @Override
    public String onUpdate() {
        if (JumpCircle.mc.field_71439_g.field_70124_G && this.Mode.getValue() == mode.Landing && this.check) {
            circles.add(new Circle(new Vec3d(JumpCircle.mc.field_71439_g.field_70165_t, JumpCircle.mc.field_71439_g.field_70163_u + 0.0625, JumpCircle.mc.field_71439_g.field_70161_v)));
            this.check = false;
        }
        jumpanim.update();
        for (Circle circle : circles) {
            circle.update();
        }
        circles.removeIf(Circle::update);
        return null;
    }

    @SubscribeEvent
    public void onJump(JumpEvent e) {
        if (this.Mode.getValue() == mode.Jump) {
            circles.add(new Circle(new Vec3d(JumpCircle.mc.field_71439_g.field_70165_t, JumpCircle.mc.field_71439_g.field_70163_u + 0.0625, JumpCircle.mc.field_71439_g.field_70161_v)));
        }
        this.check = true;
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        GlStateManager.func_179094_E();
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3008);
        GL11.glEnable((int)2848);
        GlStateManager.func_179117_G();
        GL11.glShadeModel((int)7425);
        double ix = -(JumpCircle.mc.field_71439_g.field_70142_S + (JumpCircle.mc.field_71439_g.field_70165_t - JumpCircle.mc.field_71439_g.field_70142_S) * (double)mc.func_184121_ak());
        double iy = -(JumpCircle.mc.field_71439_g.field_70137_T + (JumpCircle.mc.field_71439_g.field_70163_u - JumpCircle.mc.field_71439_g.field_70137_T) * (double)mc.func_184121_ak());
        double iz = -(JumpCircle.mc.field_71439_g.field_70136_U + (JumpCircle.mc.field_71439_g.field_70161_v - JumpCircle.mc.field_71439_g.field_70136_U) * (double)mc.func_184121_ak());
        GL11.glTranslated((double)ix, (double)iy, (double)iz);
        Collections.reverse(circles);
        try {
            for (Circle c : circles) {
                int blue;
                int green;
                int red;
                int clr;
                double stage;
                int i;
                double x = c.position().field_72450_a;
                double y = c.position().field_72448_b;
                double z = c.position().field_72449_c;
                float k = (float)c.timer.getPassedTimeMs() / (float)this.lifetime.getValue().intValue();
                float start = k * this.range.getValue().floatValue();
                float end = k * this.range2.getValue().floatValue();
                float middle = (start + end) / 2.0f;
                GL11.glBegin((int)8);
                for (i = 0; i <= 360; i += 5) {
                    stage = (double)(i + 90) / 360.0;
                    clr = jumpanim.getColor(stage);
                    red = clr >> 16 & 0xFF;
                    green = clr >> 8 & 0xFF;
                    blue = clr & 0xFF;
                    GL11.glColor4f((float)((float)red / 255.0f), (float)((float)green / 255.0f), (float)((float)blue / 255.0f), (float)0.0f);
                    GL11.glVertex3d((double)(x + Math.cos(Math.toRadians(i)) * (double)start), (double)y, (double)(z + Math.sin(Math.toRadians(i)) * (double)start));
                    GL11.glColor4f((float)((float)red / 255.0f), (float)((float)green / 255.0f), (float)((float)blue / 255.0f), (float)(1.0f - (float)c.timer.getPassedTimeMs() / (float)this.lifetime.getValue().intValue()));
                    GL11.glVertex3d((double)(x + Math.cos(Math.toRadians(i)) * (double)middle), (double)y, (double)(z + Math.sin(Math.toRadians(i)) * (double)middle));
                }
                GL11.glEnd();
                GL11.glBegin((int)8);
                for (i = 0; i <= 360; i += 5) {
                    stage = (double)(i + 90) / 360.0;
                    clr = jumpanim.getColor(stage);
                    red = clr >> 16 & 0xFF;
                    green = clr >> 8 & 0xFF;
                    blue = clr & 0xFF;
                    GL11.glColor4f((float)((float)red / 255.0f), (float)((float)green / 255.0f), (float)((float)blue / 255.0f), (float)(1.0f - (float)c.timer.getPassedTimeMs() / (float)this.lifetime.getValue().intValue()));
                    GL11.glVertex3d((double)(x + Math.cos(Math.toRadians(i)) * (double)middle), (double)y, (double)(z + Math.sin(Math.toRadians(i)) * (double)middle));
                    GL11.glColor4f((float)((float)red / 255.0f), (float)((float)green / 255.0f), (float)((float)blue / 255.0f), (float)0.0f);
                    GL11.glVertex3d((double)(x + Math.cos(Math.toRadians(i)) * (double)end), (double)y, (double)(z + Math.sin(Math.toRadians(i)) * (double)end));
                }
                GL11.glEnd();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3008);
        GlStateManager.func_179117_G();
        Collections.reverse(circles);
        GlStateManager.func_179121_F();
        GL11.glShadeModel((int)7424);
    }

    class Circle {
        private final Vec3d vec;
        Timer timer = new Timer();

        Circle(Vec3d vec) {
            this.vec = vec;
            this.timer.reset();
        }

        Vec3d position() {
            return this.vec;
        }

        public boolean update() {
            return this.timer.passedMs(JumpCircle.this.lifetime.getValue().intValue());
        }
    }

    public static enum mode {
        Jump,
        Landing;

    }
}

