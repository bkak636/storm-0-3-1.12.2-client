/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.features.modules.Module;

public class Step
extends Module {
    public Step() {
        super("Step", "Step.", Module.Category.MOVEMENT, true, false, false);
    }
}

