/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.client;

import java.awt.Color;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;

public class ModuleColor
extends Module {
    public static final Setting<Color> daColor = new Setting<Color>("Color", new Color(255, 255, 255, 255));

    public ModuleColor() {
        super("Color", "Allows you to customize the client's main colors.", Module.Category.CLIENT, true, false, false);
    }

    public static int getColor() {
        return new Color(daColor.getValue().getRed(), daColor.getValue().getGreen(), daColor.getValue().getBlue()).getRGB();
    }
}

