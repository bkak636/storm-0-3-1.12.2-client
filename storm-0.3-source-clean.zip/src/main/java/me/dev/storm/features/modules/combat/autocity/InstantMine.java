/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockObsidian
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketPlayerDigging$Action
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.combat.autocity;

import java.awt.Color;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import me.dev.storm.event.events.PacketEvent;
import me.dev.storm.event.events.PlayerDamageBlockEvent;
import me.dev.storm.event.events.Render3DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.combat.AntiBurrow;
import me.dev.storm.features.setting.Bind;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.Timer;
import me.dev.storm.util.trollhack.BlockUtil;
import me.dev.storm.util.trollhack.FadeUtils;
import me.dev.storm.util.trollhack.InventoryUtil;
import me.dev.storm.util.trollhack.RenderUtil2;
import me.dev.storm.util.trollhack.RotationUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class InstantMine
extends Module {
    boolean switched = false;
    Timer retryTime;
    private final Setting<Boolean> rotate;
    private final Setting<Integer> red;
    public final Setting<Boolean> db;
    public final Setting<Bind> bind;
    public static BlockPos breakPos;
    private final Timer breakSuccess;
    private static InstantMine INSTANCE;
    private final Setting<Boolean> render2;
    private final Setting<Integer> alpha;
    public FadeUtils secondFade;
    public static BlockPos breakPos2;
    public FadeUtils firstFade;
    private final Setting<Boolean> retry;
    private final Setting<Integer> green;
    private final Setting<Boolean> placeCrystal;
    public static final List<Block> godBlocks;
    private final Setting<Integer> pos1BoxAlpha;
    private final Setting<Integer> pos1FillAlpha;
    private final Setting<Boolean> ghostHand;
    public final Setting<Boolean> attackCrystal = this.register(new Setting<Boolean>("Attack Crystal", Boolean.TRUE));
    private EnumFacing facing;
    private final Setting<Boolean> render;
    int slotMain2;
    public final Setting<Float> health;
    private final Setting<Integer> blue;
    private final Setting<Boolean> crystalOnBreak;
    static int ticked;
    private boolean empty = false;
    private final Setting<Boolean> instant;
    private final Setting<Integer> alpha2;
    private boolean cancelStart = false;

    private boolean lambda$new$0(Float f) {
        return this.db.getValue();
    }

    @Override
    public String onUpdate() {
        int n;
        if (InstantMine.fullNullCheck()) {
            return null;
        }
        if (InstantMine.mc.field_71439_g.func_184812_l_()) {
            return null;
        }
        this.slotMain2 = InstantMine.mc.field_71439_g.field_71071_by.field_70461_c;
        if (ticked == 0) {
            breakPos2 = null;
        }
        if (breakPos2 != null) {
            if (ticked >= 60 || ticked > 1) {
                // empty if block
            }
            if (++ticked > 30 || ticked > 13 && InstantMine.mc.field_71441_e.func_180495_p(breakPos2).func_177230_c() == Blocks.field_150477_bB || ticked >= 3 && InstantMine.mc.field_71441_e.func_180495_p(breakPos2).func_177230_c() == Blocks.field_150321_G) {
                if (InstantMine.mc.field_71439_g.func_184587_cr()) {
                    this.resetMine();
                } else {
                    this.switchMine();
                }
            }
            if (InstantMine.mc.field_71441_e.func_175623_d(breakPos2)) {
                this.resetMine();
                breakPos2 = null;
                ticked = 0;
            }
        } else {
            ticked = 0;
        }
        if (ticked > 80) {
            this.resetMine();
            breakPos2 = null;
            ticked = 0;
        }
        if (breakPos == null) {
            return null;
        }
        if (!this.instant.getValue().booleanValue() && InstantMine.mc.field_71441_e.func_175623_d(breakPos)) {
            breakPos = null;
            return null;
        }
        if (!this.cancelStart) {
            return null;
        }
        if (InstantMine.mc.field_71439_g.func_70011_f((double)breakPos.func_177958_n(), (double)breakPos.func_177956_o(), (double)breakPos.func_177952_p()) > 6.0) {
            return null;
        }
        if (this.retry.getValue().booleanValue() && this.retryTime.passedMs(1000L) && !this.instant.getValue().booleanValue()) {
            this.retryTime.reset();
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, breakPos, this.facing));
            this.cancelStart = true;
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
        }
        if (this.attackCrystal.getValue().booleanValue() && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150350_a) {
            InstantMine.attackcrystal(this.rotate.getValue());
        }
        if (this.bind.getValue().isDown() && this.placeCrystal.getValue().booleanValue() && InventoryUtil.findHotbarBlock(BlockObsidian.class) != -1 && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150350_a) {
            n = InventoryUtil.findHotbarBlock(BlockObsidian.class);
            int n2 = InstantMine.mc.field_71439_g.field_71071_by.field_70461_c;
            this.switchToSlot(n);
            BlockUtil.placeBlock(breakPos, EnumHand.MAIN_HAND, false, true, false);
            this.switchToSlot(n2);
        }
        if (InventoryUtil.getItemHotbar(Items.field_185158_cP) != -1 && this.placeCrystal.getValue().booleanValue() && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150343_Z && !breakPos.equals((Object)AntiBurrow.pos)) {
            if (this.empty) {
                BlockUtil.placeCrystalOnBlock3(breakPos, EnumHand.MAIN_HAND, true, false, true);
            } else if (!this.crystalOnBreak.getValue().booleanValue()) {
                BlockUtil.placeCrystalOnBlock3(breakPos, EnumHand.MAIN_HAND, true, false, true);
            }
        }
        if (godBlocks.contains(InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c())) {
            return null;
        }
        if (this.rotate.getValue().booleanValue()) {
            RotationUtil.facePos(breakPos);
        }
        if (InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() != Blocks.field_150321_G) {
            if (this.ghostHand.getValue().booleanValue() && InventoryUtil.getItemHotbar(Items.field_151046_w) != -1 && InventoryUtil.getItemHotbars(Items.field_151046_w) != -1) {
                n = InstantMine.mc.field_71439_g.field_71071_by.field_70461_c;
                if (InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150343_Z) {
                    if (!this.breakSuccess.passedMs(1400L)) {
                        return null;
                    }
                    InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.getItemHotbar(Items.field_151046_w);
                    InstantMine.mc.field_71442_b.func_78765_e();
                    InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                    InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = n;
                    InstantMine.mc.field_71442_b.func_78765_e();
                    return null;
                }
                InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.getItemHotbar(Items.field_151046_w);
                InstantMine.mc.field_71442_b.func_78765_e();
                InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = n;
                InstantMine.mc.field_71442_b.func_78765_e();
                return null;
            }
        } else if (this.ghostHand.getValue().booleanValue() && InventoryUtil.getItemHotbar(Items.field_151048_u) != -1 && InventoryUtil.getItemHotbars(Items.field_151048_u) != -1) {
            n = InstantMine.mc.field_71439_g.field_71071_by.field_70461_c;
            InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.getItemHotbar(Items.field_151048_u);
            InstantMine.mc.field_71442_b.func_78765_e();
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
            InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = n;
            InstantMine.mc.field_71442_b.func_78765_e();
            return null;
        }
        InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
        return null;
    }

    @Override
    public void onRender3D(Render3DEvent render3DEvent) {
        if (!InstantMine.mc.field_71439_g.func_184812_l_()) {
            AxisAlignedBB axisAlignedBB;
            double d;
            double d2;
            double d3;
            double d4;
            double d5;
            double d6;
            AxisAlignedBB axisAlignedBB2;
            if (breakPos2 != null) {
                axisAlignedBB2 = InstantMine.mc.field_71441_e.func_180495_p(breakPos2).func_185918_c((World)InstantMine.mc.field_71441_e, breakPos2);
                d6 = axisAlignedBB2.field_72340_a + (axisAlignedBB2.field_72336_d - axisAlignedBB2.field_72340_a) / 2.0;
                d5 = axisAlignedBB2.field_72338_b + (axisAlignedBB2.field_72337_e - axisAlignedBB2.field_72338_b) / 2.0;
                d4 = axisAlignedBB2.field_72339_c + (axisAlignedBB2.field_72334_f - axisAlignedBB2.field_72339_c) / 2.0;
                d3 = this.secondFade.easeOutQuad() * (axisAlignedBB2.field_72336_d - d6);
                d2 = this.secondFade.easeOutQuad() * (axisAlignedBB2.field_72337_e - d5);
                d = this.secondFade.easeOutQuad() * (axisAlignedBB2.field_72334_f - d4);
                axisAlignedBB = new AxisAlignedBB(d6 - d3, d5 - d2, d4 - d, d6 + d3, d5 + d2, d4 + d);
                if (breakPos != null) {
                    if (!breakPos2.equals((Object)breakPos)) {
                        RenderUtil2.drawBBBox(axisAlignedBB, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), this.alpha.getValue());
                        RenderUtil2.drawBBFill(axisAlignedBB, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha2.getValue()), this.alpha2.getValue());
                    }
                } else {
                    RenderUtil2.drawBBBox(axisAlignedBB, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), this.alpha.getValue());
                    RenderUtil2.drawBBFill(axisAlignedBB, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha2.getValue()), this.alpha2.getValue());
                }
            }
            if (this.cancelStart && breakPos != null) {
                if (godBlocks.contains(InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c())) {
                    this.empty = true;
                }
                axisAlignedBB2 = InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_185918_c((World)InstantMine.mc.field_71441_e, breakPos);
                d6 = axisAlignedBB2.field_72340_a + (axisAlignedBB2.field_72336_d - axisAlignedBB2.field_72340_a) / 2.0;
                d5 = axisAlignedBB2.field_72338_b + (axisAlignedBB2.field_72337_e - axisAlignedBB2.field_72338_b) / 2.0;
                d4 = axisAlignedBB2.field_72339_c + (axisAlignedBB2.field_72334_f - axisAlignedBB2.field_72339_c) / 2.0;
                d3 = this.firstFade.easeOutQuad() * (axisAlignedBB2.field_72336_d - d6);
                d2 = this.firstFade.easeOutQuad() * (axisAlignedBB2.field_72337_e - d5);
                d = this.firstFade.easeOutQuad() * (axisAlignedBB2.field_72334_f - d4);
                axisAlignedBB = new AxisAlignedBB(d6 - d3, d5 - d2, d4 - d, d6 + d3, d5 + d2, d4 + d);
                if (this.render.getValue().booleanValue()) {
                    RenderUtil2.drawBBFill(axisAlignedBB, new Color(this.empty ? 0 : 255, this.empty ? 255 : 0, 0, 255), this.pos1FillAlpha.getValue());
                }
                if (this.render2.getValue().booleanValue()) {
                    RenderUtil2.drawBBBox(axisAlignedBB, new Color(this.empty ? 0 : 255, this.empty ? 255 : 0, 0, 255), this.pos1BoxAlpha.getValue());
                }
            }
        }
    }

    private static Float lambda$attackcrystal$7(Entity entity) {
        return Float.valueOf(InstantMine.mc.field_71439_g.func_70032_d(entity));
    }

    private boolean lambda$new$2(Integer n) {
        return this.render.getValue();
    }

    private boolean lambda$new$4(Object object) {
        return this.placeCrystal.getValue();
    }

    private boolean lambda$new$5(Boolean bl) {
        return this.placeCrystal.getValue();
    }

    private boolean lambda$new$1(Boolean bl) {
        return this.instant.getValue() == false;
    }

    public InstantMine() {
        super("InstantMine", "legacy", Module.Category.COMBAT, true, false, false);
        this.db = this.register(new Setting<Boolean>("Silent Double", Boolean.TRUE));
        this.health = this.register(new Setting<Float>("Health", Float.valueOf(18.0f), Float.valueOf(0.0f), Float.valueOf(35.9f), this::lambda$new$0));
        this.breakSuccess = new Timer();
        this.instant = this.register(new Setting<Boolean>("Instant", true));
        this.retry = this.register(new Setting<Boolean>("Retry", Boolean.valueOf(true), this::lambda$new$1));
        this.rotate = this.register(new Setting<Boolean>("Rotate", true));
        this.ghostHand = this.register(new Setting<Boolean>("GhostHand", Boolean.TRUE));
        this.render = this.register(new Setting<Boolean>("Pos1Fill", true));
        this.pos1FillAlpha = this.register(new Setting<Integer>("Pos1FillAlpha", Integer.valueOf(30), Integer.valueOf(0), Integer.valueOf(255), this::lambda$new$2));
        this.render2 = this.register(new Setting<Boolean>("Pos1Box", true));
        this.pos1BoxAlpha = this.register(new Setting<Integer>("Pos1BoxAlpha", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(255), this::lambda$new$3));
        this.placeCrystal = this.register(new Setting<Boolean>("Place Crystal", Boolean.TRUE));
        this.bind = this.register(new Setting<Object>("ObsidianBind", new Bind(-1), this::lambda$new$4));
        this.crystalOnBreak = this.register(new Setting<Boolean>("Crystal on Break", Boolean.TRUE, this::lambda$new$5));
        this.red = this.register(new Setting<Integer>("Pos2Red", 255, 0, 255));
        this.green = this.register(new Setting<Integer>("Pos2Green", 255, 0, 255));
        this.blue = this.register(new Setting<Integer>("Pos2Blue", 255, 0, 255));
        this.alpha = this.register(new Setting<Integer>("Pos2BoxAlpha", 150, 0, 255));
        this.alpha2 = this.register(new Setting<Integer>("Pos2FillAlpha", 70, 0, 255));
        this.firstFade = new FadeUtils(1500L);
        this.secondFade = new FadeUtils(1500L);
        this.retryTime = new Timer();
        this.setInstance();
    }

    @SubscribeEvent
    public void onBlockEvent(PlayerDamageBlockEvent playerDamageBlockEvent) {
        if (InstantMine.fullNullCheck()) {
            return;
        }
        if (InstantMine.mc.field_71439_g.func_184812_l_()) {
            return;
        }
        if (!BlockUtil.canBreak(playerDamageBlockEvent.pos)) {
            return;
        }
        if (breakPos != null) {
            if (breakPos.func_177958_n() == playerDamageBlockEvent.pos.func_177958_n() && breakPos.func_177956_o() == playerDamageBlockEvent.pos.func_177956_o() && breakPos.func_177952_p() == playerDamageBlockEvent.pos.func_177952_p()) {
                return;
            }
            if (breakPos.equals((Object)breakPos2)) {
                this.secondFade.reset();
            }
        }
        this.firstFade.reset();
        this.empty = false;
        this.cancelStart = false;
        breakPos = playerDamageBlockEvent.pos;
        this.breakSuccess.reset();
        this.facing = playerDamageBlockEvent.facing;
        if (breakPos == null) {
            return;
        }
        InstantMine.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, breakPos, this.facing));
        this.cancelStart = true;
        InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
        playerDamageBlockEvent.setCanceled(true);
        if (breakPos2 == null) {
            ticked = 1;
            breakPos2 = playerDamageBlockEvent.pos;
            this.secondFade.reset();
        }
    }

    private void setInstance() {
        INSTANCE = this;
    }

    private void switchToSlot(int n) {
        InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = n;
        InstantMine.mc.field_71442_b.func_78765_e();
    }

    private void switchMine() {
        if (InstantMine.mc.field_71439_g.func_110143_aJ() + InstantMine.mc.field_71439_g.func_110139_bj() >= this.health.getValue().floatValue()) {
            if (this.db.getValue().booleanValue()) {
                if (InstantMine.mc.field_71441_e.func_180495_p(breakPos2).func_177230_c() == Blocks.field_150321_G) {
                    if (InventoryUtil.getItemHotbar(Items.field_151048_u) != -1) {
                        InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(InventoryUtil.getItemHotbars(Items.field_151048_u)));
                        this.switched = true;
                        ++ticked;
                    }
                } else if (InventoryUtil.getItemHotbar(Items.field_151046_w) != -1) {
                    InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(InventoryUtil.getItemHotbars(Items.field_151046_w)));
                    this.switched = true;
                    ++ticked;
                }
            }
        } else if (this.switched) {
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.slotMain2));
            this.switched = false;
        }
    }

    private static boolean lambda$attackcrystal$6(Entity entity) {
        return entity instanceof EntityEnderCrystal && !entity.field_70128_L;
    }

    public static void attackcrystal(boolean bl) {
        for (Entity entity : InstantMine.mc.field_71441_e.field_72996_f.stream().filter(InstantMine::lambda$attackcrystal$6).sorted(Comparator.comparing(InstantMine::lambda$attackcrystal$7)).collect(Collectors.toList())) {
            if (!(entity instanceof EntityEnderCrystal) || !(entity.func_174818_b(breakPos) <= 2.0)) continue;
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(entity));
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
            if (!bl) continue;
            RotationUtil.facePos(new BlockPos(entity.field_70165_t, entity.field_70163_u + 0.5, entity.field_70161_v));
        }
    }

    private void resetMine() {
        if (this.switched) {
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.slotMain2));
            this.switched = false;
        }
    }

    public static InstantMine INSTANCE() {
        if (INSTANCE != null) {
            return INSTANCE;
        }
        INSTANCE = new InstantMine();
        return INSTANCE;
    }

    private boolean lambda$new$3(Integer n) {
        return this.render2.getValue();
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send send) {
        if (InstantMine.fullNullCheck()) {
            return;
        }
        if (InstantMine.mc.field_71439_g.func_184812_l_()) {
            return;
        }
        if (!(send.getPacket() instanceof CPacketPlayerDigging)) {
            return;
        }
        CPacketPlayerDigging cPacketPlayerDigging = (CPacketPlayerDigging)send.getPacket();
        if (cPacketPlayerDigging.func_180762_c() != CPacketPlayerDigging.Action.START_DESTROY_BLOCK) {
            return;
        }
        send.setCanceled(this.cancelStart);
    }

    static {
        godBlocks = Arrays.asList(Blocks.field_150350_a, Blocks.field_150356_k, Blocks.field_150353_l, Blocks.field_150358_i, Blocks.field_150355_j, Blocks.field_150357_h);
        breakPos2 = null;
        ticked = 0;
        INSTANCE = new InstantMine();
    }
}

