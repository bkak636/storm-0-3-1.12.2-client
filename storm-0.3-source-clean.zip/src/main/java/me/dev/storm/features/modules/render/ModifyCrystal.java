/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.render;

import me.dev.storm.Storm;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;

public class ModifyCrystal
extends Module {
    public static Setting<Float> spin = new Setting<Float>("Spin", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(10.0f));
    public static Setting<Float> bounce = new Setting<Float>("Bounce", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(10.0f));
    public static Setting<Float> scale = new Setting<Float>("Scale", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(1.0f));

    public ModifyCrystal() {
        super("Modify Crystal", "STOP DMING ME AAAAAAAAAAA", Module.Category.RENDER, true, false, false);
        this.register(spin);
        this.register(scale);
        this.register(bounce);
    }

    public static float[] getSpeed() {
        float[] fArray;
        if (Storm.moduleManager.isModuleEnabled("Modify Crystal")) {
            float[] fArray2 = new float[2];
            fArray2[0] = spin.getValue().floatValue();
            fArray = fArray2;
            fArray2[1] = bounce.getValue().floatValue();
        } else {
            float[] fArray3 = new float[2];
            fArray3[0] = 1.0f;
            fArray = fArray3;
            fArray3[1] = 1.0f;
        }
        return fArray;
    }
}

