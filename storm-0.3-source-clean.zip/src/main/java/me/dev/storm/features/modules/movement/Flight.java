/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.features.modules.Module;

public class Flight
extends Module {
    public Flight() {
        super("Flight", "Flight.", Module.Category.MOVEMENT, true, false, false);
    }
}

