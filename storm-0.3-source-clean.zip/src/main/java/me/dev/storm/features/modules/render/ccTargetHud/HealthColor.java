/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.render.ccTargetHud;

public enum HealthColor {
    Rainbow,
    Auto;

}

