/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.render;

import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;

public class ViewModel
extends Module {
    public final Setting<Integer> translateX = this.register(new Setting<Integer>("TranslateX", 0, -200, 200));
    public final Setting<Integer> translateY = this.register(new Setting<Integer>("TranslateY", 0, -200, 200));
    public final Setting<Integer> translateZ = this.register(new Setting<Integer>("TranslateZ", 0, -200, 200));
    public final Setting<Integer> rotateX = this.register(new Setting<Integer>("RotateX", 0, -200, 200));
    public final Setting<Integer> rotateY = this.register(new Setting<Integer>("RotateY", 0, -200, 200));
    public final Setting<Integer> rotateZ = this.register(new Setting<Integer>("RotateZ", 0, -200, 200));
    public final Setting<Integer> scaleX = this.register(new Setting<Integer>("ScaleX", 100, 0, 200));
    public final Setting<Integer> scaleY = this.register(new Setting<Integer>("ScaleY", 100, 0, 200));
    public final Setting<Integer> scaleZ = this.register(new Setting<Integer>("ScaleZ", 100, 0, 200));
    public final Setting<Integer> alpha = this.register(new Setting<Integer>("Alpha", 100, 0, 200));
    public static ViewModel INSTANCE;

    public ViewModel() {
        super("ViewModel", "Modifies the items of your hands client side", Module.Category.RENDER, true, false, false);
        INSTANCE = this;
    }
}

