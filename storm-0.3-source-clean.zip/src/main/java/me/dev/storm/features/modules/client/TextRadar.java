/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 */
package me.dev.storm.features.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import me.dev.storm.Storm;
import me.dev.storm.event.events.Render2DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.client.ClickGui;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.ColorUtil;
import me.dev.storm.util.EntityUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class TextRadar
extends Module {
    private final Setting<Integer> amount = this.register(new Setting<Integer>("PlayerCount", 10, 1, 100));
    public Setting<Integer> Y = this.register(new Setting<Integer>("Y", 5, 0, 550));
    public static TextRadar INSTANCE = new TextRadar();
    private int color;

    public TextRadar() {
        super("TextRadar", "Shows players in render distance on hud", Module.Category.CLIENT, false, false, false);
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        int i = 0;
        for (Object o : TextRadar.mc.field_71441_e.field_72996_f) {
            if (!(o instanceof EntityPlayer) || o == TextRadar.mc.field_71439_g) continue;
            if (++i > this.amount.getValue()) {
                return;
            }
            EntityPlayer entity = (EntityPlayer)o;
            float health = Math.round(entity.func_110143_aJ()) + Math.round(entity.func_110139_bj());
            DecimalFormat dfDistance = new DecimalFormat("#.#");
            dfDistance.setRoundingMode(RoundingMode.CEILING);
            StringBuilder distanceSB = new StringBuilder();
            this.color = ColorUtil.toRGBA(ClickGui.getInstance().red.getValue(), ClickGui.getInstance().green.getValue(), ClickGui.getInstance().blue.getValue());
            String health_str = String.valueOf(health);
            health_str = health_str.replace(".0", "");
            int distanceInt = (int)EntityUtil.mc.field_71439_g.func_70032_d((Entity)entity);
            String distance = dfDistance.format(distanceInt);
            if (distanceInt >= 25) {
                distanceSB.append(ChatFormatting.GREEN);
            } else if (distanceInt > 10) {
                distanceSB.append(ChatFormatting.GOLD);
            } else if (distanceInt >= 50) {
                distanceSB.append(ChatFormatting.GRAY);
            } else {
                distanceSB.append(ChatFormatting.RED);
            }
            distanceSB.append(distance);
            String heal = (double)health >= 12.0 ? " " + ChatFormatting.GREEN + health_str + "" : ((double)health >= 4.0 ? " " + ChatFormatting.YELLOW + health_str + "" : " " + ChatFormatting.RED + health_str + "");
            String name = entity.func_146103_bH().getName();
            String str = heal + " " + ChatFormatting.RESET;
            if (Storm.friendManager.isFriend(entity.func_70005_c_())) {
                Storm.textManager.drawString(str + ChatFormatting.AQUA + name + " " + distanceSB.toString() + ChatFormatting.WHITE, -2.0f, this.Y.getValue() + i * 10, this.color, true);
                continue;
            }
            if (ClickGui.getInstance().rainbow.getValue().booleanValue() && ClickGui.getInstance().rainbowModeHud.getValue() == ClickGui.rainbowMode.Static) {
                Storm.textManager.drawString(str + name + " " + distanceSB.toString() + ChatFormatting.GRAY + "", -2.0f, this.Y.getValue() + i * 10, ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
                continue;
            }
            Storm.textManager.drawString(str + name + " " + distanceSB.toString() + ChatFormatting.GRAY + "", -2.0f, this.Y.getValue() + i * 10, this.color, true);
        }
    }
}

