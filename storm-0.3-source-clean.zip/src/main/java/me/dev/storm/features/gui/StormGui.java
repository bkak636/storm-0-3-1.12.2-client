/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.ScaledResolution
 *  org.lwjgl.input.Mouse
 */
package me.dev.storm.features.gui;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import me.dev.storm.Storm;
import me.dev.storm.features.Feature;
import me.dev.storm.features.gui.components.Component;
import me.dev.storm.features.gui.components.items.Item;
import me.dev.storm.features.gui.components.items.buttons.ModuleButton;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.client.ClickGui;
import me.dev.storm.util.ParticleGenerator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

public class StormGui
extends GuiScreen {
    private static StormGui StormGui;
    private static StormGui INSTANCE;
    public static Minecraft mc;
    private final ArrayList<Component> components = new ArrayList();
    public static ParticleGenerator particleGenerator;
    int color;
    private StormGui ClickGuiMod;

    public StormGui() {
        this.color = new Color(ClickGui.getInstance().red.getValue(), ClickGui.getInstance().blue.getValue(), ClickGui.getInstance().green.getValue()).getRGB();
        this.setInstance();
        this.load();
    }

    public static StormGui getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new StormGui();
        }
        return INSTANCE;
    }

    public static StormGui getClickGui() {
        return StormGui.getInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    private void load() {
        int x = -84;
        for (final Module.Category category : Storm.moduleManager.getCategories()) {
            this.components.add(new Component(category.getName(), x += 110, 4, true){

                @Override
                public void setupItems() {
                    counter1 = new int[]{1};
                    Storm.moduleManager.getModulesByCategory(category).forEach(module -> {
                        if (!module.hidden) {
                            this.addButton(new ModuleButton((Module)module));
                        }
                    });
                }
            });
        }
        this.components.forEach(components -> components.getItems().sort(Comparator.comparing(Feature::getName)));
    }

    public void updateModule(Module module) {
        for (Component component : this.components) {
            for (Item item : component.getItems()) {
                if (!(item instanceof ModuleButton)) continue;
                ModuleButton button = (ModuleButton)item;
                Module mod = button.getModule();
                if (module == null || !module.equals(mod)) continue;
                button.initSettings();
            }
        }
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.checkMouseWheel();
        this.components.forEach(components -> components.drawScreen(mouseX, mouseY, partialTicks));
        particleGenerator.drawParticles(mouseX, mouseY);
        ScaledResolution res = new ScaledResolution(mc);
    }

    public void func_73864_a(int mouseX, int mouseY, int clickedButton) {
        this.components.forEach(components -> components.mouseClicked(mouseX, mouseY, clickedButton));
    }

    public void func_146286_b(int mouseX, int mouseY, int releaseButton) {
        this.components.forEach(components -> components.mouseReleased(mouseX, mouseY, releaseButton));
    }

    public boolean func_73868_f() {
        return false;
    }

    public final ArrayList<Component> getComponents() {
        return this.components;
    }

    public void checkMouseWheel() {
        int dWheel = Mouse.getDWheel();
        if (dWheel < 0) {
            this.components.forEach(component -> component.setY(component.getY() - 10));
        } else if (dWheel > 0) {
            this.components.forEach(component -> component.setY(component.getY() + 10));
        }
    }

    public int getTextOffset() {
        return -6;
    }

    public Component getComponentByName(String name) {
        for (Component component : this.components) {
            if (!component.getName().equalsIgnoreCase(name)) continue;
            return component;
        }
        return null;
    }

    public void func_73869_a(char typedChar, int keyCode) throws IOException {
        super.func_73869_a(typedChar, keyCode);
        this.components.forEach(component -> component.onKeyTyped(typedChar, keyCode));
    }

    public static int getRainbowInt(float seconds, float saturation, float brightness, long index) {
        float hue = (float)((System.currentTimeMillis() + index) % (long)((int)(seconds * 1000.0f))) / (seconds * 1000.0f);
        int color = Color.HSBtoRGB(hue, saturation, brightness);
        return color;
    }

    static {
        INSTANCE = new StormGui();
        mc = Minecraft.func_71410_x();
        particleGenerator = new ParticleGenerator(200, me.dev.storm.features.gui.StormGui.mc.field_71443_c, me.dev.storm.features.gui.StormGui.mc.field_71440_d);
    }
}

