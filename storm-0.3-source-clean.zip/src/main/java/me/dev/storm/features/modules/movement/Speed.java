/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.MobEffects
 *  net.minecraftforge.fml.common.Mod$EventHandler
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.event.events.UpdateEvent;
import me.dev.storm.event.events.trollgod.MoveEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.init.MobEffects;
import net.minecraftforge.fml.common.Mod;

public class Speed
extends Module {
    private final Setting<Boolean> placeHolder = this.register(new Setting<Boolean>("Dummy", true));
    private int stage = 1;
    private double moveSpeed;
    private double lastDist;

    public Speed() {
        super("Speed", "Trollgod speed!!!!", Module.Category.MOVEMENT, false, false, false);
    }

    @Override
    public void onEnable() {
        if (Speed.mc.field_71439_g == null) {
            return;
        }
        this.setSuffix("Strafe");
        this.lastDist = 0.0;
    }

    @Override
    public void onDisable() {
        if (Speed.mc.field_71439_g == null) {
            return;
        }
    }

    @Mod.EventHandler
    public void onUpdate(UpdateEvent event) {
        if (this.placeHolder.getValue().booleanValue()) {
            return;
        }
        this.lastDist = Math.sqrt((Speed.mc.field_71439_g.field_70165_t - Speed.mc.field_71439_g.field_70169_q) * (Speed.mc.field_71439_g.field_70165_t - Speed.mc.field_71439_g.field_70169_q) + (Speed.mc.field_71439_g.field_70161_v - Speed.mc.field_71439_g.field_70166_s) * (Speed.mc.field_71439_g.field_70161_v - Speed.mc.field_71439_g.field_70166_s));
        if (this.lastDist > 5.0) {
            this.lastDist = 0.0;
        }
    }

    @Mod.EventHandler
    public void onMotion(MoveEvent event) {
        if (this.placeHolder.getValue().booleanValue()) {
            return;
        }
        double forward = Speed.mc.field_71439_g.field_71158_b.field_192832_b;
        double strafe = Speed.mc.field_71439_g.field_71158_b.field_78902_a;
        double yaw = Speed.mc.field_71439_g.field_70177_z;
        switch (this.stage) {
            case 0: {
                ++this.stage;
                this.lastDist = 0.0;
                break;
            }
            case 2: {
                double motionY = 0.4;
                if (Speed.mc.field_71439_g.field_191988_bg == 0.0f && Speed.mc.field_71439_g.field_70702_br == 0.0f || !Speed.mc.field_71439_g.field_70122_E) break;
                if (Speed.mc.field_71439_g.func_70644_a(MobEffects.field_76430_j)) {
                    motionY += (double)((float)(Speed.mc.field_71439_g.func_70660_b(MobEffects.field_76430_j).func_76458_c() + 1) * 0.1f);
                }
                Speed.mc.field_71439_g.field_70181_x = motionY;
                event.setMotionY(Speed.mc.field_71439_g.field_70181_x);
                this.moveSpeed *= Speed.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c) ? 2.1499 : 2.1499;
                break;
            }
            case 3: {
                this.moveSpeed = this.lastDist - (Speed.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c) ? 0.658 : 0.71) * (this.lastDist - this.getBaseMoveSpeed());
                break;
            }
            default: {
                if ((Speed.mc.field_71441_e.func_184144_a((Entity)Speed.mc.field_71439_g, Speed.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, Speed.mc.field_71439_g.field_70181_x, 0.0)).size() > 0 || Speed.mc.field_71439_g.field_70124_G) && this.stage > 0) {
                    this.stage = Speed.mc.field_71439_g.field_191988_bg != 0.0f || Speed.mc.field_71439_g.field_70702_br != 0.0f ? 1 : 0;
                }
                this.moveSpeed = this.lastDist - this.lastDist / 159.0;
            }
        }
        this.moveSpeed = Math.max(this.moveSpeed, this.getBaseMoveSpeed());
        if (forward == 0.0 && strafe == 0.0) {
            event.setMotionX(0.0);
            event.setMotionZ(0.0);
        }
        if (forward != 0.0 && strafe != 0.0) {
            forward *= Math.sin(0.7853981633974483);
            strafe *= Math.cos(0.7853981633974483);
        }
        event.setMotionX((forward * this.moveSpeed * -Math.sin(Math.toRadians(yaw)) + strafe * this.moveSpeed * Math.cos(Math.toRadians(yaw))) * 0.99);
        event.setMotionZ((forward * this.moveSpeed * Math.cos(Math.toRadians(yaw)) - strafe * this.moveSpeed * -Math.sin(Math.toRadians(yaw))) * 0.99);
        ++this.stage;
    }

    private double getBaseMoveSpeed() {
        double baseSpeed = 0.272;
        if (Speed.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            int amplifier = Speed.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c).func_76458_c();
            baseSpeed *= 1.0 + 0.2 * (double)amplifier;
        }
        return baseSpeed;
    }

    @Override
    public String getDisplayInfo() {
        return "Active";
    }
}

