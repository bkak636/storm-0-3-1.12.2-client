/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class ReverseStep
extends Module {
    private static ReverseStep INSTANCE = new ReverseStep();
    private final Setting<Boolean> twoBlocks = this.register(new Setting<Boolean>("2Blocks", Boolean.FALSE));

    public ReverseStep() {
        super("ReverseStep", "ReverseStep.", Module.Category.MOVEMENT, true, false, false);
        this.setInstance();
    }

    public static ReverseStep getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ReverseStep();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public String onUpdate() {
        if (ReverseStep.fullNullCheck()) {
            return null;
        }
        IBlockState touchingState = ReverseStep.mc.field_71441_e.func_180495_p(new BlockPos(ReverseStep.mc.field_71439_g.field_70165_t, ReverseStep.mc.field_71439_g.field_70163_u, ReverseStep.mc.field_71439_g.field_70161_v).func_177979_c(2));
        IBlockState touchingState2 = ReverseStep.mc.field_71441_e.func_180495_p(new BlockPos(ReverseStep.mc.field_71439_g.field_70165_t, ReverseStep.mc.field_71439_g.field_70163_u, ReverseStep.mc.field_71439_g.field_70161_v).func_177979_c(3));
        if (ReverseStep.mc.field_71439_g.func_180799_ab() || ReverseStep.mc.field_71439_g.func_70090_H()) {
            return null;
        }
        if (touchingState.func_177230_c() == Blocks.field_150357_h || touchingState.func_177230_c() == Blocks.field_150343_Z) {
            if (ReverseStep.mc.field_71439_g.field_70122_E) {
                ReverseStep.mc.field_71439_g.field_70181_x -= 1.0;
            }
        } else if ((this.twoBlocks.getValue().booleanValue() && touchingState2.func_177230_c() == Blocks.field_150357_h || this.twoBlocks.getValue().booleanValue() && touchingState2.func_177230_c() == Blocks.field_150343_Z) && ReverseStep.mc.field_71439_g.field_70122_E) {
            ReverseStep.mc.field_71439_g.field_70181_x -= 1.0;
        }
        return null;
    }
}

