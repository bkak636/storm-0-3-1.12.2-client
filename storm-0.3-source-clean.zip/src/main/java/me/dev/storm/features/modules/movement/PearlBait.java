/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderPearl
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.network.play.server.SPacketSpawnObject
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.movement;

import java.util.Comparator;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import me.dev.storm.event.events.PacketEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PearlBait
extends Module {
    public final Setting<Boolean> guarantee = this.register(new Setting<Boolean>("Guarantee", true));
    private final Queue<CPacketPlayer> packets = new ConcurrentLinkedQueue<CPacketPlayer>();
    private int thrownPearlId = -1;

    public PearlBait() {
        super("PearlBait", "Forces your enemy to cry", Module.Category.MOVEMENT, true, false, false);
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        SPacketSpawnObject packet;
        if (event.getPacket() instanceof SPacketSpawnObject && (packet = (SPacketSpawnObject)event.getPacket()).func_148993_l() == 65) {
            PearlBait.mc.field_71441_e.field_73010_i.stream().min(Comparator.comparingDouble(p -> p.func_70011_f(packet.func_186880_c(), packet.func_186882_d(), packet.func_186881_e()))).ifPresent(player -> {
                if (player.equals((Object)PearlBait.mc.field_71439_g)) {
                    if (!PearlBait.mc.field_71439_g.field_70122_E) {
                        return;
                    }
                    PearlBait.mc.field_71439_g.field_70159_w = 0.0;
                    PearlBait.mc.field_71439_g.field_70181_x = 0.0;
                    PearlBait.mc.field_71439_g.field_70179_y = 0.0;
                    PearlBait.mc.field_71439_g.field_71158_b.field_192832_b = 0.0f;
                    PearlBait.mc.field_71439_g.field_71158_b.field_78902_a = 0.0f;
                    PearlBait.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(PearlBait.mc.field_71439_g.field_70165_t, PearlBait.mc.field_71439_g.field_70163_u + 1.0, PearlBait.mc.field_71439_g.field_70161_v, false));
                    this.thrownPearlId = packet.func_149001_c();
                }
            });
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketPlayer && this.guarantee.getValue().booleanValue() && this.thrownPearlId != -1) {
            this.packets.add((CPacketPlayer)event.getPacket());
            event.setCanceled(true);
        }
    }

    @Override
    public String onUpdate() {
        if (this.thrownPearlId != -1) {
            for (Entity entity : PearlBait.mc.field_71441_e.field_72996_f) {
                if (entity.func_145782_y() != this.thrownPearlId || !(entity instanceof EntityEnderPearl)) continue;
                EntityEnderPearl pearl = (EntityEnderPearl)entity;
                if (!pearl.field_70128_L) continue;
                this.thrownPearlId = -1;
            }
        } else if (!this.packets.isEmpty()) {
            do {
                PearlBait.mc.field_71439_g.field_71174_a.func_147297_a((Packet)this.packets.poll());
            } while (!this.packets.isEmpty());
        }
        return null;
    }
}

