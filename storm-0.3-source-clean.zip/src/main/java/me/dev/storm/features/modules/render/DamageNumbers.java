/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.ibm.icu.math.BigDecimal
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.util.math.Vec3d
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.features.modules.render;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ibm.icu.math.BigDecimal;
import java.awt.Color;
import java.util.List;
import java.util.Map;
import me.dev.storm.event.events.Render3DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.Timer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class DamageNumbers
extends Module {
    private final Map<Integer, Float> hpData = Maps.newHashMap();
    private final List<Particle> particles = Lists.newArrayList();
    private final Timer timer = new Timer();
    public Setting<Integer> deleteAfter = this.register(new Setting<Integer>("Remove Ticks", 7, 1, 60));

    public DamageNumbers() {
        super("DmgNumbers", "show damage", Module.Category.RENDER, true, false, false);
    }

    @Override
    public void onRender3D(Render3DEvent render3DEvent) {
        if (!this.particles.isEmpty()) {
            for (Particle particle : this.particles) {
                if (particle == null || particle.ticks > this.deleteAfter.getValue()) continue;
                GlStateManager.func_179094_E();
                GlStateManager.func_179097_i();
                Tessellator tessellator = Tessellator.func_178181_a();
                BufferBuilder bufferBuilder = tessellator.func_178180_c();
                bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
                tessellator.func_78381_a();
                GL11.glDisable((int)2848);
                GlStateManager.func_179132_a((boolean)true);
                GlStateManager.func_179126_j();
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                GlStateManager.func_179121_F();
                GlStateManager.func_179094_E();
                GlStateManager.func_179088_q();
                GlStateManager.func_179136_a((float)1.0f, (float)-1500000.0f);
                GlStateManager.func_179137_b((double)(particle.posX - DamageNumbers.mc.func_175598_ae().field_78725_b), (double)(particle.posY - DamageNumbers.mc.func_175598_ae().field_78726_c), (double)(particle.posZ - DamageNumbers.mc.func_175598_ae().field_78723_d));
                GlStateManager.func_179114_b((float)(-DamageNumbers.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
                GlStateManager.func_179114_b((float)DamageNumbers.mc.func_175598_ae().field_78732_j, (float)(DamageNumbers.mc.field_71474_y.field_74320_O == 2 ? -1.0f : 1.0f), (float)0.0f, (float)0.0f);
                GlStateManager.func_179139_a((double)-0.03, (double)-0.03, (double)0.03);
                GL11.glDepthMask((boolean)false);
                DamageNumbers.mc.field_71466_p.func_175063_a(particle.str, (float)((double)(-DamageNumbers.mc.field_71466_p.func_78256_a(particle.str)) * 0.5), (float)(-DamageNumbers.mc.field_71466_p.field_78288_b + 1), particle.color.getRGB());
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GL11.glDepthMask((boolean)true);
                GlStateManager.func_179136_a((float)1.0f, (float)1500000.0f);
                GlStateManager.func_179113_r();
                GlStateManager.func_179117_G();
                GlStateManager.func_179121_F();
            }
        }
    }

    @Override
    public void onDisable() {
        this.particles.clear();
    }

    @Override
    public String onUpdate() {
        if (this.timer.passedMs(12000L)) {
            this.particles.clear();
            this.timer.reset();
        }
        if (!this.particles.isEmpty()) {
            for (Particle particle : this.particles) {
                if (particle == null) continue;
                ++particle.ticks;
            }
        }
        for (Particle particle : DamageNumbers.mc.field_71441_e.field_72996_f) {
            if (!(particle instanceof EntityLivingBase)) continue;
            EntityLivingBase entityLivingBase = (EntityLivingBase)particle;
            double d = this.hpData.getOrDefault(entityLivingBase.func_145782_y(), Float.valueOf(entityLivingBase.func_110138_aP())).floatValue();
            this.hpData.remove(particle.func_145782_y());
            this.hpData.put(particle.func_145782_y(), Float.valueOf(entityLivingBase.func_110143_aJ()));
            if (d == (double)entityLivingBase.func_110143_aJ()) continue;
            Color color = Color.YELLOW;
            Vec3d vec3d = new Vec3d(((Entity)particle).field_70165_t + Math.random() * 0.5 * (double)(Math.random() > 0.5 ? -1 : 1), particle.func_174813_aQ().field_72338_b + (particle.func_174813_aQ().field_72337_e - particle.func_174813_aQ().field_72338_b) * 0.5, ((Entity)particle).field_70161_v + Math.random() * 0.5 * (double)(Math.random() > 0.5 ? -1 : 1));
            double d2 = new BigDecimal(Math.abs(d - (double)entityLivingBase.func_110143_aJ())).setScale(1, 4).doubleValue();
            this.particles.add(new Particle("" + d2, vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c, color));
        }
        return null;
    }

    static class Particle {
        public double posY;
        public Color color;
        public String str;
        public int ticks;
        public double posZ;
        public double posX;

        public Particle(String string, double d, double d2, double d3, Color color2) {
            this.str = string;
            this.posX = d;
            this.posY = d2;
            this.posZ = d3;
            this.color = color2;
            this.ticks = 0;
        }
    }
}

