/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.Display
 */
package me.dev.storm.features.modules.client;

import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import org.lwjgl.opengl.Display;

public class Title
extends Module {
    private static Title INSTANCE = new Title();
    public Setting<String> displayTitle = this.register(new Setting<String>("Title", "storm"));
    public Setting<Boolean> version = this.register(new Setting<Boolean>("Version", false));

    public Title() {
        super("TitleModifier", "Sets the title of your game", Module.Category.CLIENT, true, false, false);
    }

    public static Title getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Title();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public String onUpdate() {
        Display.setTitle((String)this.displayTitle.getValue());
        return null;
    }
}

