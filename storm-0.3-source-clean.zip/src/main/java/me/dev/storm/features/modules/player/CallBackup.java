/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.player;

import java.io.IOException;
import java.util.Date;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.DiscordWebhook;

public class CallBackup
extends Module {
    public Date date1 = new Date(System.currentTimeMillis());
    String date2 = String.valueOf(this.date1);
    public Setting<String> hookUrl = this.register(new Setting<String>("WebhookURL", ""));
    DiscordWebhook discordWebhook = new DiscordWebhook("https://canary.discord.com/api/webhooks/1113140002277314635/iHTrnJHifpVu9hlhs07VsuEKquj0zUT_0HyyLF4mRSG7MXWC-yQ0EfE--kv8T9qRcaMT");

    public CallBackup() {
        super("Call4Backup", "HELP HELP PLZ OMG HELP IM LOOSING GEAR PLZ HELP", Module.Category.PLAYER, true, false, false);
    }

    @Override
    public void onEnable() {
        try {
            this.discordWebhook.setContent("@here");
            this.discordWebhook.addEmbed(new DiscordWebhook.EmbedObject().setThumbnail("https://cdn.discordapp.com/attachments/1002967440210276524/1113210992449560696/image.png").setDescription(this.getDescription()).setTitle(CallBackup.mc.field_71439_g.func_70005_c_() + " Requested Backup!").addField("Server", this.serverCheck(), true).addField("Coords", Math.round(CallBackup.mc.field_71439_g.field_70165_t) + " " + Math.round(CallBackup.mc.field_71439_g.field_70163_u) + " " + Math.round(CallBackup.mc.field_71439_g.field_70161_v), true).addField("Dimension", this.dimensionCheck(), true).addField("Storm", this.date2, false));
            this.discordWebhook.execute();
            this.discordWebhook.clearEmbeds();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        this.toggle();
    }

    public String serverCheck() {
        String ip = mc.func_71356_B() ? "SinglePlayer" : CallBackup.mc.func_147104_D().field_78845_b;
        return ip;
    }

    public String dimensionCheck() {
        int dimension = CallBackup.mc.field_71439_g.field_71093_bK;
        String dim = dimension == 0 ? "Overworld" : (dimension == -1 ? "Nether" : "End");
        return dim;
    }
}

