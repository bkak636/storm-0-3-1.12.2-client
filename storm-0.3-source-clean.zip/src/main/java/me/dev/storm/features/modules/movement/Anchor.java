/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.movement;

import java.util.ArrayList;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Anchor
extends Module {
    public Setting<Boolean> pull = this.register(new Setting<Boolean>("Pull", true));
    public Setting<Integer> pitch = this.register(new Setting<Integer>("Pitch", 60, 0, 90));
    private final ArrayList<BlockPos> holes = new ArrayList();
    int holeblocks;
    public static boolean AnchorING;
    private Vec3d Center = Vec3d.field_186680_a;

    public Anchor() {
        super("Anchor", "Stops all movement if player is above a hole.", Module.Category.MOVEMENT, false, false, false);
    }

    public boolean isBlockHole(BlockPos blockpos) {
        this.holeblocks = 0;
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 3, 0)).func_177230_c() == Blocks.field_150350_a) {
            ++this.holeblocks;
        }
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 2, 0)).func_177230_c() == Blocks.field_150350_a) {
            ++this.holeblocks;
        }
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150350_a) {
            ++this.holeblocks;
        }
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, 0)).func_177230_c() == Blocks.field_150350_a) {
            ++this.holeblocks;
        }
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        if (Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150343_Z || Anchor.mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150357_h) {
            ++this.holeblocks;
        }
        return this.holeblocks >= 9;
    }

    public Vec3d GetCenter(double posX, double posY, double posZ) {
        double x = Math.floor(posX) + 0.5;
        double y = Math.floor(posY);
        double z = Math.floor(posZ) + 0.5;
        return new Vec3d(x, y, z);
    }

    @Override
    @SubscribeEvent
    public String onUpdate() {
        if (Anchor.mc.field_71441_e == null) {
            return null;
        }
        if (Anchor.mc.field_71439_g.field_70163_u < 0.0) {
            return null;
        }
        if (Anchor.mc.field_71439_g.field_70125_A >= (float)this.pitch.getValue().intValue()) {
            if (this.isBlockHole(this.getPlayerPos().func_177979_c(1)) || this.isBlockHole(this.getPlayerPos().func_177979_c(2)) || this.isBlockHole(this.getPlayerPos().func_177979_c(3)) || this.isBlockHole(this.getPlayerPos().func_177979_c(4))) {
                AnchorING = true;
                if (!this.pull.getValue().booleanValue()) {
                    Anchor.mc.field_71439_g.field_70159_w = 0.0;
                    Anchor.mc.field_71439_g.field_70179_y = 0.0;
                } else {
                    this.Center = this.GetCenter(Anchor.mc.field_71439_g.field_70165_t, Anchor.mc.field_71439_g.field_70163_u, Anchor.mc.field_71439_g.field_70161_v);
                    double XDiff = Math.abs(this.Center.field_72450_a - Anchor.mc.field_71439_g.field_70165_t);
                    double ZDiff = Math.abs(this.Center.field_72449_c - Anchor.mc.field_71439_g.field_70161_v);
                    if (XDiff <= 0.1 && ZDiff <= 0.1) {
                        this.Center = Vec3d.field_186680_a;
                    } else {
                        double MotionX = this.Center.field_72450_a - Anchor.mc.field_71439_g.field_70165_t;
                        double MotionZ = this.Center.field_72449_c - Anchor.mc.field_71439_g.field_70161_v;
                        Anchor.mc.field_71439_g.field_70159_w = MotionX / 2.0;
                        Anchor.mc.field_71439_g.field_70179_y = MotionZ / 2.0;
                    }
                }
            } else {
                AnchorING = false;
            }
        }
        return null;
    }

    @Override
    public void onDisable() {
        AnchorING = false;
        this.holeblocks = 0;
    }

    public BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(Anchor.mc.field_71439_g.field_70165_t), Math.floor(Anchor.mc.field_71439_g.field_70163_u), Math.floor(Anchor.mc.field_71439_g.field_70161_v));
    }
}

