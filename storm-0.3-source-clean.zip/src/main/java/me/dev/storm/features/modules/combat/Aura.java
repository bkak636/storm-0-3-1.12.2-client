/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.features.modules.combat;

import java.awt.Color;
import me.dev.storm.Storm;
import me.dev.storm.event.events.Render3DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.manager.ColorManager;
import me.dev.storm.util.ColorUtil;
import me.dev.storm.util.DamageUtil;
import me.dev.storm.util.EntityUtil;
import me.dev.storm.util.MathUtil;
import me.dev.storm.util.RenderUtil;
import me.dev.storm.util.Timer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

public class Aura
extends Module {
    public final Setting<Boolean> players;
    private final Setting<RenderMode> render;
    public final Setting<Boolean> packet;
    public final Setting<Boolean> tps;
    public final Setting<Float> raytrace;
    public final Setting<Boolean> vehicles;
    public final Setting<Boolean> animals;
    public final Setting<Boolean> delay;
    public static Entity target;
    public final Setting<Boolean> mobs;
    public final Setting<Boolean> onlySharp;
    public final Setting<Boolean> projectiles;
    public final Setting<Float> range = this.register(new Setting<Float>("Range", Float.valueOf(6.0f), Float.valueOf(0.1f), Float.valueOf(7.0f)));
    private final Timer timer;

    private void doAura() {
        int n2;
        int n = 0;
        if (this.onlySharp.getValue().booleanValue() && !EntityUtil.holdingWeapon((EntityPlayer)Aura.mc.field_71439_g)) {
            target = null;
            return;
        }
        int n3 = this.delay.getValue() == false ? 0 : (n2 = (n = (int)((float)DamageUtil.getCooldownByWeapon((EntityPlayer)Aura.mc.field_71439_g) * (this.tps.getValue() != false ? Storm.serverManager.getTpsFactor() : 1.0f))));
        if (!this.timer.passedMs(n)) {
            return;
        }
        target = this.getTarget();
        if (target == null) {
            return;
        }
        EntityUtil.attackEntity(target, this.packet.getValue(), true);
        this.timer.reset();
    }

    @Override
    public void onTick() {
        this.doAura();
    }

    public Aura() {
        super("Aura", "Swords enemies.", Module.Category.COMBAT, true, false, true);
        this.delay = this.register(new Setting<Boolean>("HitDelay", Boolean.TRUE));
        this.onlySharp = this.register(new Setting<Boolean>("SwordOnly", Boolean.TRUE));
        this.raytrace = this.register(new Setting<Float>("Raytrace", Float.valueOf(6.0f), Float.valueOf(0.1f), Float.valueOf(7.0f), "Wall Range."));
        this.players = this.register(new Setting<Boolean>("Players", Boolean.TRUE));
        this.mobs = this.register(new Setting<Boolean>("Mobs", Boolean.FALSE));
        this.animals = this.register(new Setting<Boolean>("Animals", Boolean.FALSE));
        this.vehicles = this.register(new Setting<Boolean>("Entities", Boolean.FALSE));
        this.projectiles = this.register(new Setting<Boolean>("Projectiles", Boolean.FALSE));
        this.tps = this.register(new Setting<Boolean>("TpsSync", Boolean.TRUE));
        this.packet = this.register(new Setting<Boolean>("Packet", Boolean.FALSE));
        this.timer = new Timer();
        this.render = this.register(new Setting<RenderMode>("Render", RenderMode.JELLO));
    }

    private double easeInOutQuad(double d) {
        return d < 0.5 ? 2.0 * d * d : 1.0 - Math.pow(-2.0 * d + 2.0, 2.0) / 2.0;
    }

    @Override
    public void onRender3D(Render3DEvent render3DEvent) {
        if (target != null) {
            if (this.render.getValue() == RenderMode.OLD) {
                RenderUtil.drawEntityBoxESP(target, ColorManager.getCurrent(), true, new Color(255, 255, 255, 130), 0.7f, true, true, 35);
            } else if (this.render.getValue() == RenderMode.JELLO) {
                double d = 1500.0;
                double d2 = (double)System.currentTimeMillis() % d;
                boolean bl = d2 > d / 2.0;
                double d3 = d2 / (d / 2.0);
                d3 = !bl ? 1.0 - d3 : d3 - 1.0;
                d3 = this.easeInOutQuad(d3);
                Aura.mc.field_71460_t.func_175072_h();
                GL11.glPushMatrix();
                GL11.glDisable((int)3553);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glEnable((int)2848);
                GL11.glEnable((int)3042);
                GL11.glDisable((int)2929);
                GL11.glDisable((int)2884);
                GL11.glShadeModel((int)7425);
                Aura.mc.field_71460_t.func_175072_h();
                double d4 = Aura.target.field_70130_N;
                double d5 = (double)Aura.target.field_70131_O + 0.1;
                double d6 = Aura.target.field_70142_S + (Aura.target.field_70165_t - Aura.target.field_70142_S) * (double)mc.func_184121_ak() - Aura.mc.func_175598_ae().field_78730_l;
                double d7 = Aura.target.field_70137_T + (Aura.target.field_70163_u - Aura.target.field_70137_T) * (double)mc.func_184121_ak() - Aura.mc.func_175598_ae().field_78731_m + d5 * d3;
                double d8 = Aura.target.field_70136_U + (Aura.target.field_70161_v - Aura.target.field_70136_U) * (double)mc.func_184121_ak() - Aura.mc.func_175598_ae().field_78728_n;
                double d9 = d5 / 3.0 * (d3 > 0.5 ? 1.0 - d3 : d3) * (double)(bl ? -1 : 1);
                for (int i = 0; i < 360; i += 5) {
                    Color color = Storm.colorManager.getRainbow();
                    double d10 = d6 - Math.sin((double)i * Math.PI / 180.0) * d4;
                    double d11 = d8 + Math.cos((double)i * Math.PI / 180.0) * d4;
                    double d12 = d6 - Math.sin((double)(i - 5) * Math.PI / 180.0) * d4;
                    double d13 = d8 + Math.cos((double)(i - 5) * Math.PI / 180.0) * d4;
                    GL11.glBegin((int)7);
                    GL11.glColor4f((float)((float)ColorUtil.pulseColor(color, 200, 1).getRed() / 255.0f), (float)((float)ColorUtil.pulseColor(color, 200, 1).getGreen() / 255.0f), (float)((float)ColorUtil.pulseColor(color, 200, 1).getBlue() / 255.0f), (float)0.0f);
                    GL11.glVertex3d((double)d10, (double)(d7 + d9), (double)d11);
                    GL11.glVertex3d((double)d12, (double)(d7 + d9), (double)d13);
                    GL11.glColor4f((float)((float)ColorUtil.pulseColor(color, 200, 1).getRed() / 255.0f), (float)((float)ColorUtil.pulseColor(color, 200, 1).getGreen() / 255.0f), (float)((float)ColorUtil.pulseColor(color, 200, 1).getBlue() / 255.0f), (float)200.0f);
                    GL11.glVertex3d((double)d12, (double)d7, (double)d13);
                    GL11.glVertex3d((double)d10, (double)d7, (double)d11);
                    GL11.glEnd();
                    GL11.glBegin((int)2);
                    GL11.glVertex3d((double)d12, (double)d7, (double)d13);
                    GL11.glVertex3d((double)d10, (double)d7, (double)d11);
                    GL11.glEnd();
                }
                GL11.glEnable((int)2884);
                GL11.glShadeModel((int)7424);
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GL11.glEnable((int)2929);
                GL11.glDisable((int)2848);
                GL11.glDisable((int)3042);
                GL11.glEnable((int)3553);
                GL11.glPopMatrix();
            }
        }
    }

    @Override
    public String getDisplayInfo() {
        if (target instanceof EntityPlayer) {
            return target.func_70005_c_();
        }
        return null;
    }

    private Entity getTarget() {
        Entity entity = null;
        double d = this.range.getValue().floatValue();
        double d2 = 36.0;
        for (Entity entity2 : Aura.mc.field_71441_e.field_72996_f) {
            if (!(this.players.getValue() != false && entity2 instanceof EntityPlayer || this.animals.getValue() != false && EntityUtil.isPassive(entity2) || this.mobs.getValue() != false && !EntityUtil.isMobAggressive(entity2) || this.vehicles.getValue() != false && EntityUtil.isVehicle(entity2)) && (!this.projectiles.getValue().booleanValue() || !EntityUtil.isProjectile(entity2)) || entity2 != null && EntityUtil.isntValid(entity2, d) || !Aura.mc.field_71439_g.func_70685_l(entity2) && !EntityUtil.canEntityFeetBeSeen(entity2) && Aura.mc.field_71439_g.func_70068_e(entity2) > MathUtil.square(this.raytrace.getValue().floatValue())) continue;
            if (entity == null) {
                entity = entity2;
                d = Aura.mc.field_71439_g.func_70068_e(entity2);
                d2 = EntityUtil.getHealth(entity2);
                continue;
            }
            if (entity2 instanceof EntityPlayer && DamageUtil.isArmorLow((EntityPlayer)entity2, 18)) {
                entity = entity2;
                break;
            }
            if (Aura.mc.field_71439_g.func_70068_e(entity2) < d) {
                entity = entity2;
                d = Aura.mc.field_71439_g.func_70068_e(entity2);
                d2 = EntityUtil.getHealth(entity2);
            }
            if (!((double)EntityUtil.getHealth(entity2) < d2)) continue;
            entity = entity2;
            d = Aura.mc.field_71439_g.func_70068_e(entity2);
            d2 = EntityUtil.getHealth(entity2);
        }
        return entity;
    }

    private static enum RenderMode {
        OLD,
        JELLO,
        OFF;

    }
}

