/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.Mod$EventHandler
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.event.events.trollgod.MoveEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.MovementUtil;
import me.dev.storm.util.trollhack.EntityUtil;
import net.minecraftforge.fml.common.Mod;

public class InstantSpeed
extends Module {
    Setting<Boolean> noLiquid = this.register(new Setting<Boolean>("NoLiquid", true));

    public InstantSpeed() {
        super("InstantSpeed", "Trollgod speed!!!!", Module.Category.MOVEMENT, false, false, false);
    }

    @Override
    public void onToggle() {
        if (InstantSpeed.fullNullCheck()) {
            return;
        }
    }

    @Mod.EventHandler
    public void onMove(MoveEvent e) {
        if (this.isDisabled() || InstantSpeed.mc.field_71439_g.func_184613_cA()) {
            return;
        }
        if (this.noLiquid.getValue().booleanValue() && EntityUtil.isInLiquid() || InstantSpeed.mc.field_71439_g.field_71075_bZ.field_75100_b) {
            return;
        }
        MovementUtil.strafe(e, MovementUtil.getSpeed());
    }

    @Override
    public String getDisplayInfo() {
        return "NoLiquid";
    }
}

