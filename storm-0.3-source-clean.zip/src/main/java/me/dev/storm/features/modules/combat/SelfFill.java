/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockObsidian
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 */
package me.dev.storm.features.modules.combat;

import me.dev.storm.features.command.Command;
import me.dev.storm.features.modules.Module;
import me.dev.storm.util.ItemUtil;
import net.minecraft.block.BlockObsidian;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class SelfFill
extends Module {
    private BlockPos originalPos;
    private int oldSlot = -1;

    public SelfFill() {
        super("SelfFill", "burrow", Module.Category.COMBAT, true, false, false);
    }

    @Override
    public void onEnable() {
        this.originalPos = new BlockPos(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u, SelfFill.mc.field_71439_g.field_70161_v);
        if (SelfFill.mc.field_71441_e.func_180495_p(new BlockPos(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u, SelfFill.mc.field_71439_g.field_70161_v)).func_177230_c().equals(Blocks.field_150343_Z) || this.intersectsWithEntity(this.originalPos)) {
            this.toggle();
            return;
        }
        this.oldSlot = SelfFill.mc.field_71439_g.field_71071_by.field_70461_c;
    }

    @Override
    public String onUpdate() {
        if (ItemUtil.findHotbarBlock(BlockObsidian.class) == -1) {
            Command.sendMessage("Can't find obsidian in hotbar!");
            this.toggle();
            return null;
        }
        ItemUtil.switchToSlot(ItemUtil.findHotbarBlock(BlockObsidian.class));
        SelfFill.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u + 0.41999998688698, SelfFill.mc.field_71439_g.field_70161_v, true));
        SelfFill.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u + 0.7531999805211997, SelfFill.mc.field_71439_g.field_70161_v, true));
        SelfFill.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u + 1.00133597911214, SelfFill.mc.field_71439_g.field_70161_v, true));
        SelfFill.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u + 1.16610926093821, SelfFill.mc.field_71439_g.field_70161_v, true));
        ItemUtil.placeBlock(this.originalPos, EnumHand.MAIN_HAND, true, true, false);
        SelfFill.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(SelfFill.mc.field_71439_g.field_70165_t, SelfFill.mc.field_71439_g.field_70163_u + -6.395812, SelfFill.mc.field_71439_g.field_70161_v, false));
        ItemUtil.switchToSlot(this.oldSlot);
        Minecraft.func_71410_x().field_71439_g.func_70095_a(false);
        this.toggle();
        return null;
    }

    private boolean intersectsWithEntity(BlockPos pos) {
        for (Entity entity : SelfFill.mc.field_71441_e.field_72996_f) {
            if (entity.equals((Object)SelfFill.mc.field_71439_g) || entity instanceof EntityItem || !new AxisAlignedBB(pos).func_72326_a(entity.func_174813_aQ())) continue;
            return true;
        }
        return false;
    }

    @Override
    public void onDisable() {
        Minecraft.func_71410_x().field_71439_g.func_70095_a(false);
        super.onDisable();
    }
}

