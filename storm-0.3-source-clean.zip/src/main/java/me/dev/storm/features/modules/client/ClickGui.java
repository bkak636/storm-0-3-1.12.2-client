/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.GuiConfirmOpenLink
 *  net.minecraft.client.gui.GuiControls
 *  net.minecraft.client.gui.GuiCustomizeSkin
 *  net.minecraft.client.gui.GuiGameOver
 *  net.minecraft.client.gui.GuiIngameMenu
 *  net.minecraft.client.gui.GuiOptions
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiScreenOptionsSounds
 *  net.minecraft.client.gui.GuiVideoSettings
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.gui.inventory.GuiEditSign
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.settings.GameSettings$Options
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.client.GuiModList
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import me.dev.storm.Storm;
import me.dev.storm.event.events.ClientEvent;
import me.dev.storm.features.command.Command;
import me.dev.storm.features.gui.StormGui;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.client.Colors;
import me.dev.storm.features.modules.client.GuiBlur;
import me.dev.storm.features.setting.Setting;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiConfirmOpenLink;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiCustomizeSkin;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.GuiModList;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ClickGui
extends Module {
    public static ClickGui INSTANCE = new ClickGui();
    public Setting<String> prefix = this.register(new Setting<String>("Prefix", "-"));
    public Setting<Boolean> blur = this.register(new Setting<Boolean>("Blur", true));
    public Setting<Boolean> customFov = this.register(new Setting<Boolean>("CustomFov", false));
    public Setting<Float> fov = this.register(new Setting<Float>("Fov", Float.valueOf(150.0f), Float.valueOf(-180.0f), Float.valueOf(180.0f)));
    public Setting<Integer> red = this.register(new Setting<Integer>("Red", 254, 0, 255));
    public Setting<Boolean> snowing = this.register(new Setting<Boolean>("Snowing", true));
    public Setting<Integer> green = this.register(new Setting<Integer>("Green", 254, 0, 255));
    public Setting<Integer> blue = this.register(new Setting<Integer>("Blue", 0, 0, 255));
    public Setting<Integer> hoverAlpha = this.register(new Setting<Integer>("Alpha", 77, 0, 255));
    public Setting<Integer> topRed = this.register(new Setting<Integer>("SecondRed", 164, 0, 255));
    public Setting<Integer> topGreen = this.register(new Setting<Integer>("SecondGreen", 164, 0, 255));
    public Setting<Integer> topBlue = this.register(new Setting<Integer>("SecondBlue", 1, 0, 255));
    public Setting<Integer> alpha = this.register(new Setting<Integer>("HoverAlpha", 92, 0, 255));
    public Setting<Boolean> rainbow = this.register(new Setting<Boolean>("Rainbow", false));
    public Setting<rainbowMode> rainbowModeHud = this.register(new Setting<Object>("HRainbowMode", (Object)rainbowMode.Static, v -> this.rainbow.getValue()));
    public final Setting<Style> style = this.register(new Setting<Style>("Style", Style.NEW));
    public Setting<rainbowModeArray> rainbowModeA = this.register(new Setting<Object>("ARainbowMode", (Object)rainbowModeArray.Static, v -> this.rainbow.getValue()));
    public Setting<Integer> rainbowHue = this.register(new Setting<Object>("Delay", Integer.valueOf(240), Integer.valueOf(0), Integer.valueOf(600), v -> this.rainbow.getValue()));
    public Setting<Float> rainbowBrightness = this.register(new Setting<Object>("Brightness", Float.valueOf(150.0f), Float.valueOf(1.0f), Float.valueOf(255.0f), v -> this.rainbow.getValue()));
    public Setting<Float> rainbowSaturation = this.register(new Setting<Object>("Saturation", Float.valueOf(150.0f), Float.valueOf(1.0f), Float.valueOf(255.0f), v -> this.rainbow.getValue()));
    public Setting<Boolean> box2 = this.register(new Setting<Boolean>("Box", true));
    public Setting<Integer> shaderRadius = this.register(new Setting<Integer>("ShaderRadius", 3, 1, 10));
    public Setting<Integer> shaderRed = this.register(new Setting<Integer>("ShaderRed", 253, 0, 255));
    public final Setting<Color> color = this.register(new Setting<Color>("Color", new Color(125, 125, 213)));
    public Setting<Integer> shaderGreen = this.register(new Setting<Integer>("ShaderGreen", 253, 0, 255));
    public Setting<Integer> shaderBlue = this.register(new Setting<Integer>("ShaderBlue", 0, 0, 255));
    public Setting<Integer> shaderAlpha = this.register(new Setting<Integer>("ShaderAlpha", 255, 0, 255));
    public Setting<Boolean> shader = this.register(new Setting<Boolean>("Shader", true));
    private StormGui click;
    public static final ResourceLocation GradientIMG = new ResourceLocation("textures/BUG.png");

    public ClickGui() {
        super("ClickGui", "Opens the ClickGui", Module.Category.CLIENT, true, false, false);
        this.setInstance();
    }

    public static ClickGui getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ClickGui();
        }
        return INSTANCE;
    }

    public static Colors INSTANCE() {
        return null;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public String onUpdate() {
        if (this.customFov.getValue().booleanValue()) {
            ClickGui.mc.field_71474_y.func_74304_a(GameSettings.Options.FOV, this.fov.getValue().floatValue());
        }
        if (GuiBlur.mc.field_71441_e != null) {
            if (!(ClickGui.getInstance().isEnabled() || GuiBlur.mc.field_71462_r instanceof GuiContainer || GuiBlur.mc.field_71462_r instanceof GuiChat || GuiBlur.mc.field_71462_r instanceof GuiConfirmOpenLink || GuiBlur.mc.field_71462_r instanceof GuiEditSign || GuiBlur.mc.field_71462_r instanceof GuiGameOver || GuiBlur.mc.field_71462_r instanceof GuiOptions || GuiBlur.mc.field_71462_r instanceof GuiIngameMenu || GuiBlur.mc.field_71462_r instanceof GuiVideoSettings || GuiBlur.mc.field_71462_r instanceof GuiScreenOptionsSounds || GuiBlur.mc.field_71462_r instanceof GuiControls || GuiBlur.mc.field_71462_r instanceof GuiCustomizeSkin || GuiBlur.mc.field_71462_r instanceof GuiModList || GuiBlur.mc.field_71462_r instanceof StormGui)) {
                if (GuiBlur.mc.field_71460_t.func_147706_e() != null) {
                    GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
                }
            } else if (OpenGlHelper.field_148824_g && GuiBlur.mc.func_175606_aa() instanceof EntityPlayer) {
                if (GuiBlur.mc.field_71460_t.func_147706_e() != null) {
                    GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
                }
                try {
                    GuiBlur.mc.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            } else if (GuiBlur.mc.field_71460_t.func_147706_e() != null && GuiBlur.mc.field_71462_r == null) {
                GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
            }
        }
        return null;
    }

    @SubscribeEvent
    public void onSettingChange(ClientEvent event) {
        if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
            if (event.getSetting().equals(this.prefix)) {
                Storm.commandManager.setPrefix(this.prefix.getPlannedValue());
                Command.sendMessage("prefix set to " + ChatFormatting.DARK_GRAY + Storm.commandManager.getPrefix());
            }
            Storm.colorManager.setColor(this.red.getPlannedValue(), this.green.getPlannedValue(), this.blue.getPlannedValue(), this.hoverAlpha.getPlannedValue());
        }
    }

    @Override
    public void onEnable() {
        mc.func_147108_a((GuiScreen)StormGui.getClickGui());
    }

    @Override
    public void onDisable() {
        GuiBlur.mc.field_71460_t.func_147706_e().func_148021_a();
    }

    @Override
    public void onLoad() {
        Storm.colorManager.setColor(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.hoverAlpha.getValue());
        Storm.commandManager.setPrefix(this.prefix.getValue());
    }

    @Override
    public void onTick() {
        if (!(ClickGui.mc.field_71462_r instanceof StormGui)) {
            this.disable();
        }
    }

    @Override
    public String getDisplayInfo() {
        return "NewGui";
    }

    public static enum Style {
        OLD,
        NEW,
        FUTURE,
        DOTGOD;

    }

    public static enum rainbowMode {
        Static,
        Sideway;

    }

    public static enum rainbowModeArray {
        Static,
        Up;

    }
}

