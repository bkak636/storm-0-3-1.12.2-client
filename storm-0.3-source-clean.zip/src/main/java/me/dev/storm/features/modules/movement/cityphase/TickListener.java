/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.math.MathHelper
 */
package me.dev.storm.features.modules.movement.cityphase;

import me.dev.storm.event.EventListener;
import me.dev.storm.event.events.TickEvent;
import me.dev.storm.features.modules.movement.CityPhase;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;

public class TickListener
extends EventListener<TickEvent, CityPhase> {
    public TickListener(CityPhase cityPhase) {
        super(TickEvent.class, cityPhase);
    }

    @Override
    public void invoke(Object object) {
        if (((CityPhase)this.module).movingByKeys()) {
            ((CityPhase)this.module).toggle();
            return;
        }
        if (this.mc.field_71441_e.func_184144_a((Entity)this.mc.field_71439_g, this.mc.field_71439_g.func_174813_aQ().func_72314_b(0.01, 0.0, 0.01)).size() < 2) {
            this.mc.field_71439_g.func_70107_b(((CityPhase)this.module).roundToClosest(this.mc.field_71439_g.field_70165_t, Math.floor(this.mc.field_71439_g.field_70165_t) + 0.301, Math.floor(this.mc.field_71439_g.field_70165_t) + 0.699), this.mc.field_71439_g.field_70163_u, ((CityPhase)this.module).roundToClosest(this.mc.field_71439_g.field_70161_v, Math.floor(this.mc.field_71439_g.field_70161_v) + 0.301, Math.floor(this.mc.field_71439_g.field_70161_v) + 0.699));
        } else if ((float)this.mc.field_71439_g.field_70173_aa % ((CityPhase)this.module).timeout.getValue().floatValue() == 0.0f) {
            this.mc.field_71439_g.func_70107_b(this.mc.field_71439_g.field_70165_t + MathHelper.func_151237_a((double)(((CityPhase)this.module).roundToClosest(this.mc.field_71439_g.field_70165_t, Math.floor(this.mc.field_71439_g.field_70165_t) + 0.241, Math.floor(this.mc.field_71439_g.field_70165_t) + 0.759) - this.mc.field_71439_g.field_70165_t), (double)-0.03, (double)0.03), this.mc.field_71439_g.field_70163_u, this.mc.field_71439_g.field_70161_v + MathHelper.func_151237_a((double)(((CityPhase)this.module).roundToClosest(this.mc.field_71439_g.field_70161_v, Math.floor(this.mc.field_71439_g.field_70161_v) + 0.241, Math.floor(this.mc.field_71439_g.field_70161_v) + 0.759) - this.mc.field_71439_g.field_70161_v), (double)-0.03, (double)0.03));
            this.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(this.mc.field_71439_g.field_70165_t, this.mc.field_71439_g.field_70163_u, this.mc.field_71439_g.field_70161_v, true));
            this.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(((CityPhase)this.module).roundToClosest(this.mc.field_71439_g.field_70165_t, Math.floor(this.mc.field_71439_g.field_70165_t) + 0.23, Math.floor(this.mc.field_71439_g.field_70165_t) + 0.77), this.mc.field_71439_g.field_70163_u, ((CityPhase)this.module).roundToClosest(this.mc.field_71439_g.field_70161_v, Math.floor(this.mc.field_71439_g.field_70161_v) + 0.23, Math.floor(this.mc.field_71439_g.field_70161_v) + 0.77), true));
        }
    }
}

