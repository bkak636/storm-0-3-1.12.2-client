/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.client.audio.ISound
 *  net.minecraft.client.audio.PositionedSoundRecord
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.SoundEvent
 */
package me.dev.storm.features.gui.components.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.storm.Storm;
import me.dev.storm.features.gui.StormGui;
import me.dev.storm.features.gui.components.Component;
import me.dev.storm.features.gui.components.items.buttons.Button;
import me.dev.storm.features.modules.client.ClickGui;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.RenderUtil;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

public class BooleanButton
extends Button {
    private final Setting setting;
    private int progress = 0;

    public BooleanButton(Setting setting) {
        super(setting.getName());
        this.setting = setting;
        this.width = 15;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        boolean dotgod;
        boolean newStyle = ClickGui.getInstance().style.getValue() == ClickGui.Style.NEW;
        boolean future = ClickGui.getInstance().style.getValue() == ClickGui.Style.FUTURE;
        boolean bl = dotgod = ClickGui.getInstance().style.getValue() == ClickGui.Style.DOTGOD;
        if (future) {
            RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4f, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(99) : Storm.colorManager.getCurrentWithAlpha(120)) : (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(26) : Storm.colorManager.getCurrentWithAlpha(55)));
            Storm.textManager.drawStringWithShadow(newStyle ? this.getName().toLowerCase() : this.getName(), this.x + 2.3f, this.y - 1.7f - (float)StormGui.getInstance().getTextOffset(), this.getState() ? -1 : -5592406);
        } else if (dotgod) {
            RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4f, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(65) : Storm.colorManager.getCurrentWithAlpha(90)) : (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(26) : Storm.colorManager.getCurrentWithAlpha(55)));
            Storm.textManager.drawStringWithShadow(this.getName().toLowerCase(), this.x + 2.3f, this.y - 1.7f - (float)StormGui.getInstance().getTextOffset(), this.getState() ? Storm.colorManager.getCurrentGui(240) : 0xB0B0B0);
        } else {
            RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4f, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getColorWithAlpha(Storm.moduleManager.getModuleByClass(ClickGui.class).hoverAlpha.getValue()) : Storm.colorManager.getColorWithAlpha(Storm.moduleManager.getModuleByClass(ClickGui.class).alpha.getValue())) : (!this.isHovering(mouseX, mouseY) ? 0x11555555 : -2007673515));
            Storm.textManager.drawStringWithShadow(newStyle ? this.getName().toLowerCase() : this.getName(), this.x + 2.3f, this.y - 1.7f - (float)StormGui.getInstance().getTextOffset(), this.getState() ? -1 : -5592406);
        }
        if (this.setting.parent) {
            if (this.setting.open) {
                ++this.progress;
            }
            if (future) {
                GlStateManager.func_179094_E();
                GlStateManager.func_179147_l();
                mc.func_110434_K().func_110577_a(new ResourceLocation("textures/mio/gear.png"));
                GlStateManager.func_179109_b((float)(this.getX() + (float)this.getWidth() - 6.7f + 8.0f), (float)(this.getY() + 7.7f - 0.3f), (float)0.0f);
                GlStateManager.func_179114_b((float)Component.calculateRotation(this.progress), (float)0.0f, (float)0.0f, (float)1.0f);
                RenderUtil.drawModalRect(-5, -5, 0.0f, 0.0f, 10, 10, 10, 10, 10.0f, 10.0f);
                GlStateManager.func_179084_k();
                GlStateManager.func_179121_F();
            } else {
                String color = this.getState() || newStyle ? "" : "" + ChatFormatting.GRAY;
                String gear = this.setting.open ? "-" : "+";
                Storm.textManager.drawStringWithShadow(color + gear, this.x - 1.5f + (float)this.width - 7.4f + 8.0f, this.y - 2.2f - (float)StormGui.getInstance().getTextOffset(), -1);
            }
        }
    }

    @Override
    public void update() {
        this.setHidden(!this.setting.isVisible());
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (this.isHovering(mouseX, mouseY)) {
            mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a((SoundEvent)SoundEvents.field_187909_gi, (float)1.0f));
        }
    }

    @Override
    public int getHeight() {
        return 14;
    }

    @Override
    public void toggle() {
        this.setting.setValue((Boolean)this.setting.getValue() == false);
    }

    @Override
    public boolean getState() {
        return (Boolean)this.setting.getValue();
    }
}

