/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.Gui
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.features.modules.render;

import java.awt.Color;
import java.awt.Font;
import java.util.Objects;
import me.dev.storm.event.events.Render2DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.util.EntityUtil;
import me.dev.storm.util.LBFontRenderer;
import me.dev.storm.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class TargetHud
extends Module {
    LBFontRenderer renderer;
    LBFontRenderer renderer2;

    public TargetHud() {
        super("TargetHud", "target hud", Module.Category.RENDER, true, false, false);
    }

    @Override
    public void onEnable() {
        this.renderer = new LBFontRenderer(new Font("Comfortaa", 0, 32));
        this.renderer2 = new LBFontRenderer(new Font("Comfortaa", 0, 48));
    }

    @Override
    @SubscribeEvent
    public void onRender2D(Render2DEvent event) {
        if (TargetHud.fullNullCheck()) {
            return;
        }
        EntityPlayer player = EntityUtil.getClosestEnemy(12.0);
        if (player != null && this.renderer != null && this.renderer2 != null) {
            try {
                RenderUtil.drawRectangleCorrectly(770, 350, 150, 50, new Color(30, 30, 30, 150).getRGB());
                this.drawHead(Objects.requireNonNull(mc.func_147114_u()).func_175102_a(player.func_110124_au()).func_178837_g(), 775, 355);
                RenderUtil.drawGradientSideways(820.0, 390.0, 820.0f + player.func_110143_aJ() * 3.9f, 395.0, new Color(218, 186, 255).getRGB(), new Color(255, 208, 143).getRGB());
                this.renderer.func_175065_a(String.format("%.1f", Float.valueOf(player.func_110143_aJ() + player.func_110139_bj())), 820 + (int)(player.func_110143_aJ() * 3.9f) + 5, 390.0f, new Color(255, 255, 255).getRGB(), false);
                this.renderer2.func_175065_a(player.func_70005_c_(), 820.0f, 355.0f, new Color(255, 255, 255).getRGB(), false);
                int iteration = 0;
                for (ItemStack is : player.field_71071_by.field_70460_b) {
                    ++iteration;
                    if (is.func_190926_b()) continue;
                    int x = 715 + (9 - iteration) * 20 + 2;
                    GlStateManager.func_179126_j();
                    RenderUtil.itemRender.field_77023_b = 200.0f;
                    RenderUtil.itemRender.func_180450_b(is, x, 367);
                    RenderUtil.itemRender.func_180453_a(TargetHud.mc.field_71466_p, is, x, 367, "");
                    RenderUtil.itemRender.field_77023_b = 0.0f;
                    GlStateManager.func_179098_w();
                    GlStateManager.func_179140_f();
                    GlStateManager.func_179097_i();
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public void drawHead(ResourceLocation skin, int width, int height) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        mc.func_110434_K().func_110577_a(skin);
        Gui.func_152125_a((int)width, (int)height, (float)8.0f, (float)8.0f, (int)8, (int)8, (int)40, (int)40, (float)64.0f, (float)64.0f);
    }
}

