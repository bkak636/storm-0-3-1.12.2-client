/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 */
package me.dev.storm.features.modules.combat;

import me.dev.storm.Storm;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.combat.autocity.InstantMine;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.BlockUtil;
import me.dev.storm.util.EntityUtil;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class AutoMine
extends Module {
    public static EntityPlayer target;
    private final Setting<Float> range;
    private final Setting<Boolean> toggle;
    public final Setting<Boolean> db = this.register(new Setting<Boolean>("Double Mode", false));

    private void surroundMine(BlockPos blockPos) {
        if (InstantMine.breakPos != null) {
            if (InstantMine.breakPos.equals((Object)blockPos)) {
                return;
            }
            if (InstantMine.breakPos.equals((Object)new BlockPos(AutoMine.target.field_70165_t, AutoMine.target.field_70163_u, AutoMine.target.field_70161_v)) && AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(AutoMine.target.field_70165_t, AutoMine.target.field_70163_u, AutoMine.target.field_70161_v)).func_177230_c() != Blocks.field_150350_a) {
                return;
            }
            if (InstantMine.breakPos.equals((Object)new BlockPos(AutoMine.mc.field_71439_g.field_70165_t, AutoMine.mc.field_71439_g.field_70163_u + 2.0, AutoMine.mc.field_71439_g.field_70161_v))) {
                return;
            }
            if (InstantMine.breakPos.equals((Object)new BlockPos(AutoMine.mc.field_71439_g.field_70165_t, AutoMine.mc.field_71439_g.field_70163_u - 1.0, AutoMine.mc.field_71439_g.field_70161_v))) {
                return;
            }
            if (AutoMine.mc.field_71441_e.func_180495_p(InstantMine.breakPos).func_177230_c() == Blocks.field_150321_G) {
                return;
            }
        }
        AutoMine.mc.field_71442_b.func_180512_c(blockPos, BlockUtil.getRayTraceFacing(blockPos));
    }

    @Override
    public String getDisplayInfo() {
        if (target != null) {
            return target.func_70005_c_();
        }
        return null;
    }

    @Override
    public String onUpdate() {
        target = this.getTarget(this.range.getValue().floatValue());
        if (target == null) {
            return null;
        }
        BlockPos blockPos = new BlockPos(AutoMine.target.field_70165_t, AutoMine.target.field_70163_u, AutoMine.target.field_70161_v);
        if (!this.detection(target)) {
            if (this.db.getValue().booleanValue()) {
                if (this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 0, 1));
                } else if (this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 0, -1));
                } else if (this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(1, 0, 0));
                } else if (this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(-1, 0, 0));
                } else if (this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(2, 0, 0));
                } else if (this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(-2, 0, 0));
                } else if (this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 0, -2));
                } else if (this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 0, 2));
                } else if (this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(2, 0, 0));
                    if (InstantMine.breakPos2 == null) {
                        this.surroundMine(blockPos.func_177982_a(1, 0, 0));
                    }
                } else if (this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(-2, 0, 0));
                    if (InstantMine.breakPos2 == null) {
                        this.surroundMine(blockPos.func_177982_a(-1, 0, 0));
                    }
                } else if (this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 0, -2));
                    if (InstantMine.breakPos2 == null) {
                        this.surroundMine(blockPos.func_177982_a(0, 0, -1));
                    }
                } else if (this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 0, 2));
                    if (InstantMine.breakPos2 == null) {
                        this.surroundMine(blockPos.func_177982_a(0, 0, 1));
                    }
                } else if (this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 1, 1));
                } else if (this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 0, 1));
                } else if (this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 0, -1));
                } else if (this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(1, 0, 0));
                } else if (this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(-1, 0, 0));
                } else if (this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(1, 1, 0));
                } else if (this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(-1, 1, 0));
                } else if (this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 1, -1));
                } else if (this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(1, 1, 0));
                    if (InstantMine.breakPos2 == null) {
                        this.surroundMine(blockPos.func_177982_a(1, 0, 0));
                    }
                } else if (this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(-1, 1, 0));
                    if (InstantMine.breakPos2 == null) {
                        this.surroundMine(blockPos.func_177982_a(-1, 0, 0));
                    }
                } else if (this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 1, -1));
                    if (InstantMine.breakPos2 == null) {
                        this.surroundMine(blockPos.func_177982_a(0, 0, -1));
                    }
                } else if (this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 1, 1));
                    if (InstantMine.breakPos2 == null) {
                        this.surroundMine(blockPos.func_177982_a(0, 0, 1));
                    }
                } else if (this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(-2, 1, 0));
                } else if (this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(2, 1, 0));
                } else if (this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 1, 2));
                } else if (this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 1, -2));
                } else if (this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(-1, 2, 0));
                } else if (this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(1, 2, 0));
                } else if (this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 2, 1));
                } else if (this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() != Blocks.field_150357_h) {
                    this.surroundMine(blockPos.func_177982_a(0, 2, -1));
                }
            } else if (this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 0, 1));
            } else if (this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 0, -1));
            } else if (this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(1, 0, 0));
            } else if (this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(-1, 0, 0));
            } else if (this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(2, 0, 0));
            } else if (this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(-2, 0, 0));
            } else if (this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 0, -2));
            } else if (this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 0, 2));
            } else if (this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(2, 0, 0));
            } else if (this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(-2, 0, 0));
            } else if (this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 0, -2));
            } else if (this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 0, 2));
            } else if (this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 1, 1));
            } else if (this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 0, 1));
            } else if (this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 0, -1));
            } else if (this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(1, 0, 0));
            } else if (this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(-1, 0, 0));
            } else if (this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(1, 1, 0));
            } else if (this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(-1, 1, 0));
            } else if (this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 1, -1));
            } else if (this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(1, 1, 0));
            } else if (this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(-1, 1, 0));
            } else if (this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 1, -1));
            } else if (this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() == Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 1, 1));
            } else if (this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-2, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-2, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(-2, 1, 0));
            } else if (this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(2, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(2, 1, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(2, 1, 0));
            } else if (this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, 2)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, 2)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 1, 2));
            } else if (this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 0, -2)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 1, -2)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 1, -2));
            } else if (this.getBlock(blockPos.func_177982_a(-1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 1, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(-1, 2, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(-1, 2, 0));
            } else if (this.getBlock(blockPos.func_177982_a(1, 0, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 1, 0)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(1, 2, 0)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(1, 2, 0));
            } else if (this.getBlock(blockPos.func_177982_a(0, 0, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, 1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 2, 1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 2, 1));
            } else if (this.getBlock(blockPos.func_177982_a(0, 0, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 1, -1)).func_177230_c() != Blocks.field_150357_h && this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() != Blocks.field_150350_a && this.getBlock(blockPos.func_177982_a(0, 2, -1)).func_177230_c() != Blocks.field_150357_h) {
                this.surroundMine(blockPos.func_177982_a(0, 2, -1));
            }
        }
        if (this.toggle.getValue().booleanValue()) {
            this.disable();
        }
        return null;
    }

    private IBlockState getBlock(BlockPos blockPos) {
        return AutoMine.mc.field_71441_e.func_180495_p(blockPos);
    }

    public AutoMine() {
        super("AutoCity", "Automatically breaks the enemy's hole", Module.Category.COMBAT, true, false, false);
        this.range = this.register(new Setting<Float>("Range", Float.valueOf(5.0f), Float.valueOf(1.0f), Float.valueOf(8.0f)));
        this.toggle = this.register(new Setting<Boolean>("Toggle", false));
    }

    private EntityPlayer getTarget(double d) {
        EntityPlayer entityPlayer = null;
        double d2 = Math.pow(d, 2.0) + 1.0;
        for (EntityPlayer entityPlayer2 : AutoMine.mc.field_71441_e.field_73010_i) {
            if (EntityUtil.isntValid((Entity)entityPlayer2, d) || Storm.speedManager.getPlayerSpeed(entityPlayer2) > 10.0) continue;
            if (entityPlayer == null) {
                entityPlayer = entityPlayer2;
                d2 = AutoMine.mc.field_71439_g.func_70068_e((Entity)entityPlayer2);
                continue;
            }
            if (AutoMine.mc.field_71439_g.func_70068_e((Entity)entityPlayer2) >= d2) continue;
            entityPlayer = entityPlayer2;
            d2 = AutoMine.mc.field_71439_g.func_70068_e((Entity)entityPlayer2);
        }
        return entityPlayer;
    }

    private boolean detection(EntityPlayer entityPlayer) {
        return AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t + 1.2, entityPlayer.field_70163_u, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t + 1.2, entityPlayer.field_70163_u + 1.0, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a || AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t - 1.2, entityPlayer.field_70163_u, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t - 1.2, entityPlayer.field_70163_u + 1.0, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a || AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u, entityPlayer.field_70161_v + 1.2)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u + 1.0, entityPlayer.field_70161_v + 1.2)).func_177230_c() == Blocks.field_150350_a || AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u, entityPlayer.field_70161_v - 1.2)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u + 1.0, entityPlayer.field_70161_v - 1.2)).func_177230_c() == Blocks.field_150350_a || AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t + 2.2, entityPlayer.field_70163_u + 1.0, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t + 2.2, entityPlayer.field_70163_u, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t + 1.2, entityPlayer.field_70163_u, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a || AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t - 2.2, entityPlayer.field_70163_u + 1.0, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t - 2.2, entityPlayer.field_70163_u, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t - 1.2, entityPlayer.field_70163_u, entityPlayer.field_70161_v)).func_177230_c() == Blocks.field_150350_a || AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u + 1.0, entityPlayer.field_70161_v + 2.2)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u, entityPlayer.field_70161_v + 2.2)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u, entityPlayer.field_70161_v + 1.2)).func_177230_c() == Blocks.field_150350_a || AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u + 1.0, entityPlayer.field_70161_v - 2.2)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u, entityPlayer.field_70161_v - 2.2)).func_177230_c() == Blocks.field_150350_a & AutoMine.mc.field_71441_e.func_180495_p(new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u, entityPlayer.field_70161_v - 1.2)).func_177230_c() == Blocks.field_150350_a;
    }
}

