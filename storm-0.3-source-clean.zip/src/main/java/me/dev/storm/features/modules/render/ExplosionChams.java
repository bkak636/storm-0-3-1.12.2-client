/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.features.modules.render;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import me.dev.storm.event.events.Render3DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import org.lwjgl.opengl.GL11;

public class ExplosionChams
extends Module {
    public final Setting<Boolean> syncColor = this.register(new Setting<Boolean>("Sync", false));
    public final Setting<Color> daColor = this.register(new Setting<Color>("Color", new Color(255, 255, 255, 255)));
    public static Color color8;
    public static HashMap<UUID, Thingering> thingers;

    public ExplosionChams() {
        super("ExplosionChams", "Renders a circle around newly spawned entities.", Module.Category.RENDER, true, false, false);
    }

    @Override
    public String onUpdate() {
        if (ExplosionChams.fullNullCheck()) {
            // empty if block
        }
        color8 = this.syncColor.getValue() != false ? ExplosionChams.globalColor(255) : this.daColor.getValue();
        for (Entity entity : ExplosionChams.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityEnderCrystal) || thingers.containsKey(entity.func_110124_au())) continue;
            thingers.put(entity.func_110124_au(), new Thingering(this, entity));
            ExplosionChams.thingers.get((Object)entity.func_110124_au()).starTime = System.currentTimeMillis();
        }
        return null;
    }

    @Override
    public void onRender3D(Render3DEvent Render3DEvent2) {
        if (ExplosionChams.mc.field_71439_g == null || ExplosionChams.mc.field_71441_e == null) {
            return;
        }
        for (Map.Entry<UUID, Thingering> entry : thingers.entrySet()) {
            if (System.currentTimeMillis() - entry.getValue().starTime >= 1500L) continue;
            float opacity = Float.intBitsToFloat(Float.floatToIntBits(1.2886874E38f) ^ 0x7EC1E66F);
            long time = System.currentTimeMillis();
            long duration = time - entry.getValue().starTime;
            if (duration < 1500L) {
                opacity = Float.intBitsToFloat(Float.floatToIntBits(13.7902155f) ^ 0x7EDCA4B9) - (float)duration / Float.intBitsToFloat(Float.floatToIntBits(6.1687006E-4f) ^ 0x7E9A3573);
            }
            ExplosionChams.drawCircle(entry.getValue().entity, Render3DEvent2.getPartialTicks(), Double.longBitsToDouble(Double.doubleToLongBits(205.3116845075892) ^ 0x7F89A9F951C9D87FL), (float)(System.currentTimeMillis() - entry.getValue().starTime) / Float.intBitsToFloat(Float.floatToIntBits(0.025765074f) ^ 0x7E1B1147), opacity);
        }
    }

    public static void drawCircle(Entity entity, float partialTicks, double rad, float plusY, float alpha) {
        Color color = new Color(color8.getRed(), color8.getGreen(), color8.getBlue());
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        ExplosionChams.startSmooth();
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glLineWidth((float)Float.intBitsToFloat(Float.floatToIntBits(0.8191538f) ^ 0x7F11B410));
        GL11.glBegin((int)3);
        double x = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)partialTicks - ExplosionChams.mc.func_175598_ae().field_78730_l;
        double y = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)partialTicks - ExplosionChams.mc.func_175598_ae().field_78731_m;
        double z = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)partialTicks - ExplosionChams.mc.func_175598_ae().field_78728_n;
        float r = Float.intBitsToFloat(Float.floatToIntBits(3180.4917f) ^ 0x7EC6475F) * (float)color.getRed();
        float g = Float.intBitsToFloat(Float.floatToIntBits(4554.3037f) ^ 0x7E0ED2EF) * (float)color.getGreen();
        float b = Float.intBitsToFloat(Float.floatToIntBits(29994.996f) ^ 0x7D6AD57F) * (float)color.getBlue();
        double pix2 = Double.longBitsToDouble(Double.doubleToLongBits(0.12418750450734782) ^ 0x7FA6EB3BC22A7D2FL);
        for (int i = 0; i <= 90; ++i) {
            GL11.glColor4f((float)r, (float)g, (float)b, (float)alpha);
            GL11.glVertex3d((double)(x + rad * Math.cos((double)i * Double.longBitsToDouble(Double.doubleToLongBits(0.038923223119235344) ^ 0x7FBACC45F0F011C7L) / Double.longBitsToDouble(Double.doubleToLongBits(0.010043755046771538) ^ 0x7FC211D1FBA3AC6BL))), (double)(y + (double)(plusY / Float.intBitsToFloat(Float.floatToIntBits(0.13022153f) ^ 0x7F2558CB))), (double)(z + rad * Math.sin((double)i * Double.longBitsToDouble(Double.doubleToLongBits(0.012655047216797511) ^ 0x7F90CB18FB234FBFL) / Double.longBitsToDouble(Double.doubleToLongBits(0.00992417958121009) ^ 0x7FC2D320D5ED6BD3L))));
        }
        GL11.glEnd();
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2929);
        ExplosionChams.endSmooth();
        GL11.glEnable((int)3553);
        GL11.glPopMatrix();
    }

    public static void startSmooth() {
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2881);
        GL11.glEnable((int)2832);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glHint((int)3153, (int)4354);
    }

    public static void endSmooth() {
        GL11.glDisable((int)2848);
        GL11.glDisable((int)2881);
        GL11.glEnable((int)2832);
    }

    static {
        thingers = new HashMap();
    }

    public class Thingering {
        public Entity entity;
        public long starTime;
        public ExplosionChams this$0;

        public Thingering(ExplosionChams this$02, Entity entity) {
            this.this$0 = this$02;
            this.entity = entity;
            this.starTime = 0L;
        }
    }
}

