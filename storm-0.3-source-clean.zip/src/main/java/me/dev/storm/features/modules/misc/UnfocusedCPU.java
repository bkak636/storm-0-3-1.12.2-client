/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.misc;

import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;

public class UnfocusedCPU
extends Module {
    public static UnfocusedCPU INSTANCE;
    public Setting<Integer> unfocusedFps = this.register(new Setting<Integer>("UnfocusedFPS", 5, 1, 30));

    public UnfocusedCPU() {
        super("UnfocusedCPU", "Decreases your framerate when minecraft is unfocused.", Module.Category.MISC, false, false, false);
        INSTANCE = this;
    }
}

