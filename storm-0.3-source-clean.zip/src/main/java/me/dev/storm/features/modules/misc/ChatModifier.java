/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.network.play.client.CPacketChatMessage
 *  net.minecraft.network.play.server.SPacketChat
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.storm.event.events.PacketEvent;
import me.dev.storm.features.command.Command;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.Timer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ChatModifier
extends Module {
    public Setting<Boolean> antiUnicode = this.register(new Setting<Boolean>("AntiUnicode", Boolean.valueOf(true), "Blocks "));
    public Setting<Integer> maxSymbolCount = this.register(new Setting<Integer>("MaxUnicodeCount", 100, 1, 250));
    public Setting<Boolean> greenT = this.register(new Setting<Boolean>("GreenText", false));
    public Setting<Suffix> suffix = this.register(new Setting<Suffix>("Suffix", Suffix.NONE, "Your Suffix."));
    public Setting<Boolean> clean = this.register(new Setting<Boolean>("CleanChat", Boolean.valueOf(false), "Cleans your chat"));
    public Setting<Boolean> infinite = this.register(new Setting<Boolean>("Infinite", Boolean.valueOf(false), "Makes your chat infinite."));
    private final Timer timer = new Timer();
    private final Timer delay = new Timer();
    private static ChatModifier INSTANCE = new ChatModifier();

    public ChatModifier() {
        super("ChatModifier", "Modifies your chat.", Module.Category.MISC, true, false, false);
        this.setInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public static ChatModifier getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ChatModifier();
        }
        return INSTANCE;
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getStage() == 0 && event.getPacket() instanceof CPacketChatMessage) {
            CPacketChatMessage packet = (CPacketChatMessage)event.getPacket();
            String s = packet.func_149439_c();
            if (s.startsWith("/")) {
                return;
            }
            switch (this.suffix.getValue()) {
                case STORM: {
                    s = s + " S\u1d1b\u1d0f\u0280\u1d0d";
                    break;
                }
                case DOTGOD: {
                    s = s + " \u1d05\u1d0f\u1d1b\u0262\u1d0f\u1d05";
                    break;
                }
                case PYRO: {
                    s = s + " \u1d18\u028f\u0280\u1d0f";
                    break;
                }
                case FUTURE: {
                    s = s + " future";
                }
            }
            if (this.greenT.getValue().booleanValue()) {
                s = "> " + s;
            }
            if (s.length() >= 256) {
                s = s.substring(0, 256);
            }
            packet.field_149440_a = s;
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        if (this.antiUnicode.getValue().booleanValue() && event.getPacket() instanceof SPacketChat) {
            String text = ((SPacketChat)event.getPacket()).field_148919_a.func_150254_d();
            int symbolCount = 0;
            for (int i = 0; i < text.length(); ++i) {
                char c = text.charAt(i);
                if (this.isSymbol(c)) {
                    ++symbolCount;
                }
                if (symbolCount <= this.maxSymbolCount.getValue()) continue;
                if (this.delay.passed(10L)) {
                    Command.sendMessage(ChatFormatting.GREEN + "Unicode message blocked!");
                    this.delay.reset();
                }
                event.setCanceled(true);
                break;
            }
        }
    }

    private boolean isSymbol(char charIn) {
        return !(charIn >= 'A' && charIn <= 'Z' || charIn >= 'a' && charIn <= 'z' || charIn >= '0' && charIn <= '9');
    }

    public static enum Suffix {
        NONE,
        STORM,
        DOTGOD,
        PYRO,
        FUTURE;

    }
}

