/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.client.gui.GuiHopper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 */
package me.dev.storm.features.modules.combat;

import me.dev.storm.Storm;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.combat.autocity.InstantMine;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.EntityUtil;
import me.dev.storm.util.trollhack.BlockUtil;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public class AntiBurrow
extends Module {
    public static BlockPos pos;
    private final Setting<Double> range = this.register(new Setting<Double>("Range", 5.0, 1.0, 8.0));
    private final Setting<Boolean> toggle = this.register(new Setting<Boolean>("Toggle", false));

    private boolean isOnLiquid() {
        double d = AntiBurrow.mc.field_71439_g.field_70163_u - 0.03;
        for (int i = MathHelper.func_76128_c((double)AntiBurrow.mc.field_71439_g.field_70165_t); i < MathHelper.func_76143_f((double)AntiBurrow.mc.field_71439_g.field_70165_t); ++i) {
            for (int j = MathHelper.func_76128_c((double)AntiBurrow.mc.field_71439_g.field_70161_v); j < MathHelper.func_76143_f((double)AntiBurrow.mc.field_71439_g.field_70161_v); ++j) {
                BlockPos blockPos = new BlockPos(i, MathHelper.func_76128_c((double)d), j);
                if (!(AntiBurrow.mc.field_71441_e.func_180495_p(blockPos).func_177230_c() instanceof BlockLiquid)) continue;
                return true;
            }
        }
        return false;
    }

    private boolean isInLiquid() {
        double d = AntiBurrow.mc.field_71439_g.field_70163_u + 0.01;
        for (int i = MathHelper.func_76128_c((double)AntiBurrow.mc.field_71439_g.field_70165_t); i < MathHelper.func_76143_f((double)AntiBurrow.mc.field_71439_g.field_70165_t); ++i) {
            for (int j = MathHelper.func_76128_c((double)AntiBurrow.mc.field_71439_g.field_70161_v); j < MathHelper.func_76143_f((double)AntiBurrow.mc.field_71439_g.field_70161_v); ++j) {
                BlockPos blockPos = new BlockPos(i, (int)d, j);
                if (!(AntiBurrow.mc.field_71441_e.func_180495_p(blockPos).func_177230_c() instanceof BlockLiquid)) continue;
                return true;
            }
        }
        return false;
    }

    @Override
    public String onUpdate() {
        if (AntiBurrow.fullNullCheck()) {
            return null;
        }
        if (AntiBurrow.mc.field_71462_r instanceof GuiHopper) {
            return null;
        }
        EntityPlayer entityPlayer = this.getTarget(this.range.getValue());
        if (this.toggle.getValue().booleanValue()) {
            this.disable();
        }
        if (entityPlayer == null) {
            return null;
        }
        pos = new BlockPos(entityPlayer.field_70165_t, entityPlayer.field_70163_u + 0.5, entityPlayer.field_70161_v);
        if (InstantMine.breakPos != null) {
            if (InstantMine.breakPos.equals((Object)pos)) {
                return null;
            }
            if (InstantMine.breakPos.equals((Object)new BlockPos(AntiBurrow.mc.field_71439_g.field_70165_t, AntiBurrow.mc.field_71439_g.field_70163_u + 2.0, AntiBurrow.mc.field_71439_g.field_70161_v))) {
                return null;
            }
            if (InstantMine.breakPos.equals((Object)new BlockPos(AntiBurrow.mc.field_71439_g.field_70165_t, AntiBurrow.mc.field_71439_g.field_70163_u - 1.0, AntiBurrow.mc.field_71439_g.field_70161_v))) {
                return null;
            }
            if (AntiBurrow.mc.field_71441_e.func_180495_p(InstantMine.breakPos).func_177230_c() == Blocks.field_150321_G) {
                return null;
            }
        }
        if (AntiBurrow.mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150350_a && AntiBurrow.mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150321_G && AntiBurrow.mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150488_af && !this.isOnLiquid() && !this.isInLiquid() && AntiBurrow.mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150355_j && AntiBurrow.mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150353_l) {
            AntiBurrow.mc.field_71442_b.func_180512_c(pos, BlockUtil.getRayTraceFacing(pos));
        }
        return null;
    }

    public AntiBurrow() {
        super("AntiBurrow", "AntiBurrow", Module.Category.COMBAT, true, false, false);
    }

    private EntityPlayer getTarget(double d) {
        EntityPlayer entityPlayer = null;
        double d2 = Math.pow(d, 2.0) + 1.0;
        for (EntityPlayer entityPlayer2 : AntiBurrow.mc.field_71441_e.field_73010_i) {
            if (EntityUtil.isntValid((Entity)entityPlayer2, d) || Storm.speedManager.getPlayerSpeed(entityPlayer2) > 10.0) continue;
            if (entityPlayer == null) {
                entityPlayer = entityPlayer2;
                d2 = AntiBurrow.mc.field_71439_g.func_70068_e((Entity)entityPlayer2);
                continue;
            }
            if (AntiBurrow.mc.field_71439_g.func_70068_e((Entity)entityPlayer2) >= d2) continue;
            entityPlayer = entityPlayer2;
            d2 = AntiBurrow.mc.field_71439_g.func_70068_e((Entity)entityPlayer2);
        }
        return entityPlayer;
    }
}

