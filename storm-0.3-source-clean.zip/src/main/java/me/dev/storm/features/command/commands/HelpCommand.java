/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package me.dev.storm.features.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.storm.Storm;
import me.dev.storm.features.command.Command;

public class HelpCommand
extends Command {
    public HelpCommand() {
        super("help");
    }

    @Override
    public void execute(String[] commands) {
        HelpCommand.sendMessage("Commands: ");
        for (Command command : Storm.commandManager.getCommands()) {
            HelpCommand.sendMessage(ChatFormatting.GRAY + Storm.commandManager.getPrefix() + command.getName());
        }
    }
}

