package me.dev.storm.features.command.commands;

import me.dev.storm.features.command.Command;

public abstract class BackupCommand extends Command {

    public BackupCommand() {
        super("backup");
    }

    public void onEnable() {
        Command.sendMessage("Backup command is currently disabled for security reasons.");
    }

    public String serverCheck() {
        String ip = mc.func_71356_B() ? "SinglePlayer" : BackupCommand.mc.func_147104_D().field_78845_b;
        return ip;
    }

    public String dimensionCheck() {
        int dimension = BackupCommand.mc.field_71439_g.field_71093_bK;
        String dim = dimension == 0 ? "Overworld" : (dimension == -1 ? "Nether" : "End");
        return dim;
    }
}
