/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBow
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.potion.PotionUtils
 */
package me.dev.storm.features.modules.combat;

import java.util.List;
import java.util.Objects;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.InventoryUtil;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.potion.PotionUtils;

public class Quiver
extends Module {
    private final Setting<Integer> tickDelay = this.register(new Setting<Integer>("TickDelay", 3, 0, 8));

    public Quiver() {
        super("Quiver", "Rotates and shoots yourself with good potion effects", Module.Category.COMBAT, true, false, false);
    }

    @Override
    public String onUpdate() {
        if (Quiver.mc.field_71439_g != null) {
            List<Integer> arrowSlots;
            if (Quiver.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow && Quiver.mc.field_71439_g.func_184587_cr() && Quiver.mc.field_71439_g.func_184612_cw() >= this.tickDelay.getValue()) {
                Quiver.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(Quiver.mc.field_71439_g.field_71109_bG, -90.0f, Quiver.mc.field_71439_g.field_70122_E));
                Quiver.mc.field_71442_b.func_78766_c((EntityPlayer)Quiver.mc.field_71439_g);
            }
            if ((arrowSlots = InventoryUtil.getItemInventory(Items.field_185167_i)).get(0) == -1) {
                return null;
            }
            int speedSlot = -1;
            int strengthSlot = -1;
            for (Integer slot : arrowSlots) {
                if (PotionUtils.func_185191_c((ItemStack)Quiver.mc.field_71439_g.field_71071_by.func_70301_a(slot.intValue())).getRegistryName().func_110623_a().contains("swiftness")) {
                    speedSlot = slot;
                    continue;
                }
                if (!Objects.requireNonNull(PotionUtils.func_185191_c((ItemStack)Quiver.mc.field_71439_g.field_71071_by.func_70301_a(slot.intValue())).getRegistryName()).func_110623_a().contains("strength")) continue;
                strengthSlot = slot;
            }
        }
        return null;
    }

    @Override
    public void onEnable() {
    }

    private int findBow() {
        return InventoryUtil.getItemHotbar((Item)Items.field_151031_f);
    }

    @Override
    public String getDisplayInfo() {
        return "Active";
    }
}

