/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.settings.KeyBinding
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.features.modules.Module;
import net.minecraft.client.settings.KeyBinding;

public class AutoWalk
extends Module {
    public AutoWalk() {
        super("AutoWalk", "Automatically walks in a straight line", Module.Category.MOVEMENT, true, false, false);
    }

    @Override
    public String onUpdate() {
        KeyBinding.func_74510_a((int)AutoWalk.mc.field_71474_y.field_74351_w.func_151463_i(), (boolean)true);
        return null;
    }

    @Override
    public void onDisable() {
        KeyBinding.func_74510_a((int)AutoWalk.mc.field_71474_y.field_74351_w.func_151463_i(), (boolean)false);
    }
}

