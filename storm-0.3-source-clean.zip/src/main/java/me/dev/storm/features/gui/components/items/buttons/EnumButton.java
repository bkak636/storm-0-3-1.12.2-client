/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.client.audio.ISound
 *  net.minecraft.client.audio.PositionedSoundRecord
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.util.SoundEvent
 */
package me.dev.storm.features.gui.components.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Objects;
import me.dev.storm.Storm;
import me.dev.storm.features.gui.StormGui;
import me.dev.storm.features.gui.components.items.buttons.Button;
import me.dev.storm.features.modules.client.ClickGui;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.RenderUtil;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundEvent;

public class EnumButton
extends Button {
    public Setting setting;

    public EnumButton(Setting setting) {
        super(setting.getName());
        this.setting = setting;
        this.width = 15;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        boolean dotgod;
        boolean newStyle = ClickGui.getInstance().style.getValue() == ClickGui.Style.NEW || ClickGui.getInstance().style.getValue() == ClickGui.Style.DOTGOD;
        boolean future = ClickGui.getInstance().style.getValue() == ClickGui.Style.FUTURE;
        boolean bl = dotgod = ClickGui.getInstance().style.getValue() == ClickGui.Style.DOTGOD;
        if (future) {
            RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4f, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(99) : Storm.colorManager.getCurrentWithAlpha(120)) : (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(26) : Storm.colorManager.getCurrentWithAlpha(55)));
        } else if (dotgod) {
            RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4f, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(65) : Storm.colorManager.getCurrentWithAlpha(90)) : (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getCurrentWithAlpha(26) : Storm.colorManager.getCurrentWithAlpha(35)));
        } else {
            RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4f, this.y + (float)this.height - 0.5f, this.getState() ? (!this.isHovering(mouseX, mouseY) ? Storm.colorManager.getColorWithAlpha(Storm.moduleManager.getModuleByClass(ClickGui.class).hoverAlpha.getValue()) : Storm.colorManager.getColorWithAlpha(Storm.moduleManager.getModuleByClass(ClickGui.class).alpha.getValue())) : (!this.isHovering(mouseX, mouseY) ? 0x11555555 : -2007673515));
            Storm.textManager.drawStringWithShadow((newStyle ? this.setting.getName().toLowerCase() + ":" : this.setting.getName()) + " " + ChatFormatting.GRAY + (this.setting.getCurrentEnumName().equalsIgnoreCase("ABC") ? "ABC" : this.setting.getCurrentEnumName()), this.x + 2.3f, this.y - 1.7f - (float)StormGui.getInstance().getTextOffset(), this.getState() ? -1 : -5592406);
            int y = (int)this.y;
            if (this.setting.open) {
                for (Object o : this.setting.getValue().getClass().getEnumConstants()) {
                    String s = !Objects.equals(o.toString(), "ABC") ? Character.toUpperCase(o.toString().charAt(0)) + o.toString().toLowerCase().substring(1) : o.toString();
                    Storm.textManager.drawStringWithShadow((this.setting.getCurrentEnumName().equals(s) ? ChatFormatting.WHITE : ChatFormatting.GRAY) + s, (float)this.width / 2.0f - (float)Storm.textManager.getStringWidth(s) / 2.0f + 2.0f + this.x, (float)(y += 12) + 6.0f - (float)EnumButton.mc.field_71466_p.field_78288_b / 2.0f + 3.5f, -1);
                }
            }
        }
    }

    @Override
    public void update() {
        this.setHidden(!this.setting.isVisible());
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (this.isHovering(mouseX, mouseY)) {
            mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a((SoundEvent)SoundEvents.field_187909_gi, (float)1.0f));
        }
    }

    @Override
    public int getHeight() {
        return 14;
    }

    @Override
    public void toggle() {
        this.setting.increaseEnum();
    }

    @Override
    public boolean getState() {
        return true;
    }
}

