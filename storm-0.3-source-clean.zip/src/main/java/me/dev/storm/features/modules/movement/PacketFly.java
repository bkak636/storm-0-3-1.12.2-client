/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.features.modules.Module;

public class PacketFly
extends Module {
    public PacketFly() {
        super("PacketFly", "PacketFly.", Module.Category.MOVEMENT, true, false, false);
    }
}

