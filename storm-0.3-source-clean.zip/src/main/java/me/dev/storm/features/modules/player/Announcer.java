/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemAppleGold
 *  net.minecraft.item.ItemFood
 *  net.minecraftforge.event.entity.living.LivingEntityUseItemEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.player;

import java.text.DecimalFormat;
import java.util.concurrent.ThreadLocalRandom;
import me.dev.storm.event.events.BlockDestructionEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemFood;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Announcer
extends Module {
    public static int blockBrokeDelay = 0;
    static int blockPlacedDelay = 0;
    static int jumpDelay = 0;
    static int attackDelay = 0;
    static int eattingDelay = 0;
    static long lastPositionUpdate;
    static double lastPositionX;
    static double lastPositionY;
    static double lastPositionZ;
    private static double speed;
    String heldItem = "";
    int blocksPlaced = 0;
    int blocksBroken = 0;
    int eaten = 0;
    public static String walkMessage;
    public static String breakMessage;
    public static String eatMessage;
    private final Setting<Boolean> move = this.register(new Setting<Boolean>("Move", false));
    private final Setting<Boolean> breakBlock = this.register(new Setting<Boolean>("Break", false));
    private final Setting<Boolean> eat = this.register(new Setting<Boolean>("Eat", false));
    private final Setting<Double> delay = this.register(new Setting<Double>("Delay", 1.0, 1.0, 20.0));

    public Announcer() {
        super("Announcer", "flood chat wit da cheat on baby", Module.Category.PLAYER, false, false, false);
    }

    @Override
    public String onUpdate() {
        ++blockBrokeDelay;
        ++blockPlacedDelay;
        ++jumpDelay;
        ++attackDelay;
        ++eattingDelay;
        this.heldItem = Announcer.mc.field_71439_g.func_184614_ca().func_82833_r();
        if (this.move.getValue().booleanValue() && (double)lastPositionUpdate + 5000.0 * this.delay.getValue() < (double)System.currentTimeMillis()) {
            double d0 = lastPositionX - Announcer.mc.field_71439_g.field_70142_S;
            double d2 = lastPositionY - Announcer.mc.field_71439_g.field_70137_T;
            double d3 = lastPositionZ - Announcer.mc.field_71439_g.field_70136_U;
            speed = Math.sqrt(d0 * d0 + d2 * d2 + d3 * d3);
            if (!(speed <= 1.0) && !(speed > 5000.0)) {
                String walkAmount = new DecimalFormat("0").format(speed);
                Announcer.mc.field_71439_g.func_71165_d(walkMessage.replace("{blocks}", walkAmount));
            }
            lastPositionUpdate = System.currentTimeMillis();
            lastPositionX = Announcer.mc.field_71439_g.field_70142_S;
            lastPositionY = Announcer.mc.field_71439_g.field_70137_T;
            lastPositionZ = Announcer.mc.field_71439_g.field_70136_U;
        }
        return null;
    }

    @SubscribeEvent
    public void onItemUse(LivingEntityUseItemEvent event) {
        int randomNum = ThreadLocalRandom.current().nextInt(1, 11);
        if (event.getEntity() == Announcer.mc.field_71439_g && (event.getItem().func_77973_b() instanceof ItemFood || event.getItem().func_77973_b() instanceof ItemAppleGold)) {
            ++this.eaten;
            if ((double)eattingDelay >= 300.0 * this.delay.getValue() && this.eat.getValue().booleanValue() && this.eaten > randomNum) {
                Announcer.mc.field_71439_g.func_71165_d(eatMessage.replace("{amount}", this.eaten + "").replace("{name}", Announcer.mc.field_71439_g.func_184614_ca().func_82833_r()));
                this.eaten = 0;
                eattingDelay = 0;
            }
        }
    }

    @SubscribeEvent
    public void onBlockBreak(BlockDestructionEvent event) {
        ++this.blocksBroken;
        int randomNum = ThreadLocalRandom.current().nextInt(1, 11);
        if ((double)blockBrokeDelay >= 300.0 * this.delay.getValue()) {
            if (this.breakBlock.getValue().booleanValue() && this.blocksBroken > randomNum) {
                String msg = breakMessage.replace("{amount}", this.blocksBroken + "").replace("{name}", Announcer.mc.field_71441_e.func_180495_p(event.getBlockPos()).func_177230_c().func_149732_F());
                Announcer.mc.field_71439_g.func_71165_d(msg);
            }
            this.blocksBroken = 0;
            blockBrokeDelay = 0;
        }
    }

    static {
        walkMessage = "I just moved {blocks} blocks thanks to storm";
        breakMessage = "I just broke {amount} {name} thanks to storm";
        eatMessage = "I just ate {amount} {name} thanks to storm";
    }
}

