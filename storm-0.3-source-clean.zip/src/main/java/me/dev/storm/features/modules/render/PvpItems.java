/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 */
package me.dev.storm.features.modules.render;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.storm.Storm;
import me.dev.storm.event.events.Render2DEvent;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.client.ClickGui;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.ColorUtil;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class PvpItems
extends Module {
    public Setting<Boolean> watermark = this.register(new Setting<Boolean>("watermark", true));
    public Setting<Integer> X = this.register(new Setting<Integer>("X", 0, 0, 950));
    public Setting<Integer> Y = this.register(new Setting<Integer>("Y", 10, 0, 550));
    public static PvpItems INSTANCE = new PvpItems();
    private int color;

    public PvpItems() {
        super("PvPItems", "items", Module.Category.RENDER, true, false, false);
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        float yOffset = (float)Storm.textManager.scaledHeight / 2.0f;
        float offset = (float)Storm.textManager.scaledHeight / 2.0f - 30.0f;
        int totemCount = PvpItems.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> itemStack.func_77973_b() == Items.field_190929_cY).mapToInt(ItemStack::func_190916_E).sum();
        int gapcount = PvpItems.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> itemStack.func_77973_b() == Items.field_151153_ao).mapToInt(ItemStack::func_190916_E).sum();
        int crystalcount = PvpItems.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> itemStack.func_77973_b() == Items.field_185158_cP).mapToInt(ItemStack::func_190916_E).sum();
        int xpcount = PvpItems.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> itemStack.func_77973_b() == Items.field_151062_by).mapToInt(ItemStack::func_190916_E).sum();
        if (PvpItems.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
            totemCount += PvpItems.mc.field_71439_g.func_184592_cb().func_190916_E();
        }
        String totemString = ChatFormatting.WHITE + "" + totemCount;
        String gapstring = ChatFormatting.WHITE + "" + gapcount;
        String crystalstring = ChatFormatting.WHITE + "" + crystalcount;
        String xpstring = ChatFormatting.WHITE + "" + xpcount;
        this.color = ClickGui.INSTANCE.rainbow.getValue() != false && ClickGui.INSTANCE.rainbowModeHud.getValue() == ClickGui.rainbowMode.Static ? ColorUtil.rainbow(ClickGui.INSTANCE.rainbowHue.getValue()).getRGB() : ColorUtil.toRGBA(ClickGui.INSTANCE.red.getValue(), ClickGui.INSTANCE.green.getValue(), ClickGui.INSTANCE.blue.getValue());
        if (this.watermark.getValue().booleanValue()) {
            Storm.textManager.drawString("Storm" + ChatFormatting.WHITE + " v0.3+", 2.0f, offset, this.color, true);
        }
        Storm.textManager.drawString("Xp: " + xpstring, 2.0f, yOffset - 20.0f, this.color, true);
        Storm.textManager.drawString("Totems: " + totemString, 2.0f, yOffset - 10.0f, this.color, true);
        Storm.textManager.drawString("Gapples: " + gapstring, 2.0f, yOffset, this.color, true);
        Storm.textManager.drawString("Crystals: " + crystalstring, 2.0f, yOffset + 10.0f, this.color, true);
    }
}

