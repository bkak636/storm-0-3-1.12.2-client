/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.effect.EntityLightningBolt
 *  net.minecraft.entity.monster.EntityMob
 *  net.minecraft.entity.monster.EntitySlime
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.world.World
 *  net.minecraftforge.event.entity.living.LivingDeathEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.dev.storm.features.modules.render;

import java.util.ArrayList;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class KillEffects
extends Module {
    public Setting<Boolean> thunder = this.register(new Setting<Boolean>("Thunder", true));
    public Setting<Integer> numbersThunder = this.register(new Setting<Integer>("Number Thunder", 1, 1, 10));
    public Setting<Boolean> sound = this.register(new Setting<Boolean>("Sound", true));
    public Setting<Integer> numberSound = this.register(new Setting<Integer>("Number Sound", 1, 1, 10));
    public Setting<Integer> timeActive = this.register(new Setting<Integer>("TimeActive", 20, 0, 50));
    public Setting<Boolean> lightning = this.register(new Setting<Boolean>("Lightning", true));
    public Setting<Boolean> totemPop = this.register(new Setting<Boolean>("TotemPop", true));
    public Setting<Boolean> totemPopSound = this.register(new Setting<Boolean>("TotemPopSound", false));
    public Setting<Boolean> firework = this.register(new Setting<Boolean>("FireWork", false));
    public Setting<Boolean> fire = this.register(new Setting<Boolean>("Fire", false));
    public Setting<Boolean> water = this.register(new Setting<Boolean>("Water", false));
    public Setting<Boolean> smoke = this.register(new Setting<Boolean>("Smoke", false));
    public Setting<Boolean> players = this.register(new Setting<Boolean>("Players", true));
    public Setting<Boolean> animals = this.register(new Setting<Boolean>("Animals", true));
    public Setting<Boolean> mobs = this.register(new Setting<Boolean>("Mobs", true));
    public Setting<Boolean> all = this.register(new Setting<Boolean>("All", true));
    ArrayList<EntityPlayer> playersDead = new ArrayList();
    final Object sync = new Object();

    public KillEffects() {
        super("KillEffects", "When you kill something it spawns shit.", Module.Category.RENDER, true, false, false);
    }

    @Override
    public void onEnable() {
        this.playersDead.clear();
    }

    @Override
    public String onUpdate() {
        if (KillEffects.mc.field_71441_e == null) {
            this.playersDead.clear();
            return null;
        }
        KillEffects.mc.field_71441_e.field_73010_i.forEach(entity -> {
            if (this.playersDead.contains(entity)) {
                if (entity.func_110143_aJ() > 0.0f) {
                    this.playersDead.remove(entity);
                }
            } else if (entity.func_110143_aJ() == 0.0f) {
                int i;
                if (this.thunder.getValue().booleanValue()) {
                    for (i = 0; i < this.numbersThunder.getValue(); ++i) {
                        KillEffects.mc.field_71441_e.func_72838_d((Entity)new EntityLightningBolt((World)KillEffects.mc.field_71441_e, entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, true));
                    }
                }
                if (this.sound.getValue().booleanValue()) {
                    for (i = 0; i < this.numberSound.getValue(); ++i) {
                        KillEffects.mc.field_71439_g.func_184185_a(SoundEvents.field_187754_de, 0.5f, 1.0f);
                    }
                }
                this.playersDead.add((EntityPlayer)entity);
            }
        });
        return null;
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        if (event.getEntity() == KillEffects.mc.field_71439_g) {
            return;
        }
        if (this.shouldRenderParticle(event.getEntity())) {
            if (this.lightning.getValue().booleanValue()) {
                KillEffects.mc.field_71441_e.func_73027_a(-999, (Entity)new EntityLightningBolt((World)KillEffects.mc.field_71441_e, event.getEntity().field_70165_t, event.getEntity().field_70163_u, event.getEntity().field_70161_v, true));
            }
            if (this.totemPop.getValue().booleanValue()) {
                this.totemPop(event.getEntity());
            }
            if (this.firework.getValue().booleanValue()) {
                KillEffects.mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.FIREWORKS_SPARK, this.timeActive.getValue().intValue());
            }
            if (this.fire.getValue().booleanValue()) {
                KillEffects.mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.FLAME, this.timeActive.getValue().intValue());
                KillEffects.mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.DRIP_LAVA, this.timeActive.getValue().intValue());
            }
            if (this.water.getValue().booleanValue()) {
                KillEffects.mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.WATER_BUBBLE, this.timeActive.getValue().intValue());
                KillEffects.mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.WATER_DROP, this.timeActive.getValue().intValue());
            }
            if (this.smoke.getValue().booleanValue()) {
                KillEffects.mc.field_71452_i.func_191271_a(event.getEntity(), EnumParticleTypes.SMOKE_NORMAL, this.timeActive.getValue().intValue());
            }
        }
    }

    public boolean shouldRenderParticle(Entity entity) {
        return entity != KillEffects.mc.field_71439_g && (this.all.getValue() != false || entity instanceof EntityPlayer && this.players.getValue() != false || entity instanceof EntityMob || entity instanceof EntitySlime && this.mobs.getValue() != false || entity instanceof EntityAnimal && this.animals.getValue() != false);
    }

    public void totemPop(Entity entity) {
        KillEffects.mc.field_71452_i.func_191271_a(entity, EnumParticleTypes.TOTEM, this.timeActive.getValue().intValue());
        if (this.totemPopSound.getValue().booleanValue()) {
            KillEffects.mc.field_71441_e.func_184134_a(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, SoundEvents.field_191263_gW, entity.func_184176_by(), 1.0f, 1.0f, false);
        }
    }
}

