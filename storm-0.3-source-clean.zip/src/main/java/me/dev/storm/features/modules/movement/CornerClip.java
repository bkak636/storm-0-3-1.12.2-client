/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.math.Vec3d
 */
package me.dev.storm.features.modules.movement;

import me.dev.storm.features.modules.Module;
import me.dev.storm.features.setting.Setting;
import me.dev.storm.util.MathUtil;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.Vec3d;

public class CornerClip
extends Module {
    public final Setting<Mode> mode = this.register(new Setting<Mode>("CornerClip Mode", Mode.Vertical));
    public final Setting<VMode> vmode = this.register(new Setting<Object>("V Mode", (Object)VMode.Bypass, v -> this.mode.getValue() == Mode.Vertical));
    public final Setting<HMode> hmode = this.register(new Setting<Object>("H Mode", (Object)HMode.Normal, v -> this.mode.getValue() == Mode.Horizontal));
    public final Setting<Boolean> disables = this.register(new Setting<Boolean>("Disables", true));
    public final Setting<Integer> CornerClipAmount = this.register(new Setting<Integer>("CornerClip Amount", -3, -50, 50));
    public final Setting<Boolean> autoAdjust = this.register(new Setting<Boolean>("Auto Adjust", true));
    public final Setting<Double> offset = this.register(new Setting<Double>("Offset", -4.0, -70.0, 70.0));
    boolean isSneaking;

    public CornerClip() {
        super("Clip", "Automatically CornerClips you into blocks", Module.Category.MOVEMENT, true, false, false);
    }

    @Override
    public String onUpdate() {
        if (CornerClip.nullCheck()) {
            return null;
        }
        Vec3d dir = MathUtil.direction(CornerClip.mc.field_71439_g.field_70177_z);
        if (this.mode.getValue() == Mode.Vertical && this.vmode.getValue() == VMode.Normal) {
            CornerClip.mc.field_71439_g.func_70107_b(CornerClip.mc.field_71439_g.field_70165_t, CornerClip.mc.field_71439_g.field_70163_u + (double)this.CornerClipAmount.getValue().intValue(), CornerClip.mc.field_71439_g.field_70161_v);
            if (this.disables.getValue().booleanValue()) {
                this.disable();
            }
        }
        if (this.mode.getValue() == Mode.Horizontal && this.hmode.getValue() == HMode.Normal) {
            CornerClip.mc.field_71439_g.func_70107_b(CornerClip.mc.field_71439_g.field_70165_t + dir.field_72450_a * (double)this.CornerClipAmount.getValue().intValue(), CornerClip.mc.field_71439_g.field_70163_u, CornerClip.mc.field_71439_g.field_70161_v + dir.field_72449_c * (double)this.CornerClipAmount.getValue().intValue());
            if (this.disables.getValue().booleanValue()) {
                this.disable();
            }
        }
        if (this.mode.getValue() == Mode.Vertical && this.vmode.getValue() == VMode.Bypass) {
            if (this.autoAdjust.getValue().booleanValue()) {
                this.offset.setValue(-CornerClip.mc.field_71439_g.field_70163_u - 2.0);
            }
            if (this.isSneaking) {
                CornerClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)CornerClip.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                this.isSneaking = false;
            }
            CornerClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(CornerClip.mc.field_71439_g.field_70165_t, CornerClip.mc.field_71439_g.field_70163_u + this.offset.getValue(), CornerClip.mc.field_71439_g.field_70161_v, false));
            CornerClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(CornerClip.mc.field_71439_g.field_70165_t, CornerClip.mc.field_71439_g.field_70163_u + 0.41999998688698, CornerClip.mc.field_71439_g.field_70161_v, true));
            CornerClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(CornerClip.mc.field_71439_g.field_70165_t, CornerClip.mc.field_71439_g.field_70163_u + 0.7531999805211997, CornerClip.mc.field_71439_g.field_70161_v, true));
            CornerClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(CornerClip.mc.field_71439_g.field_70165_t, CornerClip.mc.field_71439_g.field_70163_u + 1.00133597911214, CornerClip.mc.field_71439_g.field_70161_v, true));
            CornerClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(CornerClip.mc.field_71439_g.field_70165_t, CornerClip.mc.field_71439_g.field_70163_u + 1.16610926093821, CornerClip.mc.field_71439_g.field_70161_v, true));
            CornerClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)CornerClip.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
            CornerClip.mc.field_71439_g.func_70095_a(false);
        }
        return null;
    }

    @Override
    public void onDisable() {
        if (CornerClip.mc.field_71439_g == null) {
            return;
        }
        if (this.isSneaking) {
            CornerClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)CornerClip.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
            this.isSneaking = false;
        }
    }

    @Override
    public void onEnable() {
        if (CornerClip.mc.field_71439_g == null) {
            return;
        }
        if (this.mode.getValue() == Mode.Vertical && this.vmode.getValue() == VMode.Bypass) {
            CornerClip.mc.field_71439_g.func_70664_aZ();
        }
    }

    public static enum Mode {
        Vertical,
        Horizontal;

    }

    public static enum VMode {
        Normal,
        Bypass;

    }

    public static enum HMode {
        Normal;

    }
}

