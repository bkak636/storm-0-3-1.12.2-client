/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraftforge.fml.common.Mod
 *  net.minecraftforge.fml.common.Mod$EventHandler
 *  net.minecraftforge.fml.common.Mod$Instance
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.opengl.Display
 */
package me.dev.storm;

import me.dev.storm.manager.ColorManager;
import me.dev.storm.manager.CommandManager;
import me.dev.storm.manager.ConfigManager;
import me.dev.storm.manager.EventManager;
import me.dev.storm.manager.FileManager;
import me.dev.storm.manager.FriendManager;
import me.dev.storm.manager.HoleManager;
import me.dev.storm.manager.InventoryManager;
import me.dev.storm.manager.ModuleManager;
import me.dev.storm.manager.PacketManager;
import me.dev.storm.manager.PositionManager;
import me.dev.storm.manager.PotionManager;
import me.dev.storm.manager.ReloadManager;
import me.dev.storm.manager.RotationManager;
import me.dev.storm.manager.ServerManager;
import me.dev.storm.manager.SpeedManager;
import me.dev.storm.manager.TextManager;
import me.dev.storm.manager.TotemPopManager;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

@Mod(modid="storm", name="storm", version="0.3")
public class Storm {
    public static final String MODID = "storm";
    public static final String MODNAME = "storm";
    public static final String MODVER = "0.3";
    public static final Logger LOGGER = LogManager.getLogger((String)"storm");
    public static CommandManager commandManager;
    public static TotemPopManager totemPopManager;
    public static FriendManager friendManager;
    public static ModuleManager moduleManager;
    public static PacketManager packetManager;
    public static ColorManager colorManager;
    public static HoleManager holeManager;
    public static InventoryManager inventoryManager;
    public static PotionManager potionManager;
    public static RotationManager rotationManager;
    public static PositionManager positionManager;
    public static SpeedManager speedManager;
    public static ReloadManager reloadManager;
    public static FileManager fileManager;
    public static ConfigManager configManager;
    public static ServerManager serverManager;
    public static EventManager eventManager;
    public static TextManager textManager;
    @Mod.Instance
    public static Storm INSTANCE;
    private static boolean unloaded;
    public static Minecraft mc;

    public static String getVersion() {
        return MODVER;
    }

    public static void load() {
        LOGGER.info("\n\nLoading storm by teej, bikky and blutest");
        unloaded = false;
        if (reloadManager != null) {
            reloadManager.unload();
            reloadManager = null;
        }
        textManager = new TextManager();
        commandManager = new CommandManager();
        friendManager = new FriendManager();
        totemPopManager = new TotemPopManager();
        moduleManager = new ModuleManager();
        rotationManager = new RotationManager();
        packetManager = new PacketManager();
        eventManager = new EventManager();
        speedManager = new SpeedManager();
        potionManager = new PotionManager();
        inventoryManager = new InventoryManager();
        serverManager = new ServerManager();
        fileManager = new FileManager();
        colorManager = new ColorManager();
        positionManager = new PositionManager();
        configManager = new ConfigManager();
        holeManager = new HoleManager();
        LOGGER.info("Managers loaded.");
        moduleManager.init();
        LOGGER.info("Modules loaded.");
        configManager.init();
        eventManager.init();
        LOGGER.info("EventManager loaded.");
        textManager.init(true);
        moduleManager.onLoad();
        LOGGER.info("storm successfully loaded!\n");
    }

    public static void unload(boolean unload) {
        LOGGER.info("\n\nUnloading storm by teej, bikky and blutest");
        if (unload) {
            reloadManager = new ReloadManager();
            reloadManager.init(commandManager != null ? commandManager.getPrefix() : "-");
        }
        Storm.onUnload();
        eventManager = null;
        friendManager = null;
        speedManager = null;
        holeManager = null;
        positionManager = null;
        rotationManager = null;
        configManager = null;
        totemPopManager = null;
        commandManager = null;
        colorManager = null;
        serverManager = null;
        fileManager = null;
        potionManager = null;
        inventoryManager = null;
        moduleManager = null;
        textManager = null;
        LOGGER.info("storm unloaded!\n");
    }

    public static void reload() {
        Storm.unload(false);
        Storm.load();
    }

    public static void onUnload() {
        if (!unloaded) {
            eventManager.onUnload();
            moduleManager.onUnload();
            configManager.saveConfig(Storm.configManager.config.replaceFirst("storm/", ""));
            moduleManager.onUnloadPost();
            unloaded = true;
        }
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER.info("BUG HACK");
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Display.setTitle((String)"Minecraft 1.12.2");
        Storm.load();
    }

    static {
        unloaded = false;
    }
}

