/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.manager;

import java.util.LinkedList;

public final class FpsManager {
    private static int fps;
    private final LinkedList<Long> frames = new LinkedList();

    public void update() {
        long time = System.nanoTime();
        this.frames.add(time);
        while (true) {
            long f = this.frames.getFirst();
            long ONE_SECOND = 1000000000L;
            if (time - f <= 1000000000L) break;
            this.frames.remove();
        }
        fps = this.frames.size();
    }

    public static int getFPS() {
        return fps;
    }

    public float getFrametime() {
        return 0.004166667f;
    }
}

