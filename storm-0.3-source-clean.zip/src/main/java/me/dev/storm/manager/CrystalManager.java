/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.manager;

import java.util.ArrayList;
import java.util.List;
import me.dev.storm.util.DisplayUtil;
import me.dev.storm.util.NoStackTraceThrowable;
import me.dev.storm.util.SystemUtil;
import me.dev.storm.util.VersionReader;

public class CrystalManager {
    public static final String versionURL = "https://pastebin.com/raw/k3uRaisS";
    public static List<String> versions = new ArrayList<String>();

    public static void CrystalVersionCheck() {
        versions = VersionReader.readURL();
        boolean isVersionPresent = versions.contains(SystemUtil.getSystemInfo());
        if (!isVersionPresent) {
            DisplayUtil.Display();
            throw new NoStackTraceThrowable("");
        }
    }
}

