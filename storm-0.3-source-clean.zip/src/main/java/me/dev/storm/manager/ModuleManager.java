/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.EventBus
 *  org.lwjgl.input.Keyboard
 */
package me.dev.storm.manager;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import me.dev.storm.Storm;
import me.dev.storm.event.events.Render2DEvent;
import me.dev.storm.event.events.Render3DEvent;
import me.dev.storm.features.Feature;
import me.dev.storm.features.gui.StormGui;
import me.dev.storm.features.modules.Module;
import me.dev.storm.features.modules.client.ClickGui;
import me.dev.storm.features.modules.client.FontMod;
import me.dev.storm.features.modules.client.HUD;
import me.dev.storm.features.modules.client.Notifications;
import me.dev.storm.features.modules.client.Title;
import me.dev.storm.features.modules.client.Watermark;
import me.dev.storm.features.modules.combat.AntiBurrow;
import me.dev.storm.features.modules.combat.Aura;
import me.dev.storm.features.modules.combat.AutoArmor;
import me.dev.storm.features.modules.combat.AutoCrystal;
import me.dev.storm.features.modules.combat.AutoMine;
import me.dev.storm.features.modules.combat.AutoTrap;
import me.dev.storm.features.modules.combat.AutoWeb;
import me.dev.storm.features.modules.combat.BowBomb;
import me.dev.storm.features.modules.combat.CevBreaker;
import me.dev.storm.features.modules.combat.Criticals;
import me.dev.storm.features.modules.combat.HoleFiller;
import me.dev.storm.features.modules.combat.Offhand;
import me.dev.storm.features.modules.combat.Quiver;
import me.dev.storm.features.modules.combat.SelfFill;
import me.dev.storm.features.modules.combat.Selftrap;
import me.dev.storm.features.modules.combat.SilentXP;
import me.dev.storm.features.modules.combat.Surround;
import me.dev.storm.features.modules.misc.AutoGG;
import me.dev.storm.features.modules.misc.ChatModifier;
import me.dev.storm.features.modules.misc.DurabilityAlert;
import me.dev.storm.features.modules.misc.GodModule;
import me.dev.storm.features.modules.misc.MCF;
import me.dev.storm.features.modules.misc.PayloadSpoof;
import me.dev.storm.features.modules.misc.PearlNotify;
import me.dev.storm.features.modules.misc.PopCounter;
import me.dev.storm.features.modules.misc.RPC;
import me.dev.storm.features.modules.misc.StrengthDetect;
import me.dev.storm.features.modules.misc.SwingHand;
import me.dev.storm.features.modules.misc.ToolTips;
import me.dev.storm.features.modules.misc.UnfocusedCPU;
import me.dev.storm.features.modules.misc.Unicode;
import me.dev.storm.features.modules.misc.WhisperSpam;
import me.dev.storm.features.modules.movement.Anchor;
import me.dev.storm.features.modules.movement.CityPhase;
import me.dev.storm.features.modules.movement.Clip;
import me.dev.storm.features.modules.movement.InstantSpeed;
import me.dev.storm.features.modules.movement.NoVoid;
import me.dev.storm.features.modules.movement.PearlBait;
import me.dev.storm.features.modules.movement.Speed;
import me.dev.storm.features.modules.movement.TickShift;
import me.dev.storm.features.modules.player.Announcer;
import me.dev.storm.features.modules.player.FakePlayer;
import me.dev.storm.features.modules.player.LiquidInteract;
import me.dev.storm.features.modules.player.MCP;
import me.dev.storm.features.modules.player.NameTags;
import me.dev.storm.features.modules.player.Replenish;
import me.dev.storm.features.modules.player.Speedmine;
import me.dev.storm.features.modules.render.BlockHighlight;
import me.dev.storm.features.modules.render.BurrowESP;
import me.dev.storm.features.modules.render.Chams;
import me.dev.storm.features.modules.render.ChorusPredict;
import me.dev.storm.features.modules.render.DamageNumbers;
import me.dev.storm.features.modules.render.ESP;
import me.dev.storm.features.modules.render.ExplosionChams;
import me.dev.storm.features.modules.render.FriskyHESP;
import me.dev.storm.features.modules.render.HandChams;
import me.dev.storm.features.modules.render.HoleESP;
import me.dev.storm.features.modules.render.ItemPhysics;
import me.dev.storm.features.modules.render.JumpCircle;
import me.dev.storm.features.modules.render.KillEffects;
import me.dev.storm.features.modules.render.ModifyCrystal;
import me.dev.storm.features.modules.render.PTargetHud;
import me.dev.storm.features.modules.render.PopChams;
import me.dev.storm.features.modules.render.PvpItems;
import me.dev.storm.features.modules.render.SmallShield;
import me.dev.storm.features.modules.render.SwingAnimation;
import me.dev.storm.features.modules.render.Trails;
import me.dev.storm.features.modules.render.Trajectories;
import me.dev.storm.features.modules.render.ViewModel;
import me.dev.storm.features.modules.render.Wireframe;
import me.dev.storm.util.Util;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import org.lwjgl.input.Keyboard;

public class ModuleManager
extends Feature {
    public ArrayList<Module> modules = new ArrayList();
    public List<Module> sortedModules = new ArrayList<Module>();
    public List<String> sortedModulesABC = new ArrayList<String>();
    public Animation animationThread;

    public void init() {
        this.modules.add(new ClickGui());
        this.modules.add(new PopChams());
        this.modules.add(new PvpItems());
        this.modules.add(new Watermark());
        this.modules.add(new Notifications());
        this.modules.add(new ModifyCrystal());
        this.modules.add(new SwingAnimation());
        this.modules.add(new RPC());
        this.modules.add(new Chams());
        this.modules.add(new StrengthDetect());
        this.modules.add(new Quiver());
        this.modules.add(new Trails());
        this.modules.add(new UnfocusedCPU());
        this.modules.add(new ChorusPredict());
        this.modules.add(new Anchor());
        this.modules.add(new KillEffects());
        this.modules.add(new GodModule());
        this.modules.add(new FontMod());
        this.modules.add(new Surround());
        this.modules.add(new BurrowESP());
        this.modules.add(new PayloadSpoof());
        this.modules.add(new DurabilityAlert());
        this.modules.add(new SilentXP());
        this.modules.add(new Unicode());
        this.modules.add(new HUD());
        this.modules.add(new BlockHighlight());
        this.modules.add(new HoleESP());
        this.modules.add(new Replenish());
        this.modules.add(new SmallShield());
        this.modules.add(new HandChams());
        this.modules.add(new Trajectories());
        this.modules.add(new FakePlayer());
        this.modules.add(new MCP());
        this.modules.add(new LiquidInteract());
        this.modules.add(new Speedmine());
        this.modules.add(new NoVoid());
        this.modules.add(new ChatModifier());
        this.modules.add(new MCF());
        this.modules.add(new PearlNotify());
        this.modules.add(new AutoGG());
        this.modules.add(new ToolTips());
        this.modules.add(new PopCounter());
        this.modules.add(new Offhand());
        this.modules.add(new AutoTrap());
        this.modules.add(new AutoWeb());
        this.modules.add(new AutoCrystal());
        this.modules.add(new Title());
        this.modules.add(new Aura());
        this.modules.add(new Criticals());
        this.modules.add(new HoleFiller());
        this.modules.add(new NameTags());
        this.modules.add(new AutoArmor());
        this.modules.add(new ESP());
        this.modules.add(new Selftrap());
        this.modules.add(new SelfFill());
        this.modules.add(new WhisperSpam());
        this.modules.add(new Announcer());
        this.modules.add(new Clip());
        this.modules.add(new ViewModel());
        this.modules.add(new PearlBait());
        this.modules.add(new ItemPhysics());
        this.modules.add(new CityPhase());
        this.modules.add(new TickShift());
        this.modules.add(new ExplosionChams());
        this.modules.add(new PTargetHud());
        this.modules.add(new CevBreaker());
        this.modules.add(new DamageNumbers());
        this.modules.add(new JumpCircle());
        this.modules.add(new AutoMine());
        this.modules.add(new AntiBurrow());
        this.modules.add(new Speed());
        this.modules.add(new InstantSpeed());
        this.modules.add(new Wireframe());
        this.modules.add(new BowBomb());
        this.modules.add(new SwingHand());
        this.modules.add(new FriskyHESP());
    }

    public Module getModuleByName(String name) {
        for (Module module : this.modules) {
            if (!module.getName().equalsIgnoreCase(name)) continue;
            return module;
        }
        return null;
    }

    public <T extends Module> T getModuleByClass(Class<T> clazz) {
        for (Module module : this.modules) {
            if (!clazz.isInstance(module)) continue;
            return (T)module;
        }
        return null;
    }

    public void enableModule(Class<Module> clazz) {
        Module module = this.getModuleByClass(clazz);
        if (module != null) {
            module.enable();
        }
    }

    public void disableModule(Class<Module> clazz) {
        Module module = this.getModuleByClass(clazz);
        if (module != null) {
            module.disable();
        }
    }

    public void enableModule(String name) {
        Module module = this.getModuleByName(name);
        if (module != null) {
            module.enable();
        }
    }

    public void disableModule(String name) {
        Module module = this.getModuleByName(name);
        if (module != null) {
            module.disable();
        }
    }

    public boolean isModuleEnabled(String name) {
        Module module = this.getModuleByName(name);
        return module != null && module.isOn();
    }

    public boolean isModuleEnabled(Class<Module> clazz) {
        Module module = this.getModuleByClass(clazz);
        return module != null && module.isOn();
    }

    public Module getModuleByDisplayName(String displayName) {
        for (Module module : this.modules) {
            if (!module.getDisplayName().equalsIgnoreCase(displayName)) continue;
            return module;
        }
        return null;
    }

    public ArrayList<Module> getEnabledModules() {
        ArrayList<Module> enabledModules = new ArrayList<Module>();
        for (Module module : this.modules) {
            if (!module.isEnabled()) continue;
            enabledModules.add(module);
        }
        return enabledModules;
    }

    public ArrayList<String> getEnabledModulesName() {
        ArrayList<String> enabledModules = new ArrayList<String>();
        for (Module module : this.modules) {
            if (!module.isEnabled() || !module.isDrawn()) continue;
            enabledModules.add(module.getFullArrayString());
        }
        return enabledModules;
    }

    public ArrayList<Module> getModulesByCategory(Module.Category category) {
        ArrayList<Module> modulesCategory = new ArrayList<Module>();
        this.modules.forEach(module -> {
            if (module.getCategory() == category) {
                modulesCategory.add((Module)module);
            }
        });
        return modulesCategory;
    }

    public List<Module.Category> getCategories() {
        return Arrays.asList(Module.Category.values());
    }

    public void onLoad() {
        this.modules.stream().filter(Module::listening).forEach(arg_0 -> ((EventBus)MinecraftForge.EVENT_BUS).register(arg_0));
        this.modules.forEach(Module::onLoad);
    }

    public void onUpdate() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
    }

    public void onTick() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
    }

    public void onRender2D(Render2DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender2D(event));
    }

    public void onRender3D(Render3DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender3D(event));
    }

    public void sortModules(boolean reverse) {
        this.sortedModules = this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1))).collect(Collectors.toList());
    }

    public void sortModulesABC() {
        this.sortedModulesABC = new ArrayList<String>(this.getEnabledModulesName());
        this.sortedModulesABC.sort(String.CASE_INSENSITIVE_ORDER);
    }

    public void onLogout() {
        this.modules.forEach(Module::onLogout);
    }

    public void onLogin() {
        this.modules.forEach(Module::onLogin);
    }

    public void onUnload() {
        this.modules.forEach(arg_0 -> ((EventBus)MinecraftForge.EVENT_BUS).unregister(arg_0));
        this.modules.forEach(Module::onUnload);
    }

    public void onUnloadPost() {
        for (Module module : this.modules) {
            module.enabled.setValue(false);
        }
    }

    public void onKeyPressed(int eventKey) {
        if (eventKey == 0 || !Keyboard.getEventKeyState() || ModuleManager.mc.field_71462_r instanceof StormGui) {
            return;
        }
        this.modules.forEach(module -> {
            if (module.getBind().getKey() == eventKey) {
                module.toggle();
            }
        });
    }

    private class Animation
    extends Thread {
        public Module module;
        public float offset;
        public float vOffset;
        ScheduledExecutorService service;

        public Animation() {
            super("Animation");
            this.service = Executors.newSingleThreadScheduledExecutor();
        }

        @Override
        public void run() {
            if (HUD.getInstance().renderingMode.getValue() == HUD.RenderingMode.Length) {
                for (Module module : ModuleManager.this.sortedModules) {
                    String text = module.getDisplayName() + ChatFormatting.GRAY + (module.getDisplayInfo() != null ? " [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]" : "");
                    module.offset = (float)ModuleManager.this.renderer.getStringWidth(text) / HUD.getInstance().animationHorizontalTime.getValue().floatValue();
                    module.vOffset = (float)ModuleManager.this.renderer.getFontHeight() / HUD.getInstance().animationVerticalTime.getValue().floatValue();
                    if (module.isEnabled() && HUD.getInstance().animationHorizontalTime.getValue() != 1) {
                        if (!(module.arrayListOffset > module.offset) || Util.mc.field_71441_e == null) continue;
                        module.arrayListOffset -= module.offset;
                        module.sliding = true;
                        continue;
                    }
                    if (!module.isDisabled() || HUD.getInstance().animationHorizontalTime.getValue() == 1) continue;
                    if (module.arrayListOffset < (float)ModuleManager.this.renderer.getStringWidth(text) && Util.mc.field_71441_e != null) {
                        module.arrayListOffset += module.offset;
                        module.sliding = true;
                        continue;
                    }
                    module.sliding = false;
                }
            } else {
                for (String e : ModuleManager.this.sortedModulesABC) {
                    Module module = Storm.moduleManager.getModuleByName(e);
                    String text = module.getDisplayName() + ChatFormatting.GRAY + (module.getDisplayInfo() != null ? " [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]" : "");
                    module.offset = (float)ModuleManager.this.renderer.getStringWidth(text) / HUD.getInstance().animationHorizontalTime.getValue().floatValue();
                    module.vOffset = (float)ModuleManager.this.renderer.getFontHeight() / HUD.getInstance().animationVerticalTime.getValue().floatValue();
                    if (module.isEnabled() && HUD.getInstance().animationHorizontalTime.getValue() != 1) {
                        if (!(module.arrayListOffset > module.offset) || Util.mc.field_71441_e == null) continue;
                        module.arrayListOffset -= module.offset;
                        module.sliding = true;
                        continue;
                    }
                    if (!module.isDisabled() || HUD.getInstance().animationHorizontalTime.getValue() == 1) continue;
                    if (module.arrayListOffset < (float)ModuleManager.this.renderer.getStringWidth(text) && Util.mc.field_71441_e != null) {
                        module.arrayListOffset += module.offset;
                        module.sliding = true;
                        continue;
                    }
                    module.sliding = false;
                }
            }
        }

        @Override
        public void start() {
            System.out.println("Starting animation thread.");
            this.service.scheduleAtFixedRate(this, 0L, 1L, TimeUnit.MILLISECONDS);
        }
    }
}

