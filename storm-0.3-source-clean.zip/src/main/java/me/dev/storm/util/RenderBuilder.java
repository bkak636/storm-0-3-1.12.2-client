/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.util;

import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class RenderBuilder {
    private static boolean setup;
    private static boolean depth;
    private static boolean blend;
    private static boolean texture;
    private static boolean cull;
    private static boolean alpha;
    private static boolean shade;
    private static AxisAlignedBB axisAlignedBB;
    private static Box box;
    private static double height;
    private static double length;
    private static double width;
    private static Color color;

    public RenderBuilder setup() {
        GlStateManager.func_179094_E();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        setup = true;
        return this;
    }

    public RenderBuilder depth(boolean in) {
        if (in) {
            GlStateManager.func_179097_i();
            GlStateManager.func_179132_a((boolean)false);
        }
        depth = in;
        return this;
    }

    public RenderBuilder blend() {
        GlStateManager.func_179147_l();
        blend = true;
        return this;
    }

    public RenderBuilder texture() {
        GlStateManager.func_179090_x();
        texture = true;
        return this;
    }

    public RenderBuilder line(float width) {
        GlStateManager.func_187441_d((float)width);
        return this;
    }

    public RenderBuilder cull(boolean in) {
        if (cull) {
            GlStateManager.func_179129_p();
        }
        cull = in;
        return this;
    }

    public RenderBuilder alpha(boolean in) {
        if (alpha) {
            GlStateManager.func_179118_c();
        }
        alpha = in;
        return this;
    }

    public RenderBuilder shade(boolean in) {
        if (in) {
            GlStateManager.func_179103_j((int)7425);
        }
        shade = in;
        return this;
    }

    public RenderBuilder build() {
        if (depth) {
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
        }
        if (texture) {
            GlStateManager.func_179098_w();
        }
        if (blend) {
            GlStateManager.func_179084_k();
        }
        if (cull) {
            GlStateManager.func_179089_o();
        }
        if (alpha) {
            GlStateManager.func_179141_d();
        }
        if (shade) {
            GlStateManager.func_179103_j((int)7424);
        }
        if (setup) {
            GL11.glDisable((int)2848);
            GlStateManager.func_179121_F();
        }
        return this;
    }

    public RenderBuilder position(BlockPos in) {
        this.position(new AxisAlignedBB((double)in.func_177958_n(), (double)in.func_177956_o(), (double)in.func_177952_p(), (double)(in.func_177958_n() + 1), (double)(in.func_177956_o() + 1), (double)(in.func_177952_p() + 1)));
        return this;
    }

    public RenderBuilder position(Vec3d in) {
        this.position(new AxisAlignedBB(in.field_72450_a, in.field_72448_b, in.field_72449_c, in.field_72450_a + 1.0, in.field_72448_b + 1.0, in.field_72449_c + 1.0));
        return this;
    }

    public RenderBuilder position(AxisAlignedBB in) {
        axisAlignedBB = in;
        return this;
    }

    public RenderBuilder height(double in) {
        height = in;
        return this;
    }

    public RenderBuilder width(double in) {
        width = in;
        return this;
    }

    public RenderBuilder length(double in) {
        length = in;
        return this;
    }

    public RenderBuilder color(Color in) {
        color = in;
        return this;
    }

    public RenderBuilder box(Box in) {
        box = in;
        return this;
    }

    public AxisAlignedBB getAxisAlignedBB() {
        return axisAlignedBB;
    }

    public double getHeight() {
        return height;
    }

    public double getWidth() {
        return width;
    }

    public double getLength() {
        return length;
    }

    public Color getColor() {
        return color;
    }

    public Box getBox() {
        return box;
    }

    static {
        axisAlignedBB = new AxisAlignedBB(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        box = Box.FILL;
        color = Color.WHITE;
    }

    public static enum Box {
        FILL,
        OUTLINE,
        BOTH,
        GLOW,
        REVERSE,
        CLAW,
        NONE;

    }
}

