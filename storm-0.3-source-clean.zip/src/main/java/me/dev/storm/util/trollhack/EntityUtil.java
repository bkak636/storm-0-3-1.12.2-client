/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockDeadBush
 *  net.minecraft.block.BlockFire
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.block.BlockSnow
 *  net.minecraft.block.BlockTallGrass
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.MobEffects
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagList
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.CombatRules
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.Explosion
 *  net.minecraft.world.World
 */
package me.dev.storm.util.trollhack;

import java.util.ArrayList;
import java.util.List;
import me.dev.storm.Storm;
import me.dev.storm.util.MathUtil;
import me.dev.storm.util.Util;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class EntityUtil
implements Util {
    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean isntValid(EntityPlayer entity, double range) {
        if ((double)EntityUtil.mc.field_71439_g.func_70032_d((Entity)entity) > range) return true;
        if (entity.func_110143_aJ() <= 0.0f) return true;
        if (entity == EntityUtil.mc.field_71439_g) return true;
        if (!Storm.friendManager.isFriend(entity)) return false;
        return true;
    }

    public static boolean isInLiquid() {
        return EntityUtil.mc.field_71439_g.func_70090_H() || EntityUtil.mc.field_71439_g.func_180799_ab();
    }

    public static boolean isMoving() {
        return EntityUtil.mc.field_71439_g.field_191988_bg != 0.0f || EntityUtil.mc.field_71439_g.field_70702_br != 0.0f;
    }

    public static EntityPlayer getClosestPlayer(float range) {
        EntityPlayer player = null;
        double maxDistance = 999.0;
        int size = EntityUtil.mc.field_71441_e.field_73010_i.size();
        for (int i = 0; i < size; ++i) {
            EntityPlayer entityPlayer = (EntityPlayer)EntityUtil.mc.field_71441_e.field_73010_i.get(i);
            if (!EntityUtil.isntValid(entityPlayer, range)) continue;
            double distanceSq = EntityUtil.mc.field_71439_g.func_70068_e((Entity)entityPlayer);
            if (maxDistance != 999.0 && !(distanceSq < maxDistance)) continue;
            maxDistance = distanceSq;
            player = entityPlayer;
        }
        return player;
    }

    public static BlockPos getRoundedBlockPos(Entity entity) {
        return new BlockPos(MathUtil.roundVec(entity.func_174791_d(), 0));
    }

    public static float getHealth(EntityPlayer player) {
        return player.func_110143_aJ() + player.func_110139_bj();
    }

    public static float calculate(double x, double y, double z, EntityLivingBase base) {
        PotionEffect resistance;
        double densityDistance;
        double distance = base.func_70011_f(x, y, z) / 12.0;
        if (distance > 1.0) {
            return 0.0f;
        }
        distance = densityDistance = (1.0 - distance) * (double)EntityUtil.mc.field_71441_e.func_72842_a(new Vec3d(x, y, z), base.func_174813_aQ());
        float damage = EntityUtil.getDifficultyMultiplier((float)((densityDistance * densityDistance + distance) / 2.0 * 7.0 * 12.0 + 1.0));
        DamageSource damageSource = DamageSource.func_94539_a((Explosion)new Explosion((World)EntityUtil.mc.field_71441_e, (Entity)EntityUtil.mc.field_71439_g, x, y, z, 6.0f, false, true));
        damage = CombatRules.func_189427_a((float)damage, (float)base.func_70658_aO(), (float)((float)base.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
        int modifierDamage = EntityUtil.getEnchantmentModifierDamage(base.func_184193_aE(), damageSource);
        if (modifierDamage > 0) {
            damage = CombatRules.func_188401_b((float)damage, (float)modifierDamage);
        }
        if ((resistance = base.func_70660_b(MobEffects.field_76429_m)) != null) {
            damage = damage * (float)(25 - (resistance.func_76458_c() + 1) * 5) / 25.0f;
        }
        return Math.max(damage, 0.0f);
    }

    public static int getEnchantmentModifierDamage(Iterable<ItemStack> stacks, DamageSource source) {
        int modifier = 0;
        for (ItemStack stack : stacks) {
            NBTTagList nbttaglist = stack.func_77986_q();
            for (int i = 0; i < nbttaglist.func_74745_c(); ++i) {
                Enchantment enchantment = Enchantment.func_185262_c((int)nbttaglist.func_150305_b(i).func_74765_d("id"));
                if (enchantment == null) continue;
                modifier += enchantment.func_77318_a((int)nbttaglist.func_150305_b(i).func_74765_d("lvl"), source);
            }
        }
        return modifier;
    }

    public static float getDifficultyMultiplier(float distance) {
        switch (EntityUtil.mc.field_71441_e.func_175659_aa()) {
            case HARD: {
                return distance * 3.0f / 2.0f;
            }
            case PEACEFUL: {
                return 0.0f;
            }
            case EASY: {
                return Math.min(distance / 2.0f + 1.0f, distance);
            }
        }
        return distance;
    }

    public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
        return new Vec3d((entity.field_70165_t - entity.field_70142_S) * x, (entity.field_70163_u - entity.field_70137_T) * y, (entity.field_70161_v - entity.field_70136_U) * z);
    }

    public static Vec3d getInterpolatedAmount(Entity entity, Vec3d vec) {
        return EntityUtil.getInterpolatedAmount(entity, vec.field_72450_a, vec.field_72448_b, vec.field_72449_c);
    }

    public static Vec3d getInterpolatedAmount(Entity entity, double ticks) {
        return EntityUtil.getInterpolatedAmount(entity, ticks, ticks, ticks);
    }

    public static Vec3d getInterpolatedPos(Entity entity, double ticks) {
        return new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U).func_178787_e(EntityUtil.getInterpolatedAmount(entity, ticks));
    }

    public static Vec3d getInterpolatedEyePos(Entity entity, double ticks) {
        return EntityUtil.getInterpolatedPos(entity, ticks).func_72441_c(0.0, (double)entity.func_70047_e(), 0.0);
    }

    public static boolean isSafe(Entity entity, int height, boolean floor) {
        return EntityUtil.getUnsafeBlocks(entity, height, floor).size() == 0;
    }

    public static boolean isSafe(Entity entity) {
        return EntityUtil.isSafe(entity, 0, false);
    }

    public static List<Vec3d> getUnsafeBlocks(Entity entity, int height, boolean floor) {
        return EntityUtil.getUnsafeBlocksFromVec3d(entity.func_174791_d(), height, floor);
    }

    public static boolean isLiving(Entity entity) {
        return entity instanceof EntityLivingBase;
    }

    public static List<Vec3d> getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
        ArrayList<Vec3d> vec3ds = new ArrayList<Vec3d>();
        for (Vec3d vector : EntityUtil.getOffsets(height, floor)) {
            BlockPos targetPos = new BlockPos(pos).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
            Block block = EntityUtil.mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
            if (!(block instanceof BlockAir) && !(block instanceof BlockLiquid) && !(block instanceof BlockTallGrass) && !(block instanceof BlockFire) && !(block instanceof BlockDeadBush) && !(block instanceof BlockSnow)) continue;
            vec3ds.add(vector);
        }
        return vec3ds;
    }

    public static List<Vec3d> getOffsetList(int y, boolean floor) {
        ArrayList<Vec3d> offsets = new ArrayList<Vec3d>();
        offsets.add(new Vec3d(-1.0, (double)y, 0.0));
        offsets.add(new Vec3d(1.0, (double)y, 0.0));
        offsets.add(new Vec3d(0.0, (double)y, -1.0));
        offsets.add(new Vec3d(0.0, (double)y, 1.0));
        if (floor) {
            offsets.add(new Vec3d(0.0, (double)(y - 1), 0.0));
        }
        return offsets;
    }

    public static Vec3d[] getOffsets(int y, boolean floor) {
        List<Vec3d> offsets = EntityUtil.getOffsetList(y, floor);
        Vec3d[] array = new Vec3d[offsets.size()];
        return offsets.toArray(array);
    }
}

