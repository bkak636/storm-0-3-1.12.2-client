/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.MathHelper
 *  org.lwjgl.opengl.GL11
 */
package me.dev.storm.util;

import java.util.ArrayList;
import java.util.Random;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

public class ParticleGenerator {
    private final int count;
    private final int width;
    private final int height;
    private final ArrayList<Particle> particles = new ArrayList();
    private final Random random = new Random();
    int state = 0;
    int a = 255;
    int r = 255;
    int g = 255;
    int b = 255;

    public ParticleGenerator(int count, int width, int height) {
        this.count = count;
        this.width = width;
        this.height = height;
        for (int i = 0; i < count; ++i) {
            this.particles.add(new Particle(this.random.nextInt(width), this.random.nextInt(height)));
        }
    }

    public void drawParticles(int mouseX, int mouseY) {
        for (Particle p : this.particles) {
            if (p.reset) {
                p.resetPosSize();
                p.reset = false;
            }
            p.draw(mouseX, mouseY);
        }
    }

    public static void drawBorderedCircle(int x, int y, float radius, int outsideC, int insideC) {
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3848);
        GL11.glPushMatrix();
        float scale = 0.1f;
        GL11.glScalef((float)scale, (float)scale, (float)scale);
        x = (int)((float)x * (1.0f / scale));
        y = (int)((float)y * (1.0f / scale));
        ParticleGenerator.drawCircle(x, y, radius *= 1.0f / scale, insideC);
        ParticleGenerator.drawUnfilledCircle(x, y, radius, 1.0f, outsideC);
        GL11.glScalef((float)(1.0f / scale), (float)(1.0f / scale), (float)(1.0f / scale));
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)3848);
    }

    public static void drawCircle(int x, int y, float radius, int color) {
        float alpha = (float)(color >> 24 & 0xFF) / 255.0f;
        float red = (float)(color >> 16 & 0xFF) / 255.0f;
        float green = (float)(color >> 8 & 0xFF) / 255.0f;
        float blue = (float)(color & 0xFF) / 255.0f;
        GL11.glColor4f((float)red, (float)green, (float)blue, (float)alpha);
        GL11.glBegin((int)9);
        for (int i = 0; i <= 360; ++i) {
            GL11.glVertex2d((double)((double)x + Math.sin((double)i * 3.141526 / 180.0) * (double)radius), (double)((double)y + Math.cos((double)i * 3.141526 / 180.0) * (double)radius));
        }
        GL11.glEnd();
    }

    public static void drawUnfilledCircle(int x, int y, float radius, float lineWidth, int color) {
        float alpha = (float)(color >> 24 & 0xFF) / 255.0f;
        float red = (float)(color >> 16 & 0xFF) / 255.0f;
        float green = (float)(color >> 8 & 0xFF) / 255.0f;
        float blue = (float)(color & 0xFF) / 255.0f;
        GL11.glColor4f((float)red, (float)green, (float)blue, (float)alpha);
        GL11.glLineWidth((float)lineWidth);
        GL11.glEnable((int)3848);
        GL11.glBegin((int)2);
        for (int i = 0; i <= 360; ++i) {
            GL11.glVertex2d((double)((double)x + Math.sin((double)i * 3.141526 / 180.0) * (double)radius), (double)((double)y + Math.cos((double)i * 3.141526 / 180.0) * (double)radius));
        }
        GL11.glEnd();
        GL11.glDisable((int)3848);
    }

    public static double distance(float x, float y, float x1, float y1) {
        return Math.sqrt((x - x1) * (x - x1) + (y - y1) * (y - y1));
    }

    public class Particle {
        private int x;
        private int y;
        private int k;
        private float size;
        private boolean reset;
        private final Random random = new Random();

        public Particle(int x, int y) {
            this.x = x;
            this.y = y;
            this.size = this.genRandom(1.0f, 3.0f);
        }

        public void draw(int mouseX, int mouseY) {
            if (this.size <= 0.0f) {
                this.reset = true;
            }
            this.size -= 0.05f;
            ++this.k;
            int xx = (int)(MathHelper.func_76134_b((float)(0.1f * (float)(this.x + this.k))) * 10.0f);
            int yy = (int)(MathHelper.func_76134_b((float)(0.1f * (float)(this.y + this.k))) * 10.0f);
            ParticleGenerator.drawBorderedCircle(this.x + xx, this.y + yy, this.size, 0, 0x20FFFFFF);
            float distance = (float)ParticleGenerator.distance(this.x + xx, this.y + yy, mouseX, mouseY);
            if (distance < 50.0f) {
                float alpha1 = Math.min(1.0f, Math.min(1.0f, 1.0f - distance / 50.0f));
                GL11.glEnable((int)2848);
                GL11.glDisable((int)2929);
                GL11.glColor4f((float)255.0f, (float)255.0f, (float)255.0f, (float)255.0f);
                GL11.glDisable((int)3553);
                GL11.glDepthMask((boolean)false);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glEnable((int)3042);
                GL11.glLineWidth((float)0.1f);
                GL11.glBegin((int)1);
                GL11.glVertex2f((float)(this.x + xx), (float)(this.y + yy));
                GL11.glVertex2f((float)mouseX, (float)mouseY);
                GL11.glEnd();
            }
        }

        public void resetPosSize() {
            this.x = this.random.nextInt(ParticleGenerator.this.width);
            this.y = this.random.nextInt(ParticleGenerator.this.height);
            this.size = this.genRandom(1.0f, 3.0f);
        }

        public float genRandom(float min, float max) {
            return (float)((double)min + Math.random() * (double)(max - min + 1.0f));
        }
    }
}

