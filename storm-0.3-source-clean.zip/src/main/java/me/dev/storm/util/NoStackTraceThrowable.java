/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.util;

import me.dev.storm.Storm;

public class NoStackTraceThrowable
extends RuntimeException {
    public NoStackTraceThrowable(String msg) {
        super(msg);
        this.setStackTrace(new StackTraceElement[0]);
    }

    @Override
    public String toString() {
        return "" + Storm.getVersion();
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}

