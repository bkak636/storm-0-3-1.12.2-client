/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.MobEffects
 *  net.minecraft.util.MovementInput
 */
package me.dev.storm.util;

import java.util.Objects;
import me.dev.storm.event.events.trollgod.MoveEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.init.MobEffects;
import net.minecraft.util.MovementInput;

public class MovementUtil {
    private static final Minecraft mc = Minecraft.func_71410_x();

    public static double[] directionSpeed(double speed) {
        float forward = MovementUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        float side = MovementUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float yaw = MovementUtil.mc.field_71439_g.field_70126_B + (MovementUtil.mc.field_71439_g.field_70177_z - MovementUtil.mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
        if (forward != 0.0f) {
            if (side > 0.0f) {
                yaw += (float)(forward > 0.0f ? -45 : 45);
            } else if (side < 0.0f) {
                yaw += (float)(forward > 0.0f ? 45 : -45);
            }
            side = 0.0f;
            if (forward > 0.0f) {
                forward = 1.0f;
            } else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }
        double sin = Math.sin(Math.toRadians(yaw + 90.0f));
        double cos = Math.cos(Math.toRadians(yaw + 90.0f));
        double posX = (double)forward * speed * cos + (double)side * speed * sin;
        double posZ = (double)forward * speed * sin - (double)side * speed * cos;
        return new double[]{posX, posZ};
    }

    public static double[] dirSpeedNew(double speed) {
        float moveForward = MovementUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        float moveStrafe = MovementUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float rotationYaw = MovementUtil.mc.field_71439_g.field_70126_B + (MovementUtil.mc.field_71439_g.field_70177_z - MovementUtil.mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
        if (moveForward != 0.0f) {
            if (moveStrafe > 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? -45 : 45);
            } else if (moveStrafe < 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? 45 : -45);
            }
            moveStrafe = 0.0f;
            if (moveForward > 0.0f) {
                moveForward = 1.0f;
            } else if (moveForward < 0.0f) {
                moveForward = -1.0f;
            }
        }
        double posX = (double)moveForward * speed * -Math.sin(Math.toRadians(rotationYaw)) + (double)moveStrafe * speed * Math.cos(Math.toRadians(rotationYaw));
        double posZ = (double)moveForward * speed * Math.cos(Math.toRadians(rotationYaw)) - (double)moveStrafe * speed * -Math.sin(Math.toRadians(rotationYaw));
        return new double[]{posX, posZ};
    }

    public static double[] futureCalc1(double d) {
        double d4;
        double d5;
        MovementInput movementInput = MovementUtil.mc.field_71439_g.field_71158_b;
        double d2 = movementInput.field_192832_b;
        double d3 = movementInput.field_78902_a;
        float f = MovementUtil.mc.field_71439_g.field_70177_z;
        if (d2 == 0.0 && d3 == 0.0) {
            d5 = 0.0;
            d4 = 0.0;
        } else {
            if (d2 != 0.0) {
                if (d3 > 0.0) {
                    f += (float)(d2 > 0.0 ? -45 : 45);
                } else if (d3 < 0.0) {
                    f += (float)(d2 > 0.0 ? 45 : -45);
                }
                d3 = 0.0;
                if (d2 > 0.0) {
                    d2 = 1.0;
                } else if (d2 < 0.0) {
                    d2 = -1.0;
                }
            }
            d4 = d2 * d * Math.cos(Math.toRadians(f + 90.0f)) + d3 * d * Math.sin(Math.toRadians(f + 90.0f));
            d5 = d2 * d * Math.sin(Math.toRadians(f + 90.0f)) - d3 * d * Math.cos(Math.toRadians(f + 90.0f));
        }
        return new double[]{d4, d5};
    }

    public static void strafe(MoveEvent event, double speed) {
        if (MovementUtil.isMoving()) {
            double[] strafe = MovementUtil.strafe(speed);
            event.setMotionX(strafe[0]);
            event.setMotionZ(strafe[1]);
        } else {
            event.setMotionX(0.0);
            event.setMotionZ(0.0);
        }
    }

    public static double[] strafe(double speed) {
        return MovementUtil.strafe((Entity)MovementUtil.mc.field_71439_g, speed);
    }

    public static double[] strafe(Entity entity, double speed) {
        return MovementUtil.strafe(entity, MovementUtil.mc.field_71439_g.field_71158_b, speed);
    }

    public static double[] strafe(Entity entity, MovementInput movementInput, double speed) {
        float moveForward = movementInput.field_192832_b;
        float moveStrafe = movementInput.field_78902_a;
        float rotationYaw = entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * mc.func_184121_ak();
        if (moveForward != 0.0f) {
            if (moveStrafe > 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? -45 : 45);
            } else if (moveStrafe < 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? 45 : -45);
            }
            moveStrafe = 0.0f;
            if (moveForward > 0.0f) {
                moveForward = 1.0f;
            } else if (moveForward < 0.0f) {
                moveForward = -1.0f;
            }
        }
        double posX = (double)moveForward * speed * -Math.sin(Math.toRadians(rotationYaw)) + (double)moveStrafe * speed * Math.cos(Math.toRadians(rotationYaw));
        double posZ = (double)moveForward * speed * Math.cos(Math.toRadians(rotationYaw)) - (double)moveStrafe * speed * -Math.sin(Math.toRadians(rotationYaw));
        return new double[]{posX, posZ};
    }

    public static boolean isMoving() {
        return (double)MovementUtil.mc.field_71439_g.field_191988_bg != 0.0 || (double)MovementUtil.mc.field_71439_g.field_70702_br != 0.0;
    }

    public static double getSpeed() {
        return MovementUtil.getSpeed(false);
    }

    public static double getSpeed(boolean slowness) {
        int amplifier;
        double defaultSpeed = 0.2873;
        if (MovementUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            amplifier = Objects.requireNonNull(MovementUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c)).func_76458_c();
            defaultSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        if (slowness && MovementUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76421_d)) {
            amplifier = Objects.requireNonNull(MovementUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76421_d)).func_76458_c();
            defaultSpeed /= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return defaultSpeed;
    }
}

