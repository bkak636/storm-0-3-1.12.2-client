/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package me.dev.storm.util;

import net.minecraft.client.Minecraft;

public interface Util {
    public static final Minecraft mc = Minecraft.func_71410_x();
}

