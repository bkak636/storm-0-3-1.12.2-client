/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.texture.TextureManager
 *  net.minecraft.client.resources.IResourceManager
 *  net.minecraft.util.ChatAllowedCharacters
 *  net.minecraft.util.ResourceLocation
 */
package me.dev.storm.util;

import java.awt.Color;
import java.awt.Font;
import java.util.Random;
import me.dev.storm.util.ImageAWT;
import me.dev.storm.util.Util;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ResourceLocation;

public class LBFontRenderer
extends FontRenderer
implements Util {
    private final ImageAWT defaultFont;

    public LBFontRenderer(Font font) {
        super(LBFontRenderer.mc.field_71474_y, new ResourceLocation("textures/font/ascii.png"), (TextureManager)null, false);
        this.defaultFont = new ImageAWT(font);
        this.field_78288_b = this.getHeight();
    }

    public int getHeight() {
        return this.defaultFont.getHeight() / 2;
    }

    public int getSize() {
        return this.defaultFont.getFont().getSize();
    }

    public int func_175063_a(String text, float x, float y, int color) {
        return this.func_175065_a(text, x, y, color, true);
    }

    public int func_175065_a(String text, float x, float y, int color, boolean dropShadow) {
        float currY = y - 3.0f;
        if (text.contains("\n")) {
            String[] parts = text.split("\n");
            float newY = 0.0f;
            for (String s : parts) {
                this.drawText(s, x, currY + newY, color, dropShadow);
                newY += (float)this.getHeight();
            }
            return 0;
        }
        if (dropShadow) {
            this.drawText(text, x + 1.0f, currY + 1.0f, new Color(0, 0, 0, 150).getRGB(), true);
        }
        return this.drawText(text, x, currY, color, false);
    }

    private int drawText(String text, float x, float y, int color, boolean ignoreColor) {
        if (text == null) {
            return 0;
        }
        if (text.isEmpty()) {
            return (int)x;
        }
        GlStateManager.func_179137_b((double)((double)x - 1.5), (double)((double)y + 0.5), (double)0.0);
        GlStateManager.func_179141_d();
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179098_w();
        int currentColor = color;
        if ((currentColor & 0xFC000000) == 0) {
            currentColor |= 0xFF000000;
        }
        int alpha = currentColor >> 24 & 0xFF;
        if (text.contains("\u00c2\u00c2\u00a7")) {
            String[] parts = text.split("\u00c2\u00c2\u00a7");
            ImageAWT currentFont = this.defaultFont;
            double width = 0.0;
            boolean randomCase = false;
            for (int index = 0; index < parts.length; ++index) {
                String part = parts[index];
                if (part.isEmpty()) continue;
                if (index == 0) {
                    currentFont.drawString(part, width, 0.0, currentColor);
                    width += (double)currentFont.getStringWidth(part);
                    continue;
                }
                String words = part.substring(1);
                char type2 = part.charAt(0);
                int colorIndex = "0123456789abcdefklmnor".indexOf(type2);
                switch (colorIndex) {
                    case 0: 
                    case 1: 
                    case 2: 
                    case 3: 
                    case 4: 
                    case 5: 
                    case 6: 
                    case 7: 
                    case 8: 
                    case 9: 
                    case 10: 
                    case 11: 
                    case 12: 
                    case 13: 
                    case 14: 
                    case 15: {
                        if (!ignoreColor) {
                            currentColor = ColorUtils.hexColors[colorIndex] | alpha << 24;
                        }
                        randomCase = false;
                        break;
                    }
                    case 16: {
                        randomCase = true;
                    }
                    case 21: {
                        currentColor = color;
                        if ((currentColor & 0xFC000000) == 0) {
                            currentColor |= 0xFF000000;
                        }
                        randomCase = false;
                    }
                }
                currentFont = this.defaultFont;
                if (randomCase) {
                    currentFont.drawString(ColorUtils.randomMagicText(words), width, 0.0, currentColor);
                } else {
                    currentFont.drawString(words, width, 0.0, currentColor);
                }
                width += (double)currentFont.getStringWidth(words);
            }
        } else {
            this.defaultFont.drawString(text, 0.0, 0.0, currentColor);
        }
        GlStateManager.func_179084_k();
        GlStateManager.func_179137_b((double)(-((double)x - 1.5)), (double)(-((double)y + 0.5)), (double)0.0);
        return (int)(x + (float)this.func_78256_a(text));
    }

    public int func_175064_b(char charCode) {
        return ColorUtils.hexColors[LBFontRenderer.getColorIndex(charCode)];
    }

    public int func_78256_a(String text) {
        if (text.contains("\u00c2\u00c2\u00a7")) {
            String[] parts = text.split("\u00c2\u00c2\u00a7");
            ImageAWT currentFont = this.defaultFont;
            int width = 0;
            for (int index = 0; index < parts.length; ++index) {
                String part = parts[index];
                if (part.isEmpty()) continue;
                if (index == 0) {
                    width += currentFont.getStringWidth(part);
                    continue;
                }
                String words = part.substring(1);
                currentFont = this.defaultFont;
                width += currentFont.getStringWidth(words);
            }
            return width / 2;
        }
        return this.defaultFont.getStringWidth(text) / 2;
    }

    public int func_78263_a(char character) {
        return this.func_78256_a(String.valueOf(character));
    }

    public void func_110549_a(IResourceManager resourceManager) {
    }

    protected void bindTexture(ResourceLocation location) {
    }

    public static int getColorIndex(char type2) {
        switch (type2) {
            case '0': 
            case '1': 
            case '2': 
            case '3': 
            case '4': 
            case '5': 
            case '6': 
            case '7': 
            case '8': 
            case '9': {
                return type2 - 48;
            }
            case 'a': 
            case 'b': 
            case 'c': 
            case 'd': 
            case 'e': 
            case 'f': {
                return type2 - 97 + 10;
            }
            case 'k': 
            case 'l': 
            case 'm': 
            case 'n': 
            case 'o': {
                return type2 - 107 + 16;
            }
            case 'r': {
                return 21;
            }
        }
        return -1;
    }

    private static class ColorUtils {
        public static int[] hexColors;
        private static final Random random;
        private static final String magicAllowedCharacters = "\u00c3\u20ac\u00c3\ufffd\u00c3\u201a\u00c3\u02c6\u00c3\u0160\u00c3\u2039\u00c3\ufffd\u00c3\u201c\u00c3\u201d\u00c3\u2022\u00c3\u0161\u00c3\u0178\u00c3\u00c2\u00a3\u00c3\u00c2\u00b5\u00c4\u0178\u00c4\u00c2\u00b0\u00c4\u00c2\u00b1\u00c5\u2019\u00c5\u201c\u00c5\u017e\u00c5\u0178\u00c5\u00c2\u00b4\u00c5\u00c2\u00b5\u00c5\u00c2\u00be\u00c8\u2021 !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u00c3\u2021\u00c3\u00c2\u00bc\u00c3\u00c2\u00a9\u00c3\u00c2\u00a2\u00c3\u00c2\u00a4\u00c3\u00c2\u00a0\u00c3\u00c2\u00a5\u00c3\u00c2\u00a7\u00c3\u00c2\u00aa\u00c3\u00c2\u00ab\u00c3\u00c2\u00a8\u00c3\u00c2\u00af\u00c3\u00c2\u00ae\u00c3\u00c2\u00ac\u00c3\u201e\u00c3\u2026\u00c3\u2030\u00c3\u00c2\u00a6\u00c3\u2020\u00c3\u00c2\u00b4\u00c3\u00c2\u00b6\u00c3\u00c2\u00b2\u00c3\u00c2\u00bb\u00c3\u00c2\u00b9\u00c3\u00c2\u00bf\u00c3\u2013\u00c3\u0153\u00c3\u00c2\u00b8\u00c2\u00c2\u00a3\u00c3\u02dc\u00c3\u2014\u00c6\u2019\u00c3\u00c2\u00a1\u00c3\u00ad\u00c3\u00c2\u00b3\u00c3\u00c2\u00ba\u00c3\u00c2\u00b1\u00c3\u2018\u00c2\u00c2\u00aa\u00c2\u00c2\u00ba\u00c2\u00c2\u00bf\u00c2\u00c2\u00ae\u00c2\u00c2\u00ac\u00c2\u00c2\u00bd\u00c2\u00c2\u00bc\u00c2\u00c2\u00a1\u00c2\u00c2\u00ab\u00c2\u00c2\u00bb\u00e2\u2013\u2018\u00e2\u2013\u2019\u00e2\u2013\u201c\u00e2\u201d\u201a\u00e2\u201d\u00c2\u00a4\u00e2\u2022\u00c2\u00a1\u00e2\u2022\u00c2\u00a2\u00e2\u2022\u2013\u00e2\u2022\u2022\u00e2\u2022\u00c2\u00a3\u00e2\u2022\u2018\u00e2\u2022\u2014\u00e2\u2022\ufffd\u00e2\u2022\u0153\u00e2\u2022\u203a\u00e2\u201d\ufffd\u00e2\u201d\u201d\u00e2\u201d\u00c2\u00b4\u00e2\u201d\u00c2\u00ac\u00e2\u201d\u0153\u00e2\u201d\u20ac\u00e2\u201d\u00c2\u00bc\u00e2\u2022\u017e\u00e2\u2022\u0178\u00e2\u2022\u0161\u00e2\u2022\u201d\u00e2\u2022\u00c2\u00a9\u00e2\u2022\u00c2\u00a6\u00e2\u2022\u00c2\u00a0\u00e2\u2022\ufffd\u00e2\u2022\u00c2\u00ac\u00e2\u2022\u00c2\u00a7\u00e2\u2022\u00c2\u00a8\u00e2\u2022\u00c2\u00a4\u00e2\u2022\u00c2\u00a5\u00e2\u2022\u2122\u00e2\u2022\u02dc\u00e2\u2022\u2019\u00e2\u2022\u201c\u00e2\u2022\u00c2\u00ab\u00e2\u2022\u00c2\u00aa\u00e2\u201d\u02dc\u00e2\u201d\u0152\u00e2\u2013\u02c6\u00e2\u2013\u201e\u00e2\u2013\u0152\u00e2\u2013\ufffd\u00e2\u2013\u20ac\u00ce\u00c2\u00b1\u00ce\u00c2\u00b2\u00ce\u201c\u00cf\u20ac\u00ce\u00c2\u00a3\u00cf\u0192\u00ce\u00c2\u00bc\u00cf\u201e\u00ce\u00c2\u00a6\u00ce\u02dc\u00ce\u00c2\u00a9\u00ce\u00c2\u00b4\u00e2\u02c6\u017e\u00e2\u02c6\u2026\u00e2\u02c6\u02c6\u00e2\u02c6\u00c2\u00a9\u00e2\u2030\u00c2\u00a1\u00c2\u00c2\u00b1\u00e2\u2030\u00c2\u00a5\u00e2\u2030\u00c2\u00a4\u00e2\u0152\u00c2\u00a0\u00e2\u0152\u00c2\u00a1\u00c3\u00c2\u00b7\u00e2\u2030\u02c6\u00c2\u00c2\u00b0\u00e2\u02c6\u2122\u00c2\u00c2\u00b7\u00e2\u02c6\u0161\u00e2\ufffd\u00c2\u00bf\u00c2\u00c2\u00b2\u00e2\u2013\u00c2\u00a0";

        private ColorUtils() {
        }

        public static String randomMagicText(String text) {
            StringBuilder stringBuilder = new StringBuilder();
            for (char ch : text.toCharArray()) {
                if (!ChatAllowedCharacters.func_71566_a((char)ch)) continue;
                int index = random.nextInt(magicAllowedCharacters.length());
                stringBuilder.append(magicAllowedCharacters.charAt(index));
            }
            return stringBuilder.toString();
        }

        static {
            int[] nArray = new int[16];
            hexColors = nArray;
            nArray[0] = 0;
            ColorUtils.hexColors[1] = 170;
            ColorUtils.hexColors[2] = 43520;
            ColorUtils.hexColors[3] = 43690;
            ColorUtils.hexColors[4] = 0xAA0000;
            ColorUtils.hexColors[5] = 0xAA00AA;
            ColorUtils.hexColors[6] = 0xFFAA00;
            ColorUtils.hexColors[7] = 0xAAAAAA;
            ColorUtils.hexColors[8] = 0x555555;
            ColorUtils.hexColors[9] = 0x5555FF;
            ColorUtils.hexColors[10] = 0x55FF55;
            ColorUtils.hexColors[11] = 0x55FFFF;
            ColorUtils.hexColors[12] = 0xFF5555;
            ColorUtils.hexColors[13] = 0xFF55FF;
            ColorUtils.hexColors[14] = 0xFFFF55;
            ColorUtils.hexColors[15] = 0xFFFFFF;
            random = new Random();
        }
    }
}

