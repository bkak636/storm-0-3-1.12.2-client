/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.Entity
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package me.dev.storm.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import me.dev.storm.util.Util;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class ItemUtil {
    public static final Minecraft mc = Minecraft.func_71410_x();

    public static boolean placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking) {
        boolean sneaking = false;
        EnumFacing side = ItemUtil.getFirstFacing(pos);
        if (side == null) {
            return isSneaking;
        }
        BlockPos neighbour = pos.func_177972_a(side);
        EnumFacing opposite = side.func_176734_d();
        Vec3d hitVec = new Vec3d((Vec3i)neighbour).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(opposite.func_176730_m()).func_186678_a(0.5));
        Block neighbourBlock = ItemUtil.mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
        if (!ItemUtil.mc.field_71439_g.func_70093_af()) {
            ItemUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)ItemUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            ItemUtil.mc.field_71439_g.func_70095_a(true);
            sneaking = true;
        }
        if (rotate) {
            ItemUtil.faceVector(hitVec, true);
        }
        ItemUtil.rightClickBlock(neighbour, hitVec, hand, opposite, packet);
        ItemUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        ItemUtil.mc.field_71467_ac = 4;
        return sneaking || isSneaking;
    }

    public static List<EnumFacing> getPossibleSides(BlockPos pos) {
        ArrayList<EnumFacing> facings = new ArrayList<EnumFacing>();
        for (EnumFacing side : EnumFacing.values()) {
            IBlockState blockState;
            BlockPos neighbour = pos.func_177972_a(side);
            if (!ItemUtil.mc.field_71441_e.func_180495_p(neighbour).func_177230_c().func_176209_a(ItemUtil.mc.field_71441_e.func_180495_p(neighbour), false) || (blockState = ItemUtil.mc.field_71441_e.func_180495_p(neighbour)).func_185904_a().func_76222_j()) continue;
            facings.add(side);
        }
        return facings;
    }

    public static EnumFacing getFirstFacing(BlockPos pos) {
        Iterator<EnumFacing> iterator = ItemUtil.getPossibleSides(pos).iterator();
        if (iterator.hasNext()) {
            EnumFacing facing = iterator.next();
            return facing;
        }
        return null;
    }

    public static int getItemCount(Item item) {
        int count = 0;
        int size = Util.mc.field_71439_g.field_71071_by.field_70462_a.size();
        for (int i = 0; i < size; ++i) {
            ItemStack itemStack = (ItemStack)Util.mc.field_71439_g.field_71071_by.field_70462_a.get(i);
            if (itemStack.func_77973_b() != item) continue;
            count += itemStack.func_190916_E();
        }
        ItemStack offhandStack = Util.mc.field_71439_g.func_184592_cb();
        if (item == offhandStack.func_77973_b()) {
            count += offhandStack.func_190916_E();
        }
        return count;
    }

    public static Vec3d getEyesPos() {
        return new Vec3d(ItemUtil.mc.field_71439_g.field_70165_t, ItemUtil.mc.field_71439_g.field_70163_u + (double)ItemUtil.mc.field_71439_g.func_70047_e(), ItemUtil.mc.field_71439_g.field_70161_v);
    }

    public static float[] getLegitRotations(Vec3d vec) {
        Vec3d eyesPos = ItemUtil.getEyesPos();
        double diffX = vec.field_72450_a - eyesPos.field_72450_a;
        double diffY = vec.field_72448_b - eyesPos.field_72448_b;
        double diffZ = vec.field_72449_c - eyesPos.field_72449_c;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{ItemUtil.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g((float)(yaw - ItemUtil.mc.field_71439_g.field_70177_z)), ItemUtil.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g((float)(pitch - ItemUtil.mc.field_71439_g.field_70125_A))};
    }

    public static void faceVector(Vec3d vec, boolean normalizeAngle) {
        float[] rotations = ItemUtil.getLegitRotations(vec);
        ItemUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(rotations[0], normalizeAngle ? (float)MathHelper.func_180184_b((int)((int)rotations[1]), (int)360) : rotations[1], ItemUtil.mc.field_71439_g.field_70122_E));
    }

    public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction, boolean packet) {
        if (packet) {
            float f = (float)(vec.field_72450_a - (double)pos.func_177958_n());
            float f1 = (float)(vec.field_72448_b - (double)pos.func_177956_o());
            float f2 = (float)(vec.field_72449_c - (double)pos.func_177952_p());
            ItemUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
        } else {
            ItemUtil.mc.field_71442_b.func_187099_a(ItemUtil.mc.field_71439_g, ItemUtil.mc.field_71441_e, pos, direction, vec, hand);
        }
        ItemUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        ItemUtil.mc.field_71467_ac = 4;
    }

    public static int findHotbarBlock(Class clazz) {
        for (int i = 0; i < 9; ++i) {
            Block block;
            ItemStack stack = ItemUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack == ItemStack.field_190927_a) continue;
            if (clazz.isInstance(stack.func_77973_b())) {
                return i;
            }
            if (!(stack.func_77973_b() instanceof ItemBlock) || !clazz.isInstance(block = ((ItemBlock)stack.func_77973_b()).func_179223_d())) continue;
            return i;
        }
        return -1;
    }

    public static void switchToSlot(int slot) {
        ItemUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
        ItemUtil.mc.field_71439_g.field_71071_by.field_70461_c = slot;
        ItemUtil.mc.field_71442_b.func_78765_e();
    }
}

