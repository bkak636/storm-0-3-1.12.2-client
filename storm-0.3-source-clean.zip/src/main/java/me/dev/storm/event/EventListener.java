/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package me.dev.storm.event;

import me.dev.storm.Storm;
import net.minecraft.client.Minecraft;

public abstract class EventListener<E, M> {
    protected final Minecraft mc = Storm.mc;
    protected final Class<? extends E> listener;
    public M module;

    public EventListener(Class<? extends E> listener) {
        this.listener = listener;
    }

    public EventListener(Class<? extends E> listener, M module) {
        this.listener = listener;
        this.module = module;
    }

    public Class<? extends E> getListener() {
        return this.listener;
    }

    public void invoke(Object object) {
    }
}

