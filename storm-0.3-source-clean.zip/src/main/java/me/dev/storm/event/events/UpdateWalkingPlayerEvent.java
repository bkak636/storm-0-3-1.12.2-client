/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.event.events;

import me.dev.storm.event.EventStage;

public class UpdateWalkingPlayerEvent
extends EventStage {
    public UpdateWalkingPlayerEvent(int stage) {
        super(stage);
    }
}

