/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.Event
 */
package me.dev.storm.event;

import net.minecraftforge.fml.common.eventhandler.Event;

public class EventHandler
extends Event {
    private int stage;

    public EventHandler() {
    }

    public EventHandler(int stage) {
        this.stage = stage;
    }

    public int getStage() {
        return this.stage;
    }

    public void setStage(int stage) {
        this.stage = stage;
    }
}

