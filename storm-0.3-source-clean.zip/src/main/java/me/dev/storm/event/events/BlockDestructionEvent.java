/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.BlockPos
 */
package me.dev.storm.event.events;

import me.dev.storm.event.EventStage;
import net.minecraft.util.math.BlockPos;

public class BlockDestructionEvent
extends EventStage {
    BlockPos blockz;

    public BlockDestructionEvent(BlockPos blockz) {
    }

    public BlockPos getBlockPos() {
        return this.blockz;
    }
}

