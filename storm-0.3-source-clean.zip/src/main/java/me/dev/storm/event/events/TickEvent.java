/*
 * Decompiled with CFR 0.152.
 */
package me.dev.storm.event.events;

import me.dev.storm.event.EventStage;

public class TickEvent
extends EventStage {
    protected boolean isCancellable() {
        return false;
    }

    public static class Post
    extends TickEvent {
    }

    public static class Pre
    extends TickEvent {
    }
}

