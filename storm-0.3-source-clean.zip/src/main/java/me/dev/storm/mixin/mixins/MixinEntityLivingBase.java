/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.EntityLivingBase
 */
package me.dev.storm.mixin.mixins;

import me.dev.storm.Storm;
import me.dev.storm.features.modules.render.SwingAnimation;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={EntityLivingBase.class})
public class MixinEntityLivingBase {
    @Inject(method={"getArmSwingAnimationEnd"}, at={@At(value="HEAD")}, cancellable=true)
    public void getArmSwingAnimationEndHook(CallbackInfoReturnable<Integer> cir) {
        int stuff = Storm.moduleManager.getModuleByClass(SwingAnimation.class).isEnabled() ? SwingAnimation.changeSwing.getValue() : 6;
        cir.setReturnValue(stuff);
    }
}

