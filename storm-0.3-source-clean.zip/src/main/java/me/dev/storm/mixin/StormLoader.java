/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.relauncher.IFMLLoadingPlugin
 */
package me.dev.storm.mixin;

import java.util.Map;
import me.dev.storm.Storm;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;

public class StormLoader
implements IFMLLoadingPlugin {
    private static boolean isObfuscatedEnvironment = false;

    public StormLoader() {
        Storm.LOGGER.info("\n\nLoading mixins by storm");
        MixinBootstrap.init();
        Mixins.addConfiguration("mixins.storm.json");
        MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");
        Storm.LOGGER.info(MixinEnvironment.getDefaultEnvironment().getObfuscationContext());
    }

    public String[] getASMTransformerClass() {
        return new String[0];
    }

    public String getModContainerClass() {
        return null;
    }

    public String getSetupClass() {
        return null;
    }

    public void injectData(Map<String, Object> data) {
        isObfuscatedEnvironment = (Boolean)data.get("runtimeDeobfuscationEnabled");
    }

    public String getAccessTransformerClass() {
        return null;
    }
}

