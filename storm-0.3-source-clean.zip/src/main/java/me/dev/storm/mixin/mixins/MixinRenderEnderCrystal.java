/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.entity.Render
 *  net.minecraft.client.renderer.entity.RenderEnderCrystal
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.MathHelper
 */
package me.dev.storm.mixin.mixins;

import javax.annotation.Nullable;
import me.dev.storm.features.modules.render.ModifyCrystal;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={RenderEnderCrystal.class})
public class MixinRenderEnderCrystal
extends Render<EntityEnderCrystal> {
    @Shadow
    public ModelBase field_76995_b;
    @Final
    @Shadow
    private static ResourceLocation field_110787_a;

    protected MixinRenderEnderCrystal(RenderManager renderManager) {
        super(renderManager);
    }

    @Redirect(method={"doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"))
    public void bottomRenderRedirect(ModelBase modelBase, Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        GlStateManager.func_179152_a((float)ModifyCrystal.scale.getValue().floatValue(), (float)ModifyCrystal.scale.getValue().floatValue(), (float)ModifyCrystal.scale.getValue().floatValue());
        modelBase.func_78088_a(entityIn, limbSwing, limbSwingAmount * ModifyCrystal.getSpeed()[0], ageInTicks * ModifyCrystal.getSpeed()[1], netHeadYaw, headPitch, scale);
    }

    @Inject(method={"doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V"}, at={@At(value="RETURN")}, cancellable=true)
    public void doRenderCrystal(EntityEnderCrystal entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo ci) {
        float f3 = (float)entity.field_70261_a + partialTicks;
        float f4 = MathHelper.func_76126_a((float)(f3 * 0.2f)) / 2.0f + 0.5f;
        f4 += f4 * f4;
        if (entity.func_184520_k()) {
            this.field_76995_b.func_78088_a((Entity)entity, 0.0f, f3 * 3.0f * ModifyCrystal.getSpeed()[0], f4 * 0.2f * ModifyCrystal.getSpeed()[1], 0.0f, 0.0f, 0.0625f);
        }
    }

    @Nullable
    protected ResourceLocation getEntityTexture(EntityEnderCrystal entity) {
        return null;
    }
}

